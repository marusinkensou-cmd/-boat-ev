import sqlite3
from prediction_v161 import staged_picks
scores=[{"boat":i,"score":s,"components":{"進入コース":.1}} for i,s in enumerate([1.0,.8,.7,.5,.4,.3],1)]
first,picks=staged_picks(scores)
assert max(first,key=first.get)==1
assert picks and picks[0]["combination"].startswith("1")
assert len(picks)<=5
assert len({p["combination"] for p in picks})==len(picks)
print("v1.6.1 staged prediction: OK")
