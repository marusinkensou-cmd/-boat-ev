from __future__ import annotations
import os, sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from nationwide_board_v09 import parse_deadline
from prediction_v162 import predict_race
from refresh_service_v13 import seed_today
from racelist_live_v12 import refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from result_live_v14 import fetch_resultlist
from validation_store_v166 import save_snapshot,has_snapshot,unsettled,settle,metrics,MODEL_VERSION

JST=ZoneInfo('Asia/Tokyo')

def _db_path(con):
    row=con.execute('PRAGMA database_list').fetchone()
    return row[2]

def capture_race(con, race_id, now=None, cache_dir='cache/live'):
    now=now or datetime.now(JST)
    row=con.execute('SELECT race_date,jcd,race_no,deadline FROM races WHERE race_id=?',(race_id,)).fetchone()
    if not row:return {'saved':False,'reason':'race_missing'}
    date,jcd,rno,deadline=row
    dl=parse_deadline(date,deadline)
    if not dl or dl<=now:return {'saved':False,'reason':'deadline_passed'}
    path=_db_path(con)
    if has_snapshot(path,race_id):return {'saved':False,'reason':'already_saved'}
    pr=predict_race(con,race_id,5)
    if pr.get('status')!='ok':return {'saved':False,'reason':'prediction_missing'}
    if pr.get('stage')!='final':return {'saved':False,'reason':'not_final'}
    payload={
        'race_id':race_id,'captured_at':now.isoformat(),'deadline_at':dl.isoformat(),
        'first_rank':pr.get('first_rank',[]),'predictions':pr.get('predictions',[]),
        'buy_plan':pr.get('buy_plan',{}),'weather':pr.get('weather'),
        'boat_scores':pr.get('boat_scores',[]),'exhibition_courses':pr.get('exhibition_courses',{}),
        'parse_status':pr.get('parse_status',{}),'f_risk':pr.get('f_risk',[]),
        'model_version':MODEL_VERSION
    }
    ok=save_snapshot(path,race_id=race_id,jcd=jcd,race_no=rno,captured_at=now,deadline_at=dl,stage='final',payload=payload)
    return {'saved':bool(ok),'race_id':race_id,'jcd':jcd,'race_no':rno,'deadline':dl.isoformat()}

def settle_pending(con, now=None, cache_dir='cache/live', grace_min=3):
    now=now or datetime.now(JST); path=_db_path(con)
    rows=unsettled(path,now-timedelta(minutes=grace_min))
    groups={}
    for rid,jcd,rno,deadline in rows:
        groups.setdefault(str(jcd).zfill(2),[]).append((rid,int(rno)))
    out=[]; errors=[]
    today=now.date().isoformat()
    for jcd,items in groups.items():
        try:
            results,_,_=fetch_resultlist(today,jcd,cache_dir)
            for rid,rno in items:
                item=results.get(rno)
                if not item or '返還' in (item.get('note') or ''):continue
                if settle(path,rid,item['combo'],item['payout'],now):
                    out.append({'race_id':rid,'combo':item['combo'],'payout':item['payout']})
        except Exception as e:
            errors.append({'jcd':jcd,'error':f'{type(e).__name__}: {e}'})
    return {'settled':out,'errors':errors}

def nationwide_tick(con, now=None, cache_dir='cache/live', capture_window_min=15, max_capture=6):
    '''One bounded validation cycle.
    1) discover/seed today's venues, 2) capture races within 0..capture_window_min,
    3) settle races already finished. No odds are read.
    '''
    now=now or datetime.now(JST)
    seeded,venue_errors=seed_today(con,now,cache_dir,selected_jcds=None)
    today=now.date().isoformat(); path=_db_path(con)
    rows=con.execute('''SELECT race_id,jcd,race_no,deadline FROM races WHERE race_date=? AND deadline IS NOT NULL ORDER BY deadline,jcd,race_no''',(today,)).fetchall()
    due=[]
    for rid,jcd,rno,deadline in rows:
        dl=parse_deadline(today,deadline)
        if not dl:continue
        mins=(dl-now).total_seconds()/60
        if 0 < mins <= capture_window_min and not has_snapshot(path,rid):
            due.append((mins,rid,jcd,rno))
    captured=[]; errors=[]
    for mins,rid,jcd,rno in due[:max_capture]:
        try:
            cnt=con.execute('SELECT COUNT(*) FROM entries WHERE race_id=?',(rid,)).fetchone()[0]
            if cnt<6: refresh_racelist(con,today,jcd,rno,cache_dir)
            refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir)
            captured.append(capture_race(con,rid,now,cache_dir))
        except Exception as e:
            errors.append({'race_id':rid,'jcd':jcd,'race_no':rno,'error':f'{type(e).__name__}: {e}'})
    settled=settle_pending(con,now,cache_dir)
    return {'generated_at':now.isoformat(),'model_version':MODEL_VERSION,'venues_found':len(seeded),
            'venue_errors':venue_errors,'due_count':len(due),'captured':captured,'capture_errors':errors,
            'settlement':settled,'metrics':metrics(path)}
