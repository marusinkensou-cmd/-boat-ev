from __future__ import annotations
import os, sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from nationwide_board_v09 import parse_deadline
from prediction_v162 import predict_race
from refresh_service_v13 import seed_today
from racelist_live_v12 import refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from result_live_v14 import fetch_resultlist
from validation_store_v166 import save_snapshot,has_snapshot,unsettled,settle,metrics,MODEL_VERSION

JST=ZoneInfo('Asia/Tokyo')

def _db_path(con):
    row=con.execute('PRAGMA database_list').fetchone()
    return row[2]



def _virtual_investment_plan(pr):
    """Build a validation-only stake plan.

    User rule: 100-200 yen per combination, roughly 1,000 yen per race,
    with an allowed band of 800-1,200 yen. The visible app buy plan is not
    changed; this plan is only for forward-test profitability measurement.
    """
    base=(pr.get('buy_plan') or {})
    src=list(base.get('bets') or [])
    # Deduplicate combinations while preserving priority/order.
    seen=set(); bets=[]
    for b in src:
        combo=str(b.get('combination') or '')
        if not combo or combo in seen:
            continue
        seen.add(combo)
        bets.append({
            'combination':combo,
            'stake_yen':100,
            'reason':str(b.get('reason') or ''),
        })
    n=len(bets)
    if not n:
        return {'bets':[],'stake_yen':0,'target_yen':1000,'rule':'100-200円/点・800-1200円/レース'}
    min_total=n*100
    max_total=n*200
    # Nearest feasible target to 1,000 yen, constrained to the user's band.
    low=max(800,min_total)
    high=min(1200,max_total)
    if low<=high:
        target=min(max(1000,low),high)
    else:
        # Current strategy normally has 6/8/10 points, so this is a defensive fallback.
        target=min(max_total,1200) if max_total<800 else max(min_total,800)
    extra=max(0,target-min_total)
    # Put 200 yen on the earlier/higher-priority lines first, 100 yen elsewhere.
    for b in bets:
        if extra>=100:
            b['stake_yen']=200
            extra-=100
    total=sum(int(b['stake_yen']) for b in bets)
    return {
        'bets':bets,
        'stake_yen':total,
        'target_yen':1000,
        'rule':'100-200円/点・800-1200円/レース',
    }

def capture_race(con, race_id, now=None, cache_dir='cache/live'):
    now=now or datetime.now(JST)
    row=con.execute('SELECT race_date,jcd,race_no,deadline FROM races WHERE race_id=?',(race_id,)).fetchone()
    if not row:return {'saved':False,'reason':'race_missing'}
    date,jcd,rno,deadline=row
    dl=parse_deadline(date,deadline)
    if not dl or dl<=now:return {'saved':False,'reason':'deadline_passed'}
    path=_db_path(con)
    if has_snapshot(path,race_id):return {'saved':False,'reason':'already_saved'}
    pr=predict_race(con,race_id,5)
    if pr.get('status')!='ok':return {'saved':False,'reason':'prediction_missing'}
    if pr.get('stage')!='final':return {'saved':False,'reason':'not_final'}
    payload={
        'race_id':race_id,'captured_at':now.isoformat(),'deadline_at':dl.isoformat(),
        'first_rank':pr.get('first_rank',[]),'predictions':pr.get('predictions',[]),
        'buy_plan':pr.get('buy_plan',{}),'virtual_plan':_virtual_investment_plan(pr),'weather':pr.get('weather'),
        'boat_scores':pr.get('boat_scores',[]),'exhibition_courses':pr.get('exhibition_courses',{}),
        'parse_status':pr.get('parse_status',{}),'f_risk':pr.get('f_risk',[]),
        'model_version':MODEL_VERSION
    }
    ok=save_snapshot(path,race_id=race_id,jcd=jcd,race_no=rno,captured_at=now,deadline_at=dl,stage='final',payload=payload)
    return {'saved':bool(ok),'race_id':race_id,'jcd':jcd,'race_no':rno,'deadline':dl.isoformat()}

def settle_pending(con, now=None, cache_dir='cache/live', grace_min=3):
    now=now or datetime.now(JST); path=_db_path(con)
    rows=unsettled(path,now-timedelta(minutes=grace_min))
    groups={}
    for rid,jcd,rno,deadline in rows:
        groups.setdefault(str(jcd).zfill(2),[]).append((rid,int(rno)))
    out=[]; errors=[]
    today=now.date().isoformat()
    for jcd,items in groups.items():
        try:
            results,_,_=fetch_resultlist(today,jcd,cache_dir)
            for rid,rno in items:
                item=results.get(rno)
                if not item or '返還' in (item.get('note') or ''):continue
                if settle(path,rid,item['combo'],item['payout'],now):
                    out.append({'race_id':rid,'combo':item['combo'],'payout':item['payout']})
        except Exception as e:
            errors.append({'jcd':jcd,'error':f'{type(e).__name__}: {e}'})
    return {'settled':out,'errors':errors}

def nationwide_tick(con, now=None, cache_dir='cache/live', capture_window_min=15, max_capture=6):
    '''One bounded validation cycle.
    1) discover/seed today's venues, 2) capture races within 0..capture_window_min,
    3) settle races already finished. No odds are read.
    '''
    now=now or datetime.now(JST)
    seeded,venue_errors=seed_today(con,now,cache_dir,selected_jcds=None)
    today=now.date().isoformat(); path=_db_path(con)
    rows=con.execute('''SELECT race_id,jcd,race_no,deadline FROM races WHERE race_date=? AND deadline IS NOT NULL ORDER BY deadline,jcd,race_no''',(today,)).fetchall()
    due=[]
    for rid,jcd,rno,deadline in rows:
        dl=parse_deadline(today,deadline)
        if not dl:continue
        mins=(dl-now).total_seconds()/60
        if 0 < mins <= capture_window_min and not has_snapshot(path,rid):
            due.append((mins,rid,jcd,rno))
    captured=[]; errors=[]
    for mins,rid,jcd,rno in due[:max_capture]:
        try:
            cnt=con.execute('SELECT COUNT(*) FROM entries WHERE race_id=?',(rid,)).fetchone()[0]
            if cnt<6: refresh_racelist(con,today,jcd,rno,cache_dir)
            refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir)
            captured.append(capture_race(con,rid,now,cache_dir))
        except Exception as e:
            errors.append({'race_id':rid,'jcd':jcd,'race_no':rno,'error':f'{type(e).__name__}: {e}'})
    settled=settle_pending(con,now,cache_dir)
    return {'generated_at':now.isoformat(),'model_version':MODEL_VERSION,'venues_found':len(seeded),
            'venue_errors':venue_errors,'due_count':len(due),'captured':captured,'capture_errors':errors,
            'settlement':settled,'metrics':metrics(path)}
