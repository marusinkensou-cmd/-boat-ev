# BOAT RACE EV Predictor v1.3 — iPhone実戦向け安全性強化

## 公式実ページで確認した項目
出走表:
- 登録番号/級
- F/L
- 平均ST
- 全国勝率/2連率/3連率
- 当地勝率/2連率/3連率
- モーターNo/2連率/3連率
- ボートNo/2連率/3連率

直前情報:
- 体重
- 展示タイム
- チルト
- プロペラ変更
- 部品交換
- スタート展示
- 展示進入
- 展示ST
- 気温
- 水温
- 風速
- 波高

## v1.3追加
- 展示進入コース
- 展示ST（Fは負値として保持）
- プロペラ変更
- 部品交換
- live_qualityによる取得品質管理

## iPhone画面
必要データが不足しているレースは、
S/A/B/C評価や舟券候補を出さず、

**データ不足**

と表示します。

推測で穴埋めして買い目を出さないことを優先しています。

## 利用構成
iPhone PWA → HTTPS → クラウド → 公式情報 → モデル/EV → iPhone

競艇場ではiPhoneのみを想定します。

## 残る工程
このチャット環境からユーザー名義のクラウドサービスへ公開URLを発行する権限はないため、
実公開だけは未実施です。

Dockerfile / render.yaml は同梱済みです。

## v1.6.1 fast one-venue mode
- Real-time refresh is intentionally limited to one selected venue and its nearest upcoming race.
- Odds are removed from the critical path and never affect prediction.
- Prediction is staged: first-place probability across six boats -> conditional second -> conditional third.
- The UI shows top first-place probabilities and actual exhibition-course order when available.

## v1.6.2
- 買い方提案: 混戦=上位3艇BOX、軸あり=1着軸＋3着広げ、最大10点を基本
- 自信度/混戦表示、100円基本・強条件のみ200円
- F持ちは注意表示（現段階では一律減点しない）
- 展示STが取得できれば直前予想へ移行し、展示タイム解析失敗だけで事前扱いにしない
- 締切後3分までカードを残す
- beforeinfo解析ログを追加
