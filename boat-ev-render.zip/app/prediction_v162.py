from __future__ import annotations
import math
from prediction_v161 import boat_scores, softmax, conditional_probs, staged_picks

def _confidence(first_rank, scores):
    ps=[x['prob'] for x in first_rank]
    if not ps:return {'label':'判定不能','stars':0,'type':'unknown','data_score':0}
    gap12=ps[0]-ps[1] if len(ps)>1 else ps[0]
    gap13=ps[0]-ps[2] if len(ps)>2 else ps[0]
    ex=sum(d.get('exhibition_st') is not None for d in scores)
    ext=sum(d.get('exhibition_time') is not None for d in scores)
    data=(ex+ext)/12
    if gap13<=.04: typ,label='mixed','混戦'
    elif gap12>=.10: typ,label='axis','軸あり'
    else: typ,label='balanced','やや混戦'
    stars=2 if typ=='mixed' else (4 if typ=='axis' else 3)
    if data<.5: stars=max(1,stars-1)
    return {'label':label,'stars':stars,'type':typ,'data_score':round(data,2),'gap12':round(gap12,4),'gap13':round(gap13,4)}

def _box3(boats):
    a,b,c=boats
    return [f'{x}{y}{z}' for x in boats for y in boats for z in boats if len({x,y,z})==3]

def _buy_plan(first_rank, scores, limit=10):
    boats=[x['boat'] for x in first_rank]
    probs={x['boat']:x['prob'] for x in first_rank}
    conf=_confidence(first_rank,scores)
    picks=[]; formations=[]
    def add(combo,reason):
        if combo not in [x['combination'] for x in picks] and len(picks)<limit:
            picks.append({'combination':combo,'stake_yen':100,'reason':reason})
    if conf['type']=='mixed':
        top=boats[:3]
        formations.append({'label':'混戦BOX','notation':''.join(map(str,top))+' BOX','points':6})
        for c in _box3(top): add(c,'1着上位3艇が接近')
        # 混戦は上位3艇BOXだけ。表示と購入判断を最短にする。
    elif conf['type']=='axis':
        a=boats[0]; b,c=boats[1],boats[2]
        formations.append({'label':'軸フォーメーション','notation':f'{a}-{b}{c}-全','points':8})
        for second in (b,c):
            for third in boats:
                if third not in (a,second): add(f'{a}{second}{third}','1着軸＋3着広げ')
        # 2着まで強い組合せの裏を少数押さえ
        for second in (b,c): add(f'{second}{a}{c if second==b else b}','軸崩れ押さえ')
    else:
        top=boats[:3]
        formations.append({'label':'上位3艇BOX','notation':''.join(map(str,top))+' BOX','points':6})
        for c in _box3(top): add(c,'上位3艇')
        if len(boats)>=4:
            for a in top[:2]: add(f'{a}{boats[3]}{top[0] if a!=top[0] else top[1]}','4番手押さえ')
    # 強く行く判定は厳しめ。現段階では条件を満たさなければ全て100円。
    strong=False
    if conf['type']=='axis' and conf['stars']>=4 and conf['data_score']>=.8 and probs[boats[0]]>=.40:
        strong=True
        for x in picks[:2]: x['stake_yen']=200
    total=sum(x['stake_yen'] for x in picks)
    return {'confidence':conf,'formations':formations,'bets':picks,'bet_count':len(picks),'stake_yen':total,'strong':strong}

def predict_race(con,rid,topn=5):
    scores=boat_scores(con,rid)
    if not scores:return {'status':'data_missing','predictions':[]}
    first,picks=staged_picks(scores,limit=topn)
    first_rank=[{'boat':b,'prob':first[b]} for b in sorted(first,key=first.get,reverse=True)]
    wx=con.execute('SELECT weather,air_temp_c,water_temp_c,wind_speed_m,wave_height_cm FROM race_weather WHERE race_id=?',(rid,)).fetchone()
    # 展示STが4艇以上取れていれば直前情報は取得済みとみなす。展示タイム解析失敗だけで事前予想に戻さない。
    exst_count=sum(d.get('exhibition_st') is not None for d in scores)
    ext_count=sum(d.get('exhibition_time') is not None for d in scores)
    stage='final' if exst_count>=4 and wx else 'preliminary'
    topboat=first_rank[0]['boat'] if first_rank else None
    bd=next((x for x in scores if x['boat']==topboat),None)
    reasons=[]
    if bd: reasons=[k for k,v in sorted(bd['components'].items(),key=lambda kv:kv[1],reverse=True) if v>0][:5]
    weather=None if not wx else {'weather':wx[0],'air_temp_c':wx[1],'water_temp_c':wx[2],'wind_speed_m':wx[3],'wave_height_cm':wx[4]}
    courses={str(d['boat']):d.get('actual_course') for d in scores}
    # Fは現時点では一律減点しない。リスク表示に使い、今後コメント/STとの相互作用で学習する。
    frows=con.execute('SELECT boat_no,COALESCE(f_count,0) FROM entries WHERE race_id=? ORDER BY boat_no',(rid,)).fetchall()
    f_risk=[{'boat':int(b),'f_count':int(f or 0)} for b,f in frows if int(f or 0)>0]
    plan=_buy_plan(first_rank,scores,10)
    return {'status':'ok','stage':stage,'predictions':picks,'first_rank':first_rank,'weather':weather,
            'boat_scores':scores,'reasons':reasons,'exhibition_courses':courses,'f_risk':f_risk,
            'buy_plan':plan,'parse_status':{'exhibition_st_count':exst_count,'exhibition_time_count':ext_count}}
