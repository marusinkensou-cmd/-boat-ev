const CACHE="boat-ev-v146";
const ASSETS=["/","/app.js","/manifest.webmanifest","/apple-touch-icon.png","/icon-512.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{
  if(e.request.url.includes("/api/")) return;
  e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});
