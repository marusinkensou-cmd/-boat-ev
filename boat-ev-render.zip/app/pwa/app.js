const VENUES={
"01":"桐生","02":"戸田","03":"江戸川","04":"平和島","05":"多摩川","06":"浜名湖",
"07":"蒲郡","08":"常滑","09":"津","10":"三国","11":"びわこ","12":"住之江",
"13":"尼崎","14":"鳴門","15":"丸亀","16":"児島","17":"宮島","18":"徳山",
"19":"下関","20":"若松","21":"芦屋","22":"福岡","23":"唐津","24":"大村"
};
let SELECTED_JCDS=new Set(JSON.parse(localStorage.getItem("selected_jcds")||"[]"));
const LAST_SELECTED_KEY="selected_jcds";

function saveVenueSelection(){
  localStorage.setItem("selected_jcds",JSON.stringify([...SELECTED_JCDS]));
}
function venueAllowed(r){
  return SELECTED_JCDS.size===0 || SELECTED_JCDS.has(String(r.jcd).padStart(2,"0"));
}
function venueSummaryText(){
  if(SELECTED_JCDS.size===0) return "場を1つ選択";
  const names=[...SELECTED_JCDS].map(j=>VENUES[j]).filter(Boolean);
  return names.length<=3?names.join("・"):`${names.slice(0,2).join("・")}ほか${names.length-2}場`;
}
function renderVenuePicker(){
  const grid=document.getElementById("venueGrid");
  if(!grid) return;
  grid.innerHTML=Object.entries(VENUES).map(([j,name])=>
    `<button class="venueBtn ${SELECTED_JCDS.has(j)?"selected":""}" data-jcd="${j}">${name}</button>`
  ).join("");
  document.getElementById("venueSummary").textContent=venueSummaryText();
  grid.querySelectorAll("[data-jcd]").forEach(b=>b.addEventListener("click",()=>{
    const j=b.dataset.jcd;
    SELECTED_JCDS.clear(); SELECTED_JCDS.add(j);
    saveVenueSelection(); renderVenuePicker(); render();
  }));
}
let DATA=[]; let FILTER="all";

function fmtPct(v){ return (v*100).toFixed(1)+"%"; }
function esc(s){ return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m])); }
function yen(v){ return "¥"+Number(v||0).toLocaleString("ja-JP"); }
function visible(r){
  if(r.minutes_to_deadline < -3 || r.minutes_to_deadline > 60) return false;
  if(!venueAllowed(r)) return false;
  if(FILTER==="all") return true;
  if(FILTER==="buy") return r.grade!=="PASS";
  if(FILTER==="pass") return r.grade==="PASS";
  if(FILTER==="buy") return r.prediction_state==="FINAL";
  if(FILTER==="pass") return r.prediction_state==="PRE";
  return true;
}

function render(){
  const rows=DATA.filter(visible);
  const active=DATA.filter(r=>venueAllowed(r) && r.minutes_to_deadline>=0 && r.minutes_to_deadline<=60);
  document.getElementById("buyCount").textContent=active.filter(r=>r.prediction_state==="FINAL").length;
  document.getElementById("passCount").textContent=active.filter(r=>r.prediction_state==="PRE").length;
  document.getElementById("nextMin").textContent=active.length?Math.max(0,Math.round(active[0].minutes_to_deadline)):"-";
  if(!rows.length){document.getElementById("list").innerHTML='<div class="empty">現在、表示できるレースはありません。<br>開催時間帯に「最新に更新」を押してください。</div>';return;}
  document.getElementById("list").innerHTML=rows.map(r=>{
    const missing=r.prediction_state==="DATA";
    const mins=r.minutes_to_deadline>=0?`締切まで ${Math.round(r.minutes_to_deadline)}分`:`締切 ${Math.abs(Math.round(r.minutes_to_deadline))}分経過`;
    const stage=missing?"データ不足":(r.prediction_state==="FINAL"?"直前予想":"事前予想");
    const best=missing?`データ不足<small>選手・モーター等の必要情報を取得中</small>`:"";
    const reasons=(r.reasons||[]).length?`<div class="why">主な根拠：${r.reasons.map(esc).join("・")}</div>`:"";
    const weather=r.weather?`<div class="why">現在：${esc(r.weather.weather||"")} 風${r.weather.wind_speed_m??"-"}m / 波${r.weather.wave_height_cm??"-"}cm / 水温${r.weather.water_temp_c??"-"}℃</div>`:"";
    const first=(r.first_rank||[]).slice(0,3).map((x,i)=>`${i+1}位 ${x.boat}号艇 ${fmtPct(x.prob)}`).join(" / ");
    const crs=r.exhibition_courses||{};
    const order=Object.entries(crs).filter(([b,c])=>c).sort((a,b)=>a[1]-b[1]).map(([b])=>b).join("-");
    const firstLine=first?`<div class="why"><b>1着予測：</b>${first}</div>`:"";
    const courseLine=order?`<div class="why"><b>展示進入：</b>${esc(order)}</div>`:"";
    const plan=r.buy_plan||{};
    const cf=plan.confidence||{};
    const stars=cf.stars?"★".repeat(cf.stars)+"☆".repeat(5-cf.stars):"";
    const confLine=cf.label?`<div class="decision"><b>${esc(cf.label)} ${stars}</b><span>${plan.bet_count||0}点 / ${yen(plan.stake_yen||0)}</span></div>`:"";
    const formLine=(plan.formations||[]).map((f,i)=>`<div class="formation"><span>${i===0?"本線":esc(f.label)}</span><b>${esc(f.notation)}</b><small>${f.points||plan.bet_count||0}点 / ${yen((f.points||plan.bet_count||0)*100)}</small></div>`).join("");
    const risk=(r.f_risk||[]).length?`<div class="risk">F注意：${r.f_risk.map(x=>`${x.boat}号艇 F${x.f_count}`).join(" / ")}</div>`:"";
    const bets=(plan.bets||[]).slice(0,10).map((b,i)=>`<div class="bet"><div class="combo">${esc(b.combination)}</div><span>${esc(b.reason||"")}</span><strong>${yen(b.stake_yen||100)}</strong></div>`).join("");
    return `<section class="card"><div class="cardhead"><div><span class="venue">${esc(r.venue)}</span><span class="race">${r.race_no}R</span><div class="deadline">${mins}</div></div><div class="badge ${esc(r.prediction_state||"PRE")}">${stage}</div></div>${best?`<div class="best">${best}</div>`:""}${firstLine}${courseLine}${reasons}${weather}${risk}${confLine}${formLine}${bets}</section>`;
  }).join("");
}

function renderStats(payload){
  const t=payload?.today||{}; const a=payload?.all||{};
  document.getElementById("paperRaces").textContent=t.settled_races||0;
  document.getElementById("paperStake").textContent=yen(t.stake_yen);
  document.getElementById("paperReturn").textContent=yen(t.return_yen);
  document.getElementById("paperRate").textContent=t.recovery_rate==null?"-":Number(t.recovery_rate).toFixed(1)+"%";
  document.getElementById("paperAll").textContent=a.stake_yen?`累計 ${a.settled_races}R / 投資 ${yen(a.stake_yen)} / 払戻 ${yen(a.return_yen)} / 回収率 ${Number(a.recovery_rate).toFixed(1)}% / 収支 ${a.profit_yen>=0?"+":""}${yen(a.profit_yen).replace("¥","")}円`:`累計データなし — 今日から自動記録します`;
}
async function fetchStats(){
  const res=await fetch("/api/stats",{cache:"no-store"});
  if(res.ok) renderStats(await res.json());
}
async function fetchBoard(){
  const res=await fetch("/api/board",{cache:"no-store"});
  if(!res.ok){
    let msg="HTTP "+res.status;
    try{const e=await res.json(); if(e?.error) msg=`${e.type||"Error"}: ${e.error}`;}catch(_){}
    throw new Error(msg);
  }
  const payload=await res.json(); DATA=payload.board||[];
  document.getElementById("updated").textContent="更新 "+new Date(payload.generated_at).toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit"}); render();
}
async function refreshLive(){
  const btn=document.getElementById("refresh");
  if(btn.disabled) return;
  if(SELECTED_JCDS.size!==1){
    document.getElementById("updated").textContent="場を1つ選択してください";
    document.getElementById("venuePicker").open=true;
    return;
  }
  btn.disabled=true;

  const stageText=(st)=>{
    const sec=st.elapsed_sec||0;
    if(st.stage==="starting") return `更新開始 ${sec}秒`;
    if(st.stage==="settlement") return `結果確認中 ${sec}秒`;
    if(st.stage==="discovering") return `全国の開催場を確認中 ${sec}秒`;
    if(st.stage==="seeded") return `${st.venues_found||0}場を確認 / ${sec}秒`;
    if(st.stage==="selected") return `更新対象 ${st.races_total||0}R・${st.venues_found||0}/${st.venues_requested||SELECTED_JCDS.size||0}場 / ${sec}秒`;
    if(st.stage==="race_start" || st.stage==="race_done")
      return `展示・水面情報 ${st.race_index||0}/${st.races_total||0}R / ${sec}秒`;
    if(st.stage==="building_board") return `解析中 / ${sec}秒`;
    return `更新中 ${sec}秒`;
  };

  try{
    const startRes=await fetch("/api/refresh",{
      method:"POST",
      cache:"no-store",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({selected_jcds:[...SELECTED_JCDS]})
    });
    if(!startRes.ok){
      let msg="HTTP "+startRes.status;
      try{const e=await startRes.json(); if(e?.error) msg=e.error;}catch(_){}
      throw new Error(msg);
    }

    document.getElementById("updated").textContent="更新開始";
    let finished=false;

    while(!finished){
      await new Promise(r=>setTimeout(r,2000));
      const res=await fetch("/api/refresh-status",{cache:"no-store"});
      if(!res.ok) throw new Error("進捗確認に失敗しました");
      const st=await res.json();

      btn.textContent=`更新中 ${st.elapsed_sec||0}秒`;
      document.getElementById("updated").textContent=stageText(st);

      try{await fetchBoard();}catch(_){}

      if(st.stage==="error"){
        throw new Error(st.error||"更新処理でエラーが発生しました");
      }
      if(!st.running && st.stage==="done"){
        finished=true;
        document.getElementById("updated").textContent=
          `更新完了 ${st.races_updated||0}R / ${st.venues_found||0}場 / ${st.elapsed_sec||0}秒`;
      }
    }

    try{await fetchStats();}catch(_){}
  }catch(e){
    document.getElementById("updated").textContent=`更新失敗：${e.message}`;
    render();
  }finally{
    btn.disabled=false;
    btn.textContent="最新に更新";
  }
}
async function load(){
  try{
    await fetchBoard();
    try{await fetchStats();}catch(e){console.warn("stats load failed",e);}
  }catch(e){
    document.getElementById("updated").textContent="更新失敗";
    document.getElementById("list").innerHTML='<div class="error">データを取得できませんでした。<br>'+esc(e.message)+'</div>';
  }
}
document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll("[data-filter]").forEach(x=>x.classList.remove("active"));b.classList.add("active");FILTER=b.dataset.filter;render();}));
document.getElementById("venueAll").addEventListener("click",()=>{
  SELECTED_JCDS.clear(); saveVenueSelection(); renderVenuePicker(); render();
});
document.getElementById("venueClear").addEventListener("click",()=>{
  SELECTED_JCDS.clear(); saveVenueSelection(); renderVenuePicker(); render();
});
renderVenuePicker();
document.getElementById("refresh").addEventListener("click",refreshLive);
if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js?v=162").catch(()=>{});
load();
