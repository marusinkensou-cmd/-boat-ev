let DATA=[]; let FILTER="all";

function fmtPct(v){ return (v*100).toFixed(1)+"%"; }
function esc(s){ return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m])); }

function visible(r){
  if(FILTER==="all") return true;
  if(FILTER==="buy") return r.grade!=="PASS";
  if(FILTER==="pass") return r.grade==="PASS";
  return r.grade===FILTER;
}

function render(){
  const rows=DATA.filter(visible);
  document.getElementById("buyCount").textContent=DATA.filter(r=>r.grade!=="PASS").length;
  document.getElementById("passCount").textContent=DATA.filter(r=>r.grade==="PASS").length;
  const future=DATA.filter(r=>r.minutes_to_deadline>=0);
  document.getElementById("nextMin").textContent=future.length?Math.max(0,Math.round(future[0].minutes_to_deadline)):"-";

  if(!rows.length){
    document.getElementById("list").innerHTML='<div class="empty">該当レースはありません。</div>'; return;
  }
  document.getElementById("list").innerHTML=rows.map(r=>{
    const dataMissing=r.grade==="DATA";
    const passed=r.grade==="PASS" || dataMissing;
    const mins=r.minutes_to_deadline>=0?`締切まで ${Math.round(r.minutes_to_deadline)}分`:`締切 ${Math.abs(Math.round(r.minutes_to_deadline))}分経過`;
    const best=dataMissing?`データ不足<small>出走表またはオッズ未取得のため判定しません</small>`:
      passed?`見送り<small>EV条件を満たす買い目なし</small>`:
      `${esc(r.best_combo)} <small>EV ${Number(r.best_ev).toFixed(2)} / ${Number(r.best_odds).toFixed(1)}倍 / 予測 ${fmtPct(r.best_prob)}</small>`;
    const bets=(r.bets||[]).slice(0,6).map(b=>`
      <div class="bet">
        <div class="combo">${esc(b.combination)}</div>
        <span>予測<br>${fmtPct(b.predicted_prob)}</span>
        <span>適正<br>${Number(b.fair_odds).toFixed(1)}倍</span>
        <strong>EV ${Number(b.ev).toFixed(2)}<br>${Number(b.market_odds).toFixed(1)}倍</strong>
      </div>`).join("");
    return `<section class="card ${passed?"pass":""}">
      <div class="cardhead">
        <div><span class="venue">${esc(r.venue)}</span><span class="race">${r.race_no}R</span><div class="deadline">${mins}</div></div>
        <div class="badge ${esc(r.grade)}">${dataMissing?"データ不足":passed?"見送り":esc(r.grade)+"評価"}</div>
      </div>
      <div class="best">${best}</div>${bets}
    </section>`;
  }).join("");
}

async function fetchBoard(){
  const res=await fetch("/api/board",{cache:"no-store"});
  if(!res.ok) throw new Error("HTTP "+res.status);
  const payload=await res.json();
  DATA=payload.board||[];
  document.getElementById("updated").textContent="更新 "+new Date(payload.generated_at).toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit"});
  render();
}
async function refreshLive(){
  const btn=document.getElementById("refresh");btn.disabled=true;btn.textContent="取得中…";
  document.getElementById("updated").textContent="公式データ更新中";
  try{
    const res=await fetch("/api/refresh",{method:"POST",cache:"no-store"});
    if(!res.ok) throw new Error("HTTP "+res.status);
    const payload=await res.json();
    DATA=payload.board||[];
    document.getElementById("updated").textContent=`${payload.venues_found||0}場 / ${payload.races_updated||0}R更新`;
    render();
  }catch(e){
    document.getElementById("updated").textContent="更新失敗";
    document.getElementById("list").innerHTML='<div class="error">最新情報を取得できませんでした。<br>'+esc(e.message)+'</div>';
  }finally{btn.disabled=false;btn.textContent="最新に更新";}
}
async function load(){
  try{await fetchBoard();}
  catch(e){document.getElementById("list").innerHTML='<div class="error">データを取得できませんでした。<br>'+esc(e.message)+'</div>';}
}

document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll("[data-filter]").forEach(x=>x.classList.remove("active"));
  b.classList.add("active"); FILTER=b.dataset.filter; render();
}));
document.getElementById("refresh").addEventListener("click",refreshLive);
if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
load();