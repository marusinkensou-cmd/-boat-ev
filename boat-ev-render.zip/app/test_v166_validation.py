import os,sqlite3,tempfile,json
from pathlib import Path
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
from parse_bk import ensure_schema
from validation_store_v166 import ensure_validation_schema,save_snapshot,settle,metrics

JST=ZoneInfo('Asia/Tokyo')
fd,path=tempfile.mkstemp(suffix='.sqlite'); os.close(fd)
try:
    con=sqlite3.connect(path); ensure_schema(con,Path(__file__).with_name('schema.sql')); con.close()
    ensure_validation_schema(path)
    now=datetime.now(JST); dl=now+timedelta(minutes=10)
    payload={
      'first_rank':[{'boat':1,'prob':.4},{'boat':4,'prob':.2},{'boat':5,'prob':.15}],
      'buy_plan':{'confidence':{'type':'balanced'},'bets':[{'combination':'145','stake_yen':100,'reason':'上位3艇'},{'combination':'154','stake_yen':100,'reason':'4番手押さえ'}],'stake_yen':200}
    }
    assert save_snapshot(path,race_id='T-01-01',jcd='01',race_no=1,captured_at=now,deadline_at=dl,stage='final',payload=payload)
    assert not save_snapshot(path,race_id='T-01-01',jcd='01',race_no=1,captured_at=now,deadline_at=dl,stage='final',payload=payload)
    assert settle(path,'T-01-01','154',28340,now+timedelta(minutes=20))
    m=metrics(path)
    assert m['snapshots']==1 and m['settled']==1
    assert m['first_pick_hit_rate']==1.0 and m['buy_hit_rate']==1.0 and m['cover_rescue_rate']==1.0
    print('v1.6.6 validation store: OK')
finally:
    try: os.unlink(path)
    except FileNotFoundError: pass
