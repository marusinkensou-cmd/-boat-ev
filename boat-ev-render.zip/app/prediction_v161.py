from __future__ import annotations
import math

COURSE_PRIOR={1:1.00,2:.66,3:.60,4:.55,5:.42,6:.31}
CLASS_SCORE={"A1":1.0,"A2":.78,"B1":.55,"B2":.38}

def clamp(x,a=0.0,b=1.0): return max(a,min(b,x))
def norm_win(v): return .5 if v is None else clamp((float(v)-2.0)/7.0)
def norm_pct(v): return .5 if v is None else clamp(float(v)/60.0)
def norm_st(v): return .5 if v is None else clamp((.30-float(v))/.22)

def _relative_good(values, boat, lower_is_better=False):
    vals=[float(v) for v in values.values() if v is not None]
    if len(vals)<3 or values.get(boat) is None:return .5
    lo,hi=min(vals),max(vals)
    if hi-lo<1e-9:return .5
    x=(float(values[boat])-lo)/(hi-lo)
    return 1.0-x if lower_is_better else x

def venue_course_adjust(con,rid,course):
    row=con.execute("""SELECT rc.jcd,w.wind_speed_m,w.wave_height_cm
        FROM races rc LEFT JOIN race_weather w ON w.race_id=rc.race_id WHERE rc.race_id=?""",(rid,)).fetchone()
    if not row:return 0.0,0
    jcd,wind,wave=row
    def wb(v):
        if v is None:return "unknown"
        if v<2:return "0-1"
        if v<4:return "2-3"
        if v<6:return "4-5"
        return "6+"
    def vb(v):
        if v is None:return "unknown"
        if v<=2:return "0-2"
        if v<=5:return "3-5"
        if v<=10:return "6-10"
        return "11+"
    s=con.execute("""SELECT starts,win_rate FROM venue_condition_stats
        WHERE jcd=? AND course=? AND wind_bucket=? AND wave_bucket=?""",
        (jcd,course,wb(wind),vb(wave))).fetchone()
    if not s or int(s[0] or 0)<30:return 0.0,int(s[0] or 0) if s else 0
    prior={1:.55,2:.15,3:.12,4:.10,5:.05,6:.03}.get(course,.10)
    return clamp((float(s[1])-prior)*.35,-.05,.05),int(s[0])

def boat_scores(con,rid):
    rows=con.execute("""SELECT e.boat_no,e.racer_no,e.class,e.national_win_rate,e.local_win_rate,e.avg_st,
        e.motor_quinella_rate,e.boat_quinella_rate,b.exhibition_time,b.exhibition_st,b.exhibition_course
        FROM entries e LEFT JOIN beforeinfo b ON b.race_id=e.race_id AND b.boat_no=e.boat_no
        WHERE e.race_id=? ORDER BY e.boat_no""",(rid,)).fetchall()
    if len(rows)!=6:return None
    ex_time={r[0]:r[8] for r in rows}; ex_st={r[0]:r[9] for r in rows}
    has_ex=sum(v is not None for v in ex_time.values())>=4
    has_exst=sum(v is not None for v in ex_st.values())>=4
    out=[]
    for r in rows:
        boat,racer,clazz,nat,local,avgst,motor,hull,ext,exst,excourse=r
        actual_course=int(excourse or boat)
        # Pure racing-strength score. Odds are never read here.
        c_nat=.22*norm_win(nat); c_local=.22*norm_win(local); c_course=.18*COURSE_PRIOR.get(actual_course,.5)
        c_motor=.15*norm_pct(motor); c_st=.09*norm_st(avgst); c_hull=.05*norm_pct(hull); c_class=.05*CLASS_SCORE.get(clazz,.5)
        s=c_nat+c_local+c_course+c_motor+c_st+c_hull+c_class
        comp={"全国勝率":c_nat,"当地勝率":c_local,"進入コース":c_course,"モーター":c_motor,
              "平均ST":c_st,"ボート":c_hull,"級別":c_class}
        if has_ex:
            v=.09*_relative_good(ex_time,boat,True); s+=v; comp["展示タイム"]=v
        if has_exst:
            v=.05*_relative_good(ex_st,boat,True); s+=v; comp["展示ST"]=v
        vadj,n=venue_course_adjust(con,rid,actual_course); s+=vadj; comp["場×水面傾向"]=vadj
        out.append({"boat":boat,"racer_no":racer,"score":s,"components":comp,"venue_samples":n,
                    "local_win_rate":local,"national_win_rate":nat,"motor_rate":motor,"avg_st":avgst,
                    "exhibition_time":ext,"exhibition_st":exst,"exhibition_course":excourse,
                    "actual_course":actual_course})
    return out

def softmax(items, key="score", temperature=4.2):
    vals={d["boat"]:math.exp(float(d[key])*temperature) for d in items}
    den=sum(vals.values()) or 1.0
    return {k:v/den for k,v in vals.items()}

def _place_score(d, place):
    # 2/3着は1着力を土台にしつつ、極端なコース先行補正を少し弱める。
    course_component=d["components"].get("進入コース",0.0)
    base=d["score"]
    if place==2:return base-course_component*.20
    return base-course_component*.30

def conditional_probs(scores, excluded, place):
    pool=[]
    for d in scores:
        if d["boat"] in excluded:continue
        q=dict(d); q["place_score"]=_place_score(d,place); pool.append(q)
    return softmax(pool,"place_score",3.8)

def staged_picks(scores, top_first=2, top_second=2, top_third=2, limit=5):
    first=softmax(scores,"score",4.2)
    first_order=sorted(first,key=first.get,reverse=True)[:top_first]
    candidates=[]
    for a in first_order:
        p2=conditional_probs(scores,{a},2)
        for b in sorted(p2,key=p2.get,reverse=True)[:top_second]:
            p3=conditional_probs(scores,{a,b},3)
            for c in sorted(p3,key=p3.get,reverse=True)[:top_third]:
                candidates.append({"combination":f"{a}{b}{c}","first_prob":first[a],
                                   "second_cond_prob":p2[b],"third_cond_prob":p3[c],
                                   "predicted_prob":first[a]*p2[b]*p3[c]})
    candidates.sort(key=lambda x:x["predicted_prob"],reverse=True)
    return first,candidates[:limit]

def predict_race(con,rid,topn=5):
    scores=boat_scores(con,rid)
    if not scores:return {"status":"data_missing","predictions":[]}
    first,picks=staged_picks(scores,limit=topn)
    first_rank=[{"boat":b,"prob":first[b]} for b in sorted(first,key=first.get,reverse=True)]
    wx=con.execute("SELECT weather,air_temp_c,water_temp_c,wind_speed_m,wave_height_cm FROM race_weather WHERE race_id=?",(rid,)).fetchone()
    before_count=con.execute("SELECT COUNT(*) FROM beforeinfo WHERE race_id=? AND exhibition_time IS NOT NULL",(rid,)).fetchone()[0]
    stage="final" if before_count>=4 and wx else "preliminary"
    topboat=first_rank[0]["boat"] if first_rank else None
    bd=next((x for x in scores if x["boat"]==topboat),None)
    reasons=[]
    if bd:
        reasons=[k for k,v in sorted(bd["components"].items(),key=lambda kv:kv[1],reverse=True) if v>0][:5]
    weather=None if not wx else {"weather":wx[0],"air_temp_c":wx[1],"water_temp_c":wx[2],"wind_speed_m":wx[3],"wave_height_cm":wx[4]}
    courses={str(d["boat"]):d.get("actual_course") for d in scores}
    return {"status":"ok","stage":stage,"predictions":picks,"first_rank":first_rank,
            "weather":weather,"boat_scores":scores,"reasons":reasons,"exhibition_courses":courses}
