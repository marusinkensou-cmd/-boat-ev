from __future__ import annotations
import math
from itertools import permutations

COURSE_PRIOR={1:1.00,2:.66,3:.60,4:.55,5:.42,6:.31}
CLASS_SCORE={"A1":1.0,"A2":.78,"B1":.55,"B2":.38}

def clamp(x,a=0.0,b=1.0):
    return max(a,min(b,x))

def norm_win(v):
    return .5 if v is None else clamp((float(v)-2.0)/7.0)

def norm_pct(v):
    return .5 if v is None else clamp(float(v)/60.0)

def norm_st(v):
    return .5 if v is None else clamp((.30-float(v))/.22)

def venue_course_adjust(con,rid,course):
    """Use actual venue/course/weather history only when enough historical samples exist."""
    row=con.execute("""SELECT rc.jcd,w.wind_speed_m,w.wave_height_cm
        FROM races rc LEFT JOIN race_weather w ON w.race_id=rc.race_id WHERE rc.race_id=?""",(rid,)).fetchone()
    if not row: return 0.0,0
    jcd,wind,wave=row
    def wb(v):
        if v is None:return "unknown"
        if v<2:return "0-1"
        if v<4:return "2-3"
        if v<6:return "4-5"
        return "6+"
    def vb(v):
        if v is None:return "unknown"
        if v<=2:return "0-2"
        if v<=5:return "3-5"
        if v<=10:return "6-10"
        return "11+"
    s=con.execute("""SELECT starts,win_rate FROM venue_condition_stats
        WHERE jcd=? AND course=? AND wind_bucket=? AND wave_bucket=?""",
        (jcd,course,wb(wind),vb(wave))).fetchone()
    if not s or int(s[0] or 0)<30:return 0.0,int(s[0] or 0) if s else 0
    prior={1:.55,2:.15,3:.12,4:.10,5:.05,6:.03}.get(course,.10)
    return clamp((float(s[1])-prior)*.35,-.05,.05),int(s[0])

def _relative_good(values, boat, lower_is_better=False):
    vals=[float(v) for v in values.values() if v is not None]
    if len(vals)<3 or values.get(boat) is None:return .5
    lo,hi=min(vals),max(vals)
    if hi-lo<1e-9:return .5
    x=(float(values[boat])-lo)/(hi-lo)
    return 1.0-x if lower_is_better else x

def boat_scores(con,rid):
    rows=con.execute("""SELECT e.boat_no,e.racer_no,e.class,e.national_win_rate,e.local_win_rate,e.avg_st,
        e.motor_quinella_rate,e.boat_quinella_rate,b.exhibition_time,b.exhibition_st,b.exhibition_course
        FROM entries e LEFT JOIN beforeinfo b ON b.race_id=e.race_id AND b.boat_no=e.boat_no
        WHERE e.race_id=? ORDER BY e.boat_no""",(rid,)).fetchall()
    if len(rows)!=6:return None
    ex_time={r[0]:r[8] for r in rows}; ex_st={r[0]:r[9] for r in rows}
    has_ex=sum(v is not None for v in ex_time.values())>=4
    has_exst=sum(v is not None for v in ex_st.values())>=4
    out=[]
    for r in rows:
        boat,racer,clazz,nat,local,avgst,motor,hull,ext,exst,excourse=r
        # Odds are intentionally absent. Local win rate is weighted heavily: it is
        # the racer's historical performance at this specific venue.
        s=(.20*norm_win(nat)+.20*norm_win(local)+.16*COURSE_PRIOR.get(int(excourse or boat),.5)+
           .14*norm_pct(motor)+.08*norm_st(avgst)+.05*norm_pct(hull)+.05*CLASS_SCORE.get(clazz,.5))
        components={"全国勝率":.20*norm_win(nat),"当地勝率":.20*norm_win(local),
                    "コース":.16*COURSE_PRIOR.get(int(excourse or boat),.5),"モーター":.14*norm_pct(motor),
                    "平均ST":.08*norm_st(avgst),"ボート":.05*norm_pct(hull),"級別":.05*CLASS_SCORE.get(clazz,.5)}
        if has_ex:
            v=.08*_relative_good(ex_time,boat,True); s+=v; components["展示タイム"]=v
        if has_exst:
            v=.04*_relative_good(ex_st,boat,True); s+=v; components["展示ST"]=v
        vadj,n=venue_course_adjust(con,rid,int(excourse or boat)); s+=vadj
        components["場×天候傾向"]=vadj
        out.append({"boat":boat,"racer_no":racer,"score":s,"components":components,"venue_samples":n,
                    "local_win_rate":local,"national_win_rate":nat,"motor_rate":motor,
                    "avg_st":avgst,"exhibition_time":ext,"exhibition_st":exst,"exhibition_course":excourse})
    return out

def trifecta_probs(scores):
    # modest temperature avoids exaggerated certainty from small score differences
    x={d["boat"]:math.exp(d["score"]*4.0) for d in scores}
    total=sum(x.values()); out={}
    for a,b,c in permutations(x,3):
        p1=x[a]/total
        p2=x[b]/sum(v for k,v in x.items() if k!=a)
        p3=x[c]/sum(v for k,v in x.items() if k not in (a,b))
        out[f"{a}{b}{c}"]=p1*p2*p3
    return out

def latest_odds(con,rid):
    row=con.execute("SELECT snapshot_id,fetched_at FROM odds_snapshots WHERE race_id=? ORDER BY fetched_at DESC LIMIT 1",(rid,)).fetchone()
    if not row:return None,{}
    sid,at=row
    mp={f"{a}{b}{c}":od for a,b,c,od in con.execute(
        "SELECT first_boat,second_boat,third_boat,odds FROM odds_trifecta WHERE snapshot_id=?",(sid,))}
    return at,mp

def predict_race(con,rid,topn=5):
    scores=boat_scores(con,rid)
    if not scores:return {"status":"data_missing","predictions":[]}
    probs=trifecta_probs(scores)
    odds_at,odds=latest_odds(con,rid)
    picks=[]
    for rank,(combo,p) in enumerate(sorted(probs.items(),key=lambda x:x[1],reverse=True)[:topn],1):
        picks.append({"rank":rank,"combination":combo,"predicted_prob":p,"market_odds":odds.get(combo)})
    wx=con.execute("SELECT weather,air_temp_c,water_temp_c,wind_speed_m,wave_height_cm FROM race_weather WHERE race_id=?",(rid,)).fetchone()
    before_count=con.execute("SELECT COUNT(*) FROM beforeinfo WHERE race_id=? AND exhibition_time IS NOT NULL",(rid,)).fetchone()[0]
    stage="final" if before_count>=4 and wx else "preliminary"
    # Explain top first-place boat using its strongest positive inputs.
    topboat=int(picks[0]["combination"][0]) if picks else None
    bd=next((x for x in scores if x["boat"]==topboat),None)
    reasons=[]
    if bd:
        labels=sorted(bd["components"].items(),key=lambda kv:kv[1],reverse=True)
        reasons=[k for k,v in labels if v>0][:4]
    weather=None if not wx else {"weather":wx[0],"air_temp_c":wx[1],"water_temp_c":wx[2],"wind_speed_m":wx[3],"wave_height_cm":wx[4]}
    return {"status":"ok","stage":stage,"predictions":picks,"odds_captured_at":odds_at,
            "weather":weather,"boat_scores":scores,"reasons":reasons}
