from __future__ import annotations
import argparse,sqlite3,json
from datetime import datetime
from zoneinfo import ZoneInfo
from prediction_v161 import predict_race
JST=ZoneInfo("Asia/Tokyo")

def parse_deadline(race_date,deadline):
    if not deadline:return None
    s=str(deadline).strip()
    try:
        if "T" in s:
            dt=datetime.fromisoformat(s); return dt if dt.tzinfo else dt.replace(tzinfo=JST)
        p=s.split(":"); hh=int(p[0]); mm=int(p[1]); ss=int(p[2]) if len(p)>2 else 0
        y,m,d=map(int,race_date.split("-")); return datetime(y,m,d,hh,mm,ss,tzinfo=JST)
    except:return None

def build_board(con,now=None,model="P160",window_before_min=3,window_after_min=240):
    now=now or datetime.now(JST)
    if now.tzinfo is None:now=now.replace(tzinfo=JST)
    today=now.date().isoformat()
    rows=con.execute("""SELECT r.race_id,r.race_date,r.jcd,r.race_no,r.deadline,r.status,COALESCE(s.name,r.jcd)
        FROM races r LEFT JOIN stadiums s ON s.jcd=r.jcd WHERE r.race_date=? ORDER BY r.deadline,r.jcd,r.race_no""",(today,)).fetchall()
    out=[]
    for rid,rdate,jcd,rno,deadline,status,venue in rows:
        dl=parse_deadline(rdate,deadline)
        if not dl:continue
        mins=(dl-now).total_seconds()/60
        if mins < -window_before_min or mins > window_after_min:continue
        pr=predict_race(con,rid,5)
        preds=pr.get("predictions",[])
        state="DATA" if pr.get("status")!="ok" else ("FINAL" if pr.get("stage")=="final" else "PRE")
        out.append({"race_id":rid,"venue":venue,"jcd":jcd,"race_no":rno,"deadline":dl.isoformat(),
          "minutes_to_deadline":round(mins,1),"race_status":status,"prediction_state":state,
          "prediction_label":"直前予想" if state=="FINAL" else ("事前予想" if state=="PRE" else "データ不足"),
          "grade":state,"decision":"prediction","decision_state":state,"decision_label":"予想",
          "best_combo":preds[0]["combination"] if preds else None,
          "best_prob":round(preds[0]["predicted_prob"],4) if preds else None,
          "bets":preds,"predictions":preds,"bet_count":len(preds),"best_ev":None,
          "weather":pr.get("weather"),"first_rank":pr.get("first_rank",[]),
          "exhibition_courses":pr.get("exhibition_courses",{}),
          "reasons":pr.get("reasons",[]),"boat_scores":pr.get("boat_scores",[])})
    out.sort(key=lambda x:x["minutes_to_deadline"])
    return out

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--db",default="data/boatrace.sqlite"); ap.add_argument("--json",action="store_true")
    a=ap.parse_args(); con=sqlite3.connect(a.db); rows=build_board(con)
    print(json.dumps(rows,ensure_ascii=False,indent=2) if a.json else "\n".join(f"{r['venue']}{r['race_no']}R {r['prediction_label']} {r['best_combo']}" for r in rows))
