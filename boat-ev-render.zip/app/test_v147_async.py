from pathlib import Path
s=Path("server_v11.py").read_text(encoding="utf-8")
j=Path("pwa/app.js").read_text(encoding="utf-8")
assert "/api/refresh-status" in s
assert "start_refresh" in s
assert "threading.Thread" in s
assert 'fetch("/api/refresh-status"' in j
assert '更新中 ${st.elapsed_sec||0}秒' in j
print("v1.4.7 async refresh regression: OK")
