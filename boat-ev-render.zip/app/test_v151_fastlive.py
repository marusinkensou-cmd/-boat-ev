from pathlib import Path
r=Path("refresh_service_v13.py").read_text(encoding="utf-8")
j=Path("pwa/app.js").read_text(encoding="utf-8")
assert "do not fetch the nationwide index first" in r
assert "cnt < 12" in r
assert 'item["odds"]=refresh_one' in r
assert 'item["beforeinfo"]={"deferred":True}' in r
assert "オッズ・出走表" in j
print("v1.5.1 fast live regression: OK")
