from pathlib import Path
r=Path("refresh_service_v13.py").read_text(encoding="utf-8")
o=Path("official_live_v10.py").read_text(encoding="utf-8")
assert "entry_count == 6" in r
assert '"source":"db-cache"' in r
assert "timeout=6" in o
print("v1.5.2 speed regression: OK")
