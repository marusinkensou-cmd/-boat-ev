from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from today_discovery_v12 import discover_today
from racelist_live_v12 import seed_venue_races,refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from official_live_v10 import refresh_one
from nationwide_board_v09 import build_board
from live_quality_v13 import mark,status

JST=ZoneInfo("Asia/Tokyo")

def mins_to_deadline(now,deadline):
    hh,mm=map(int,deadline[:5].split(":"))
    dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
    return (dl-now).total_seconds()/60

def seed_today(con,now,cache_dir="cache/live"):
    date=now.date().isoformat()
    venues,_=discover_today(date,cache_dir)
    ok=[];err=[]
    for v in venues:
        try:
            seed_venue_races(con,date,v["jcd"],cache_dir)
            ok.append(v)
        except Exception as e:
            err.append({"jcd":v["jcd"],"venue":v["venue"],"error":str(e)})
    return ok,err

def refresh_for_iphone(con,now=None,max_races=8,horizon_min=90,cache_dir="cache/live"):
    now=now or datetime.now(JST)
    seeded,venue_errors=seed_today(con,now,cache_dir)
    today=now.date().isoformat()
    rows=con.execute("""SELECT race_id,jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    cand=[]
    for rid,jcd,rno,dl in rows:
        try:m=mins_to_deadline(now,dl)
        except:continue
        if 0<=m<=horizon_min:cand.append((m,rid,jcd,rno))
    updates=[]
    for mins,rid,jcd,rno in cand[:max_races]:
        item={"race_id":rid,"jcd":jcd,"race_no":rno,"minutes":round(mins,1)}
        try:
            item["racelist"]=refresh_racelist(con,today,jcd,rno,cache_dir)
            mark(con,rid,"racelist_ok",True)
        except Exception as e:
            item["racelist_error"]=str(e)
            mark(con,rid,"racelist_ok",False,str(e))
        try:
            item["beforeinfo"]=refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir)
            mark(con,rid,"beforeinfo_ok",True)
        except Exception as e:
            item["beforeinfo_error"]=str(e)
            mark(con,rid,"beforeinfo_ok",False,str(e))
        try:
            item["odds"]=refresh_one(con,today,jcd,rno,cache_dir)
            mark(con,rid,"odds_ok",True)
        except Exception as e:
            item["odds_error"]=str(e)
            mark(con,rid,"odds_ok",False,str(e))
        item["quality"]=status(con,rid)
        updates.append(item)

    board=build_board(con,now)
    for r in board:
        q=status(con,r["race_id"])
        r["quality"]=q
        r["data_ready"]=q["racelist_ok"] and q["odds_ok"]
        if not r["data_ready"]:
            r["grade"]="DATA"
            r["decision"]="insufficient_live_data"
            r["bets"]=[]
            r["best_ev"]=r["best_combo"]=r["best_prob"]=r["best_odds"]=None
    return {
        "generated_at":now.isoformat(),
        "venues_found":len(seeded),
        "venue_errors":venue_errors,
        "races_updated":len(updates),
        "updates":updates,
        "board":board
    }
