from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from today_discovery_v12 import discover_today
from racelist_live_v12 import seed_venue_races,refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from official_live_v10 import refresh_one
from nationwide_board_v09 import build_board
from live_quality_v13 import mark,status
from virtual_ledger_v14 import record_board, stats
from result_live_v14 import settle_due

JST=ZoneInfo("Asia/Tokyo")

def mins_to_deadline(now,deadline):
    hh,mm=map(int,deadline[:5].split(":"))
    dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
    return (dl-now).total_seconds()/60

def seed_today(con,now,cache_dir="cache/live"):
    date=now.date().isoformat()
    venues,_=discover_today(date,cache_dir)
    ok=[];err=[]
    for v in venues:
        try:
            seed_venue_races(con,date,v["jcd"],cache_dir)
            ok.append(v)
        except Exception as e:
            err.append({"jcd":v["jcd"],"venue":v["venue"],"error":str(e)})
    return ok,err

def refresh_for_iphone(con,now=None,max_races=8,horizon_min=90,cache_dir="cache/live"):
    now=now or datetime.now(JST)
    settlement=settle_due(con,now,cache_dir)
    seeded,venue_errors=seed_today(con,now,cache_dir)
    today=now.date().isoformat()
    rows=con.execute("""SELECT race_id,jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    cand=[]
    fallback=[]
    for rid,jcd,rno,dl in rows:
        try:m=mins_to_deadline(now,dl)
        except:continue
        if 0<=m<=240:
            fallback.append((m,rid,jcd,rno))
            if m<=horizon_min:
                cand.append((m,rid,jcd,rno))
    # Early in the morning there may be no race inside the normal 90-minute
    # live window. In that case refresh the nearest few races anyway, so the
    # iPhone refresh button always has a meaningful target instead of doing 0R.
    selected=cand[:max_races] if cand else fallback[:min(4,max_races)]
    updates=[]
    for mins,rid,jcd,rno in selected:
        item={"race_id":rid,"jcd":jcd,"race_no":rno,"minutes":round(mins,1)}
        try:
            item["racelist"]=refresh_racelist(con,today,jcd,rno,cache_dir)
            mark(con,rid,"racelist_ok",True)
        except Exception as e:
            item["racelist_error"]=str(e)
            mark(con,rid,"racelist_ok",False,str(e))
        try:
            item["beforeinfo"]=refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir)
            mark(con,rid,"beforeinfo_ok",True)
        except Exception as e:
            item["beforeinfo_error"]=str(e)
            mark(con,rid,"beforeinfo_ok",False,str(e))
        try:
            item["odds"]=refresh_one(con,today,jcd,rno,cache_dir)
            mark(con,rid,"odds_ok",True)
        except Exception as e:
            item["odds_error"]=str(e)
            mark(con,rid,"odds_ok",False,str(e))
        item["quality"]=status(con,rid)
        updates.append(item)

    board=build_board(con,now)
    for r in board:
        q=status(con,r["race_id"])
        r["quality"]=q
        r["data_ready"]=q["racelist_ok"] and q["odds_ok"]
        if not r["data_ready"]:
            r["grade"]="DATA"
            r["decision"]="insufficient_live_data"
            r["bets"]=[]
            r["best_ev"]=r["best_combo"]=r["best_prob"]=r["best_odds"]=None
    plans_saved=record_board(con,board,now)
    return {
        "generated_at":now.isoformat(),
        "settlement":settlement,
        "plans_saved":plans_saved,
        "stats_today":stats(con,today),
        "stats_all":stats(con),
        "venues_found":len(seeded),
        "venue_errors":venue_errors,
        "races_updated":len(updates),
        "refresh_scope":"normal" if cand else ("nearest" if selected else "none"),
        "updates":updates,
        "board":board
    }
