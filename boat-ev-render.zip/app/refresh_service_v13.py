from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from today_discovery_v12 import discover_today, VENUES
from racelist_live_v12 import seed_venue_races,refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from official_live_v10 import refresh_one
from nationwide_board_v09 import build_board
from live_quality_v13 import mark,status
from virtual_ledger_v14 import record_board, stats
from result_live_v14 import settle_due

JST=ZoneInfo("Asia/Tokyo")

def mins_to_deadline(now,deadline):
    hh,mm=map(int,deadline[:5].split(":"))
    dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
    return (dl-now).total_seconds()/60

def seed_today(con,now,cache_dir="cache/live",selected_jcds=None):
    date=now.date().isoformat()

    # Fast path for explicit venue selection:
    # do not fetch the nationwide index first. Use the user's selected JCDs directly.
    if selected_jcds:
        venues=[{"jcd":str(j).zfill(2),"venue":VENUES.get(str(j).zfill(2),str(j).zfill(2))}
                for j in selected_jcds]
    else:
        venues,_=discover_today(date,cache_dir)

    ok=[];err=[]
    for v in venues:
        jcd=v["jcd"]
        try:
            # Reuse today's seeded 12-race schedule if already present.
            cnt=con.execute(
                "SELECT COUNT(*) FROM races WHERE race_date=? AND jcd=? AND deadline IS NOT NULL",
                (date,jcd)
            ).fetchone()[0]
            if cnt < 12:
                seed_venue_races(con,date,jcd,cache_dir)
            ok.append(v)
        except Exception as e:
            err.append({"jcd":jcd,"venue":v["venue"],"error":str(e)})
    return ok,err

def refresh_for_iphone(con,now=None,max_races=8,horizon_min=90,cache_dir="cache/live",progress=None,selected_jcds=None):
    now=now or datetime.now(JST)
    def report(stage, **extra):
        if progress:
            try: progress(stage, extra)
            except Exception: pass
    settlement={"skipped_for_speed":True}
    report("discovering")
    seeded,venue_errors=seed_today(con,now,cache_dir,selected_jcds)
    report("seeded", venues_found=len(seeded))
    today=now.date().isoformat()
    rows=con.execute("""SELECT race_id,jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    if selected_jcds:
        selected={str(x).zfill(2) for x in selected_jcds}
        rows=[row for row in rows if str(row[1]).zfill(2) in selected]
    cand=[]
    fallback=[]
    for rid,jcd,rno,dl in rows:
        try:m=mins_to_deadline(now,dl)
        except:continue
        if 0<=m<=240:
            fallback.append((m,rid,jcd,rno))
            if m<=horizon_min:
                cand.append((m,rid,jcd,rno))
    # iPhone fast mode:
    # when the user explicitly selected venues, refresh only the nearest
    # upcoming race for EACH selected venue. This guarantees that choosing
    # 江戸川+平和島 does not spend all time on several races from only one venue.
    if selected_jcds:
        # User-facing fast mode is strictly the next 60 minutes.
        source=[row for row in cand if row[0] <= 60]
        nearest_by_venue={}
        for row in source:
            m,rid,jcd,rno=row
            jj=str(jcd).zfill(2)
            if jj not in nearest_by_venue:
                nearest_by_venue[jj]=row
        requested=[str(x).zfill(2) for x in selected_jcds]
        selected=[nearest_by_venue[j] for j in requested if j in nearest_by_venue]
    else:
        # Nationwide mode stays capped; selected-venue mode is the fast path.
        selected=cand[:max_races] if cand else fallback[:min(4,max_races)]
    updates=[]
    report("selected", races_total=len(selected), venues_requested=len(selected_jcds or []), venues_found=len(seeded))
    for idx,(mins,rid,jcd,rno) in enumerate(selected, start=1):
        report("race_start", race_index=idx, races_total=len(selected), jcd=jcd, race_no=rno)
        item={"race_id":rid,"jcd":jcd,"race_no":rno,"minutes":round(mins,1)}
        # Fast selected-venue mode prioritizes what is required for an EV decision:
        # odds first, then the racelist. Before-info is deferred because data_ready
        # only requires racelist + odds, and waiting for exhibition data can cost
        # valuable seconds near the betting deadline.
        try:
            item["odds"]=refresh_one(con,today,jcd,rno,cache_dir)
            mark(con,rid,"odds_ok",True)
        except Exception as e:
            item["odds_error"]=str(e)
            mark(con,rid,"odds_ok",False,str(e))

        # Racer/motor data changes far less often than odds. If six entries
        # are already stored for this race, reuse them and avoid another
        # official-page request on every button press.
        entry_count=con.execute(
            "SELECT COUNT(*) FROM entries WHERE race_id=?",(rid,)
        ).fetchone()[0]
        if entry_count == 6:
            item["racelist"]={"race_id":rid,"entries":6,"source":"db-cache"}
            mark(con,rid,"racelist_ok",True)
        else:
            try:
                item["racelist"]=refresh_racelist(con,today,jcd,rno,cache_dir)
                mark(con,rid,"racelist_ok",True)
            except Exception as e:
                item["racelist_error"]=str(e)
                mark(con,rid,"racelist_ok",False,str(e))

        if selected_jcds:
            item["beforeinfo"]={"deferred":True}
        else:
            try:
                item["beforeinfo"]=refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir)
                mark(con,rid,"beforeinfo_ok",True)
            except Exception as e:
                item["beforeinfo_error"]=str(e)
                mark(con,rid,"beforeinfo_ok",False,str(e))
        item["quality"]=status(con,rid)
        updates.append(item)
        report("race_done", race_index=idx, races_total=len(selected), jcd=jcd, race_no=rno)
    report("building_board")
    board=build_board(con,now)
    for r in board:
        q=status(con,r["race_id"])
        r["quality"]=q
        r["data_ready"]=q["racelist_ok"] and q["odds_ok"]
        if not r["data_ready"]:
            r["grade"]="DATA"
            r["decision"]="insufficient_live_data"
            r["bets"]=[]
            r["best_ev"]=r["best_combo"]=r["best_prob"]=r["best_odds"]=None
    plans_saved=record_board(con,board,now)
    report("done", races_updated=len(updates), venues_found=len(seeded))
    return {
        "generated_at":now.isoformat(),
        "settlement":settlement,
        "plans_saved":plans_saved,
        "stats_today":stats(con,today),
        "stats_all":stats(con),
        "venues_found":len(seeded),
        "selected_jcds":[v["jcd"] for v in seeded],
        "venue_errors":venue_errors,
        "races_updated":len(updates),
        "refresh_scope":"normal" if cand else ("nearest" if selected else "none"),
        "updates":updates,
        "board":board
    }
