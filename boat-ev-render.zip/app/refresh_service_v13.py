from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from today_discovery_v12 import discover_today, VENUES
from racelist_live_v12 import seed_venue_races,refresh_racelist
from beforeinfo_live_v13 import refresh_beforeinfo_v13
from nationwide_board_v09 import build_board
from live_quality_v13 import mark,status
from virtual_ledger_v14 import record_board, stats
from result_live_v14 import settle_due

JST=ZoneInfo("Asia/Tokyo")

def mins_to_deadline(now,deadline):
    hh,mm=map(int,deadline[:5].split(":"))
    dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
    return (dl-now).total_seconds()/60

def seed_today(con,now,cache_dir="cache/live",selected_jcds=None):
    date=now.date().isoformat()

    # Fast path for explicit venue selection:
    # do not fetch the nationwide index first. Use the user's selected JCDs directly.
    if selected_jcds:
        venues=[{"jcd":str(j).zfill(2),"venue":VENUES.get(str(j).zfill(2),str(j).zfill(2))}
                for j in selected_jcds]
    else:
        venues,_=discover_today(date,cache_dir)

    ok=[];err=[]
    for v in venues:
        jcd=v["jcd"]
        try:
            # Reuse today's seeded 12-race schedule if already present.
            cnt=con.execute(
                "SELECT COUNT(*) FROM races WHERE race_date=? AND jcd=? AND deadline IS NOT NULL",
                (date,jcd)
            ).fetchone()[0]
            # Selected-venue refresh is a live fast path. If this venue has already
            # been seeded at all today, do not refetch race 1 just to insist on a
            # complete 12-race schedule. Missing rows can be filled on the next
            # day-start/background seed; the live button should favor speed.
            need_seed = (cnt == 0) if selected_jcds else (cnt < 12)
            if need_seed:
                seed_venue_races(con,date,jcd,cache_dir)
            ok.append(v)
        except Exception as e:
            err.append({"jcd":jcd,"venue":v["venue"],"error":str(e)})
    return ok,err

def refresh_for_iphone(con,now=None,max_races=8,horizon_min=90,cache_dir="cache/live",progress=None,selected_jcds=None):
    now=now or datetime.now(JST)
    def report(stage, **extra):
        if progress:
            try: progress(stage, extra)
            except Exception: pass
    settlement={"skipped_for_speed":True}
    report("discovering")
    seeded,venue_errors=seed_today(con,now,cache_dir,selected_jcds)
    report("seeded", venues_found=len(seeded))
    today=now.date().isoformat()
    rows=con.execute("""SELECT race_id,jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    if selected_jcds:
        # v1.6.1: real-time mode intentionally tracks one venue only.
        one=str(selected_jcds[0]).zfill(2)
        rows=[row for row in rows if str(row[1]).zfill(2)==one]
    cand=[]
    fallback=[]
    for rid,jcd,rno,dl in rows:
        try:m=mins_to_deadline(now,dl)
        except:continue
        if 0<=m<=240:
            fallback.append((m,rid,jcd,rno))
            if m<=horizon_min:
                cand.append((m,rid,jcd,rno))
    # v1.6.1: update button is a pit-side fast path. Only the nearest upcoming
    # race at the chosen venue is refreshed. Later races keep cached/base data.
    if selected_jcds:
        in_window=[row for row in cand if row[0] <= 60]
        selected=in_window[:1]
    else:
        # Nationwide mode stays capped; selected-venue mode is the fast path.
        selected=cand[:max_races] if cand else fallback[:min(4,max_races)]
    updates=[]
    report("selected", races_total=len(selected), venues_requested=len(selected_jcds or []), venues_found=len(seeded))
    for idx,(mins,rid,jcd,rno) in enumerate(selected, start=1):
        report("race_start", race_index=idx, races_total=len(selected), jcd=jcd, race_no=rno)
        item={"race_id":rid,"jcd":jcd,"race_no":rno,"minutes":round(mins,1)}

        # 1) Stable pre-race inputs first. Predictions never use odds.
        try:
            entry_count=con.execute("SELECT COUNT(*) FROM entries WHERE race_id=?",(rid,)).fetchone()[0]
            if entry_count>=6:
                item["racelist"]={"cached":True,"entries":entry_count}; mark(con,rid,"racelist_ok",True)
            else:
                item["racelist"]=refresh_racelist(con,today,jcd,rno,cache_dir); mark(con,rid,"racelist_ok",True)
        except Exception as e:
            item["racelist_error"]=str(e); mark(con,rid,"racelist_ok",False,str(e))

        # 2) Real-time input: fetch only the selected venue's nearest race
        # beforeinfo. This one request contains exhibition time/ST/course and weather/water.
        try:
            item["beforeinfo"]=refresh_beforeinfo_v13(con,today,jcd,rno,cache_dir); mark(con,rid,"beforeinfo_ok",True)
        except Exception as e:
            item["beforeinfo_error"]=str(e); mark(con,rid,"beforeinfo_ok",False,str(e))

        # Odds are intentionally NOT fetched on the critical path. The user can
        # check them at the venue/live screen; prediction must appear first.
        item["odds"]={"skipped_for_speed":True}
        item["quality"]=status(con,rid); updates.append(item)
        report("race_done", race_index=idx, races_total=len(selected), jcd=jcd, race_no=rno)
    report("building_board")
    board=build_board(con,now)
    for r in board:
        q=status(con,r["race_id"]); r["quality"]=q
        r["data_ready"]=q["racelist_ok"]
    # Old EV paper-trading is intentionally paused. v1.6 uses odds-independent
    # predictions; keeping the old EV ledger would mix two different strategies.
    plans_saved=0
    report("done", races_updated=len(updates), venues_found=len(seeded))
    return {
        "generated_at":now.isoformat(),
        "settlement":settlement,
        "plans_saved":plans_saved,
        "stats_today":stats(con,today),
        "stats_all":stats(con),
        "venues_found":len(seeded),
        "selected_jcds":[str(selected_jcds[0]).zfill(2)] if selected_jcds else [v["jcd"] for v in seeded],
        "venue_errors":venue_errors,
        "races_updated":len(updates),
        "refresh_scope":"normal" if cand else ("nearest" if selected else "none"),
        "updates":updates,
        "board":board
    }
