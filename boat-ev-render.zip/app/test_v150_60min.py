from pathlib import Path
j=Path("pwa/app.js").read_text(encoding="utf-8")
r=Path("refresh_service_v13.py").read_text(encoding="utf-8")
assert "r.minutes_to_deadline > 60" in j
assert "r.minutes_to_deadline<=60" in j
assert "row[0] <= 60" in r
print("v1.5.0 60-minute window regression: OK")
