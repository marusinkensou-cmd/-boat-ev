from __future__ import annotations
import argparse,json,mimetypes,sqlite3,traceback,threading
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse
from nationwide_board_v09 import build_board
from refresh_service_v13 import refresh_for_iphone
from virtual_ledger_v14 import stats,grade_stats
JST=ZoneInfo("Asia/Tokyo")

class App:
    def __init__(self,db,static_dir):
        self.db=db
        self.static_dir=Path(static_dir)
        self._refresh_lock=threading.Lock()
        self._refresh_state={
            "running":False,"stage":"idle","started_at":None,"finished_at":None,
            "races_total":0,"race_index":0,"races_updated":0,"venues_found":0,
            "error":None
        }

    def board(self):
        con=sqlite3.connect(self.db)
        try:
            now=datetime.now(JST)
            return {"generated_at":now.isoformat(),"board":build_board(con,now)}
        finally:
            con.close()

    def _set_state(self, **kwargs):
        with self._refresh_lock:
            self._refresh_state.update(kwargs)

    def refresh_status(self):
        with self._refresh_lock:
            st=dict(self._refresh_state)
        if st.get("running") and st.get("started_at"):
            try:
                started=datetime.fromisoformat(st["started_at"])
                st["elapsed_sec"]=max(0,int((datetime.now(JST)-started).total_seconds()))
            except Exception:
                st["elapsed_sec"]=0
        elif st.get("started_at") and st.get("finished_at"):
            try:
                a=datetime.fromisoformat(st["started_at"])
                b=datetime.fromisoformat(st["finished_at"])
                st["elapsed_sec"]=max(0,int((b-a).total_seconds()))
            except Exception:
                st["elapsed_sec"]=0
        return st

    def _refresh_worker(self):
        con=sqlite3.connect(self.db)
        try:
            def progress(stage, extra):
                patch={"stage":stage}
                patch.update(extra or {})
                if stage=="race_done":
                    patch["races_updated"]=extra.get("race_index",0)
                self._set_state(**patch)
            result=refresh_for_iphone(con,datetime.now(JST),progress=progress)
            self._set_state(
                running=False,stage="done",finished_at=datetime.now(JST).isoformat(),
                races_updated=result.get("races_updated",0),
                venues_found=result.get("venues_found",0),
                error=None
            )
        except Exception as e:
            traceback.print_exc()
            self._set_state(
                running=False,stage="error",finished_at=datetime.now(JST).isoformat(),
                error=f"{type(e).__name__}: {e}"
            )
        finally:
            con.close()

    def start_refresh(self):
        with self._refresh_lock:
            if self._refresh_state.get("running"):
                return {"accepted":True,"already_running":True,**self._refresh_state}
            self._refresh_state={
                "running":True,"stage":"starting","started_at":datetime.now(JST).isoformat(),
                "finished_at":None,"races_total":0,"race_index":0,
                "races_updated":0,"venues_found":0,"error":None
            }
        threading.Thread(target=self._refresh_worker,daemon=True).start()
        return {"accepted":True,"already_running":False,**self.refresh_status()}

    def stats(self):
        con=sqlite3.connect(self.db)
        try:
            today=datetime.now(JST).date().isoformat()
            return {"today":stats(con,today),"all":stats(con),"by_grade":grade_stats(con)}
        finally:
            con.close()

def make_handler(app):
    class H(BaseHTTPRequestHandler):
        def sendx(self,status,body,ctype="application/json; charset=utf-8"):
            self.send_response(status);self.send_header("Content-Type",ctype)
            self.send_header("Cache-Control","no-store")
            self.end_headers();self.wfile.write(body if isinstance(body,bytes) else body.encode("utf-8"))
        def do_GET(self):
            p=urlparse(self.path).path
            if p=="/api/health":return self.sendx(200,json.dumps({"ok":True}))
            if p=="/api/board":
                try:return self.sendx(200,json.dumps(app.board(),ensure_ascii=False))
                except Exception as e:
                    traceback.print_exc()
                    return self.sendx(500,json.dumps({"error":str(e),"type":type(e).__name__},ensure_ascii=False))
            if p=="/api/refresh-status":
                try:return self.sendx(200,json.dumps(app.refresh_status(),ensure_ascii=False))
                except Exception as e:
                    traceback.print_exc()
                    return self.sendx(500,json.dumps({"error":str(e),"type":type(e).__name__},ensure_ascii=False))
            if p=="/api/stats":
                try:return self.sendx(200,json.dumps(app.stats(),ensure_ascii=False))
                except Exception as e:
                    traceback.print_exc()
                    return self.sendx(500,json.dumps({"error":str(e),"type":type(e).__name__},ensure_ascii=False))
            rel="index.html" if p=="/" else p.lstrip("/")
            f=(app.static_dir/rel).resolve()
            try:f.relative_to(app.static_dir.resolve())
            except:return self.sendx(403,"forbidden","text/plain")
            if not f.is_file():return self.sendx(404,"not found","text/plain")
            return self.sendx(200,f.read_bytes(),mimetypes.guess_type(str(f))[0] or "application/octet-stream")
        def do_POST(self):
            if urlparse(self.path).path!="/api/refresh":return self.sendx(404,"not found","text/plain")
            try:return self.sendx(202,json.dumps(app.start_refresh(),ensure_ascii=False))
            except Exception as e:
                traceback.print_exc()
                return self.sendx(500,json.dumps({"error":str(e),"type":type(e).__name__},ensure_ascii=False))
        def log_message(self,*args):pass
    return H

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--host",default="0.0.0.0");ap.add_argument("--port",type=int,default=8080)
    ap.add_argument("--static",default="pwa")
    a=ap.parse_args()
    ThreadingHTTPServer((a.host,a.port),make_handler(App(a.db,a.static))).serve_forever()
