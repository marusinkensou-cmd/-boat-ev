from pathlib import Path
srv=Path("server_v11.py").read_text(encoding="utf-8")
ref=Path("refresh_service_v13.py").read_text(encoding="utf-8")
js=Path("pwa/app.js").read_text(encoding="utf-8")
html=Path("pwa/index.html").read_text(encoding="utf-8")
assert "selected_jcds" in srv
assert "selected_jcds" in ref
assert 'body:JSON.stringify({selected_jcds:[...SELECTED_JCDS]})' in js
assert "戸田" in js and "唐津" in js and "江戸川" in js
assert 'id="venuePicker"' in html
print("v1.4.8 venue selection regression: OK")
