from pathlib import Path
r=Path("refresh_service_v13.py").read_text(encoding="utf-8")
j=Path("pwa/app.js").read_text(encoding="utf-8")
assert "nearest_by_venue" in r
assert "settlement={\"skipped_for_speed\":True}" in r
assert "venues_requested" in r
assert "venues_found" in j
print("v1.4.9 fast selected venues regression: OK")
