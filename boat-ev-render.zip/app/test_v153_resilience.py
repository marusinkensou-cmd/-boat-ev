from pathlib import Path
j=Path("pwa/app.js").read_text(encoding="utf-8")
o=Path("official_live_v10.py").read_text(encoding="utf-8")
r=Path("refresh_service_v13.py").read_text(encoding="utf-8")
assert 'VENUE_MODE=localStorage.getItem("venue_mode")||"all"' in j
assert 'VENUE_MODE==="all"?null:[...SELECTED_JCDS]' in j
assert '一部取得失敗・前回データを表示' in j
assert "timeout=3" in o
assert 'report("board_error"' in r
print("v1.5.3 resilience regression: OK")
