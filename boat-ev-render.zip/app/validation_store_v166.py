from __future__ import annotations
import json, os, sqlite3
from contextlib import contextmanager
from datetime import datetime

MODEL_VERSION = os.getenv('BOAT_EV_MODEL_VERSION','P162-v167')
VALIDATION_URL = os.getenv('VALIDATION_DATABASE_URL','').strip()

SQLITE_SCHEMA = '''
CREATE TABLE IF NOT EXISTS validation_predictions (
  race_id TEXT NOT NULL,
  model_version TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  deadline_at TEXT NOT NULL,
  jcd TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  stage TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  settled_at TEXT,
  result_combo TEXT,
  payout_yen INTEGER,
  PRIMARY KEY (race_id, model_version)
);
CREATE INDEX IF NOT EXISTS idx_validation_unsettled
  ON validation_predictions(settled_at, deadline_at);
'''

POSTGRES_SCHEMA = '''
CREATE TABLE IF NOT EXISTS validation_predictions (
  race_id TEXT NOT NULL,
  model_version TEXT NOT NULL,
  captured_at TIMESTAMPTZ NOT NULL,
  deadline_at TIMESTAMPTZ NOT NULL,
  jcd TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  stage TEXT NOT NULL,
  payload_json JSONB NOT NULL,
  settled_at TIMESTAMPTZ,
  result_combo TEXT,
  payout_yen INTEGER,
  PRIMARY KEY (race_id, model_version)
);
CREATE INDEX IF NOT EXISTS idx_validation_unsettled
  ON validation_predictions(settled_at, deadline_at);
'''

def _is_pg():
    return bool(VALIDATION_URL)

@contextmanager
def _conn(sqlite_path=None):
    if _is_pg():
        import psycopg
        con=psycopg.connect(VALIDATION_URL, autocommit=False)
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback(); raise
        finally:
            con.close()
    else:
        if sqlite_path is None:
            raise ValueError('sqlite_path required when VALIDATION_DATABASE_URL is not set')
        con=sqlite3.connect(sqlite_path)
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback(); raise
        finally:
            con.close()

def ensure_validation_schema(sqlite_path=None):
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                for stmt in [s.strip() for s in POSTGRES_SCHEMA.split(';') if s.strip()]:
                    cur.execute(stmt)
        else:
            con.executescript(SQLITE_SCHEMA)

def save_snapshot(sqlite_path, *, race_id, jcd, race_no, captured_at, deadline_at, stage, payload, model_version=MODEL_VERSION):
    ensure_validation_schema(sqlite_path)
    body=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                cur.execute('''INSERT INTO validation_predictions
                    (race_id,model_version,captured_at,deadline_at,jcd,race_no,stage,payload_json)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                    ON CONFLICT (race_id,model_version) DO NOTHING''',
                    (race_id,model_version,captured_at,deadline_at,jcd,int(race_no),stage,body))
                return cur.rowcount>0
        cur=con.execute('''INSERT OR IGNORE INTO validation_predictions
            (race_id,model_version,captured_at,deadline_at,jcd,race_no,stage,payload_json)
            VALUES (?,?,?,?,?,?,?,?)''',
            (race_id,model_version,captured_at.isoformat(),deadline_at.isoformat(),jcd,int(race_no),stage,body))
        return cur.rowcount>0

def has_snapshot(sqlite_path, race_id, model_version=MODEL_VERSION):
    ensure_validation_schema(sqlite_path)
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                cur.execute('SELECT 1 FROM validation_predictions WHERE race_id=%s AND model_version=%s',(race_id,model_version))
                return cur.fetchone() is not None
        return con.execute('SELECT 1 FROM validation_predictions WHERE race_id=? AND model_version=?',(race_id,model_version)).fetchone() is not None

def unsettled(sqlite_path, now, model_version=MODEL_VERSION):
    ensure_validation_schema(sqlite_path)
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                cur.execute('''SELECT race_id,jcd,race_no,deadline_at FROM validation_predictions
                    WHERE model_version=%s AND settled_at IS NULL AND deadline_at < %s ORDER BY deadline_at''',(model_version,now))
                return cur.fetchall()
        rows=con.execute('''SELECT race_id,jcd,race_no,deadline_at FROM validation_predictions
            WHERE model_version=? AND settled_at IS NULL AND deadline_at < ? ORDER BY deadline_at''',(model_version,now.isoformat())).fetchall()
        return rows

def settle(sqlite_path, race_id, combo, payout_yen, settled_at, model_version=MODEL_VERSION):
    ensure_validation_schema(sqlite_path)
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                cur.execute('''UPDATE validation_predictions SET settled_at=%s,result_combo=%s,payout_yen=%s
                    WHERE race_id=%s AND model_version=%s AND settled_at IS NULL''',
                    (settled_at,combo,payout_yen,race_id,model_version))
                return cur.rowcount>0
        cur=con.execute('''UPDATE validation_predictions SET settled_at=?,result_combo=?,payout_yen=?
            WHERE race_id=? AND model_version=? AND settled_at IS NULL''',
            (settled_at.isoformat(),combo,payout_yen,race_id,model_version))
        return cur.rowcount>0

def _score_row(payload, result_combo, payout_yen=0):
    actual=[int(x) for x in str(result_combo)[:3] if x.isdigit()]
    rank=[int(x.get('boat')) for x in payload.get('first_rank',[]) if x.get('boat') is not None]
    top3=rank[:3]
    first_hit=int(bool(actual and rank and actual[0]==rank[0]))
    winner_top3=int(bool(actual and actual[0] in top3))
    overlap=len(set(top3)&set(actual[:3])) if len(actual)>=3 else 0
    # Profitability is scored on the validation-only virtual plan, not on odds.
    # Odds/payout are never prediction inputs; official payout is used only after the race.
    plan=payload.get('virtual_plan') or payload.get('buy_plan') or {}
    bets=plan.get('bets') or []
    hit_bet=next((b for b in bets if str(b.get('combination'))==str(result_combo)),None)
    buy_hit=int(hit_bet is not None)
    cover_rescue=int(bool(hit_bet and '押さえ' in str(hit_bet.get('reason',''))))
    main_hit=int(bool(hit_bet and not cover_rescue))
    stake=int(plan.get('stake_yen') or sum(int(b.get('stake_yen') or 0) for b in bets))
    hit_stake=int(hit_bet.get('stake_yen') or 0) if hit_bet else 0
    gross_return=int(round((int(payout_yen or 0) * hit_stake) / 100)) if hit_stake else 0
    profit=gross_return-stake
    return first_hit,winner_top3,overlap,buy_hit,main_hit,cover_rescue,len(bets),stake,gross_return,profit

def metrics(sqlite_path, model_version=MODEL_VERSION):
    ensure_validation_schema(sqlite_path)
    with _conn(sqlite_path) as con:
        if _is_pg():
            with con.cursor() as cur:
                cur.execute('''SELECT payload_json,result_combo,jcd,payout_yen FROM validation_predictions
                    WHERE model_version=%s AND settled_at IS NOT NULL AND result_combo IS NOT NULL ORDER BY deadline_at''',(model_version,))
                rows=cur.fetchall()
                cur.execute('SELECT COUNT(*) FROM validation_predictions WHERE model_version=%s',(model_version,)); total=cur.fetchone()[0]
        else:
            rows=con.execute('''SELECT payload_json,result_combo,jcd,payout_yen FROM validation_predictions
                WHERE model_version=? AND settled_at IS NOT NULL AND result_combo IS NOT NULL ORDER BY deadline_at''',(model_version,)).fetchall()
            total=con.execute('SELECT COUNT(*) FROM validation_predictions WHERE model_version=?',(model_version,)).fetchone()[0]
    n=len(rows)
    agg={'first_pick_hits':0,'winner_top3_hits':0,'top3_overlap_sum':0,'buy_hits':0,'main_hits':0,'cover_rescues':0,'bet_count_sum':0,'stake_sum_yen':0,'return_sum_yen':0,'profit_sum_yen':0}
    types={}
    for raw,combo,jcd,payout_yen in rows:
        payload=raw if isinstance(raw,dict) else json.loads(raw)
        vals=_score_row(payload,combo,payout_yen)
        for k,v in zip(agg.keys(),vals): agg[k]+=v
        typ=((payload.get('buy_plan') or {}).get('confidence') or {}).get('type','unknown')
        t=types.setdefault(typ,{'races':0,'buy_hits':0}); t['races']+=1; t['buy_hits']+=vals[3]
    def rate(x): return round(x/n,4) if n else 0.0
    return {
        'model_version':model_version,'snapshots':int(total),'settled':n,'target':500,
        'progress_pct':round(min(total,500)/500*100,1),
        'first_pick_hit_rate':rate(agg['first_pick_hits']),
        'winner_in_top3_rate':rate(agg['winner_top3_hits']),
        'avg_top3_overlap':round(agg['top3_overlap_sum']/n,3) if n else 0.0,
        'buy_hit_rate':rate(agg['buy_hits']),
        'main_hit_rate':rate(agg['main_hits']),
        'cover_rescue_rate':rate(agg['cover_rescues']),
        'avg_bet_count':round(agg['bet_count_sum']/n,2) if n else 0.0,
        'avg_stake_yen':round(agg['stake_sum_yen']/n,1) if n else 0.0,
        'total_stake_yen':int(agg['stake_sum_yen']),
        'total_return_yen':int(agg['return_sum_yen']),
        'total_profit_yen':int(agg['profit_sum_yen']),
        'recovery_rate':round(agg['return_sum_yen']/agg['stake_sum_yen'],4) if agg['stake_sum_yen'] else 0.0,
        'by_race_type':{k:{**v,'buy_hit_rate':round(v['buy_hits']/v['races'],4) if v['races'] else 0.0} for k,v in types.items()}
    }
