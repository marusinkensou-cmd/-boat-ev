from pathlib import Path
s=Path("refresh_service_v13.py").read_text()
assert "SELECT COUNT(*) FROM entries WHERE race_id=?" in s
assert 'item["racelist"]={"cached":True' in s
print("v1.5.9 racelist cache regression: OK")
