from __future__ import annotations
import argparse, re, time, sqlite3, hashlib, sys
from pathlib import Path
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from bs4 import BeautifulSoup

BASE="https://www.boatrace.jp/owpc/pc/race"
USER_AGENT="Mozilla/5.0 (compatible; BOATRACE-EV-Research/1.0)"
MIN_INTERVAL_SEC=2.0
_last_fetch=0.0

def official_url(kind,date,jcd,race_no):
    page={"odds3t":"odds3t","racelist":"racelist","beforeinfo":"beforeinfo"}[kind]
    return f"{BASE}/{page}?"+urlencode({"rno":race_no,"jcd":jcd,"hd":date.replace('-','')})

def fetch_html(url, cache_dir="cache/live", max_age_sec=45, timeout=15):
    global _last_fetch
    cache=Path(cache_dir); cache.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256(url.encode()).hexdigest()+".html"
    p=cache/key
    if p.exists() and time.time()-p.stat().st_mtime <= max_age_sec:
        return p.read_text(encoding="utf-8",errors="replace"), "cache"
    wait=MIN_INTERVAL_SEC-(time.time()-_last_fetch)
    if wait>0: time.sleep(wait)
    req=Request(url,headers={"User-Agent":USER_AGENT,"Accept-Language":"ja,en;q=0.7"})
    t0=time.time()
    try:
        with urlopen(req,timeout=timeout) as r:
            raw=r.read()
            status=getattr(r,"status",None)
            ctype=r.headers.get("Content-Type","")
        print(f"[LIVE_FETCH] ok status={status} bytes={len(raw)} sec={time.time()-t0:.2f} ctype={ctype} url={url}", flush=True)
    except Exception as e:
        print(f"[LIVE_FETCH] ERROR type={type(e).__name__} sec={time.time()-t0:.2f} url={url} err={e}", flush=True)
        raise
    _last_fetch=time.time()
    # official pages are UTF-8 today; fall back safely if encoding changes.
    text=raw.decode("utf-8",errors="replace")
    p.write_text(text,encoding="utf-8")
    return text,"network"

def parse_deadlines(html):
    soup=BeautifulSoup(html,"html.parser")
    text=soup.get_text(" ",strip=True)
    pos=text.find("締切予定時刻")
    target=text[pos:pos+600] if pos>=0 else text
    times=re.findall(r"\b(?:[01]\d|2[0-3]):[0-5]\d\b",target)
    out={}
    for i,t in enumerate(times[:12],1):
        out[i]=t
    return out

def _num(s):
    s=s.replace(",","").strip()
    try:return float(s)
    except:return None

def parse_trifecta_odds(html):
    """Parse the official 3連単 table as 20 rows x 6 first-boat columns.

    The official table stores the actual odds in ``td.oddsPoint`` cells.
    There are 20 ordered (2nd,3rd) possibilities for each first boat and
    six first-boat columns, i.e. exactly 120 values.  Reading boat-number
    labels as if they were repeated triples only captured 30 combinations.
    """
    soup=BeautifulSoup(html,"html.parser")
    best_points=[]
    best_table=None
    for table in soup.find_all("table"):
        rows=[]
        for tr in table.select("tbody tr"):
            pts=[]
            for td in tr.select("td.oddsPoint"):
                v=_num(td.get_text(" ",strip=True))
                if v is not None and v>=1.0:
                    pts.append(v)
            if pts:
                rows.append(pts)
        # Official trifecta table: 20 rows, normally 6 odds values per row.
        n=sum(len(r) for r in rows)
        if n>len(best_points):
            best_points=[v for r in rows for v in r]
            best_table=rows

    odds={}
    if best_table and len(best_table)==20 and all(len(r)==6 for r in best_table):
        # Matrix is row-major (20 x 6).  Each column is one first boat.
        for first in range(1,7):
            vals=[row[first-1] for row in best_table]
            k=0
            for second in range(1,7):
                if second==first: continue
                for third in range(1,7):
                    if third==first or third==second: continue
                    odds[f"{first}{second}{third}"]=vals[k]
                    k+=1

    print(f"[ODDS_PARSE] tables={len(soup.find_all('table'))} oddsPoint={len(best_points)} rows={len(best_table or [])} parsed={len(odds)} html_len={len(html)}", flush=True)
    if len(odds)!=120:
        raise ValueError(f"3連単オッズ解析件数が不足しています: {len(odds)}/120 (oddsPoint={len(best_points)})")
    return odds

def upsert_deadlines(con,race_date,jcd,deadlines):
    for rno,t in deadlines.items():
        rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
        con.execute("""INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status)
                       VALUES(?,?,?,?,?,'scheduled')
                       ON CONFLICT(race_date,jcd,race_no)
                       DO UPDATE SET deadline=excluded.deadline""",
                    (rid,race_date,jcd,rno,t))
    con.commit()

def store_odds(con,race_id,odds,fetched_at=None):
    fetched_at=fetched_at or datetime.now().astimezone().isoformat(timespec="seconds")
    cur=con.execute("INSERT INTO odds_snapshots(race_id,fetched_at) VALUES(?,?)",(race_id,fetched_at))
    sid=cur.lastrowid
    for combo,val in odds.items():
        a,b,c=map(int,combo)
        con.execute("""INSERT INTO odds_trifecta
                       (snapshot_id,first_boat,second_boat,third_boat,odds)
                       VALUES(?,?,?,?,?)""",(sid,a,b,c,val))
    con.commit()
    return sid

def refresh_one(con,race_date,jcd,race_no,cache_dir="cache/live"):
    url=official_url("odds3t",race_date,jcd,race_no)
    html,source=fetch_html(url,cache_dir=cache_dir)
    deadlines=parse_deadlines(html)
    if deadlines:
        upsert_deadlines(con,race_date,jcd,deadlines)
    odds=parse_trifecta_odds(html)
    rid=f"{race_date.replace('-','')}-{jcd}-{race_no:02d}"
    if len(odds)!=120:
        print(f"[ODDS_PARSE] INCOMPLETE race={rid} count={len(odds)}", flush=True)
        raise ValueError(f"official odds parse incomplete: {len(odds)}")
    sid=store_odds(con,rid,odds)
    return {"race_id":rid,"snapshot_id":sid,"odds_count":len(odds),"source":source,"url":url}

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--date",required=True)
    ap.add_argument("--jcd",required=True)
    ap.add_argument("--race",type=int,required=True)
    ap.add_argument("--cache-dir",default="cache/live")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    print(refresh_one(con,a.date,a.jcd,a.race,a.cache_dir))
