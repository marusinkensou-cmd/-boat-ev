from __future__ import annotations
import argparse, re, time, sqlite3, hashlib
from pathlib import Path
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from bs4 import BeautifulSoup

BASE="https://www.boatrace.jp/owpc/pc/race"
USER_AGENT="Mozilla/5.0 (compatible; BOATRACE-EV-Research/1.0)"
MIN_INTERVAL_SEC=2.0
_last_fetch=0.0

def official_url(kind,date,jcd,race_no):
    page={"odds3t":"odds3t","racelist":"racelist","beforeinfo":"beforeinfo"}[kind]
    return f"{BASE}/{page}?"+urlencode({"rno":race_no,"jcd":jcd,"hd":date.replace('-','')})

def fetch_html(url, cache_dir="cache/live", max_age_sec=45, timeout=6):
    global _last_fetch
    cache=Path(cache_dir); cache.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256(url.encode()).hexdigest()+".html"
    p=cache/key
    if p.exists() and time.time()-p.stat().st_mtime <= max_age_sec:
        return p.read_text(encoding="utf-8",errors="replace"), "cache"
    wait=MIN_INTERVAL_SEC-(time.time()-_last_fetch)
    if wait>0: time.sleep(wait)
    req=Request(url,headers={"User-Agent":USER_AGENT,"Accept-Language":"ja,en;q=0.7"})
    with urlopen(req,timeout=timeout) as r:
        raw=r.read()
    _last_fetch=time.time()
    # official pages are UTF-8 today; fall back safely if encoding changes.
    text=raw.decode("utf-8",errors="replace")
    p.write_text(text,encoding="utf-8")
    return text,"network"

def parse_deadlines(html):
    soup=BeautifulSoup(html,"html.parser")
    text=soup.get_text(" ",strip=True)
    pos=text.find("締切予定時刻")
    target=text[pos:pos+600] if pos>=0 else text
    times=re.findall(r"\b(?:[01]\d|2[0-3]):[0-5]\d\b",target)
    out={}
    for i,t in enumerate(times[:12],1):
        out[i]=t
    return out

def _num(s):
    s=s.replace(",","").strip()
    try:return float(s)
    except:return None

def parse_trifecta_odds(html):
    """Parse 120 trifecta odds from the official odds3t table.

    Official visible layout is six first-boat groups side by side.
    Each body row contains repeated triples:
        second boat, third boat, odds
    for first boats 1..6.

    The parser deliberately validates all returned combinations and
    requires a plausible count, rather than silently accepting malformed HTML.
    """
    soup=BeautifulSoup(html,"html.parser")
    candidates=[]
    for table in soup.find_all("table"):
        txt=table.get_text(" ",strip=True)
        # Odds table is by far the numeric-dense table on odds3t.
        if "オッズ" in txt or len(re.findall(r"\d+\.\d+|\d{2,4}",txt))>50:
            candidates.append(table)

    best={}
    for table in candidates:
        odds={}
        for tr in table.find_all("tr"):
            cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
            # Normalize cell text; some DOM cells contain line breaks.
            flat=[]
            for c in cells:
                parts=[x for x in re.split(r"\s+",c) if x]
                flat.extend(parts)

            # Search row for repeated second/third/odds triples.
            # Group order corresponds to first boat 1..6 in official layout.
            triples=[]
            i=0
            while i+2<len(flat):
                if flat[i] in "123456" and flat[i+1] in "123456":
                    val=_num(flat[i+2])
                    if val is not None and val>=1.0:
                        triples.append((int(flat[i]),int(flat[i+1]),val))
                        i+=3; continue
                i+=1

            if not triples:
                continue
            # A normal visible odds row carries up to six groups.
            for group,(second,third,val) in enumerate(triples[:6],1):
                first=group
                if len({first,second,third})==3:
                    odds[f"{first}{second}{third}"]=val

        if len(odds)>len(best):
            best=odds

    # Do not pretend a partial page is complete.
    if best and len(best)<100:
        raise ValueError(f"3連単オッズ解析件数が不足しています: {len(best)}/120")
    return best

def upsert_deadlines(con,race_date,jcd,deadlines):
    for rno,t in deadlines.items():
        rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
        con.execute("""INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status)
                       VALUES(?,?,?,?,?,'scheduled')
                       ON CONFLICT(race_date,jcd,race_no)
                       DO UPDATE SET deadline=excluded.deadline""",
                    (rid,race_date,jcd,rno,t))
    con.commit()

def store_odds(con,race_id,odds,fetched_at=None):
    fetched_at=fetched_at or datetime.now().astimezone().isoformat(timespec="seconds")
    cur=con.execute("INSERT INTO odds_snapshots(race_id,fetched_at) VALUES(?,?)",(race_id,fetched_at))
    sid=cur.lastrowid
    for combo,val in odds.items():
        a,b,c=map(int,combo)
        con.execute("""INSERT INTO odds_trifecta
                       (snapshot_id,first_boat,second_boat,third_boat,odds)
                       VALUES(?,?,?,?,?)""",(sid,a,b,c,val))
    con.commit()
    return sid

def refresh_one(con,race_date,jcd,race_no,cache_dir="cache/live"):
    url=official_url("odds3t",race_date,jcd,race_no)
    html,source=fetch_html(url,cache_dir=cache_dir)
    deadlines=parse_deadlines(html)
    if deadlines:
        upsert_deadlines(con,race_date,jcd,deadlines)
    odds=parse_trifecta_odds(html)
    rid=f"{race_date.replace('-','')}-{jcd}-{race_no:02d}"
    if len(odds)!=120:
        raise ValueError(f"official odds parse incomplete: {len(odds)}")
    sid=store_odds(con,rid,odds)
    return {"race_id":rid,"snapshot_id":sid,"odds_count":len(odds),"source":source,"url":url}

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--date",required=True)
    ap.add_argument("--jcd",required=True)
    ap.add_argument("--race",type=int,required=True)
    ap.add_argument("--cache-dir",default="cache/live")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    print(refresh_one(con,a.date,a.jcd,a.race,a.cache_dir))
