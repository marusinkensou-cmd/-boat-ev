from validation_engine_v166 import _virtual_investment_plan
from validation_store_v166 import _score_row

def make_plan(n):
    return {'buy_plan':{'bets':[{'combination':f'1-2-{i%6+1}','reason':'本線'} for i in range(n)]}}

# Use unique combos explicitly for stable test.
pr={'buy_plan':{'bets':[
 {'combination':'1-2-3','reason':'本線'}, {'combination':'1-3-2','reason':'本線'},
 {'combination':'2-1-3','reason':'本線'}, {'combination':'2-3-1','reason':'本線'},
 {'combination':'3-1-2','reason':'本線'}, {'combination':'3-2-1','reason':'本線'}]}}
vp=_virtual_investment_plan(pr)
assert vp['stake_yen']==1000, vp
assert all(b['stake_yen'] in (100,200) for b in vp['bets'])
assert sum(1 for b in vp['bets'] if b['stake_yen']==200)==4
payload={'first_rank':[{'boat':1},{'boat':2},{'boat':3}], 'virtual_plan':vp}
vals=_score_row(payload,'1-2-3',3550)
assert vals[3]==1
assert vals[7]==1000
assert vals[8] in (3550,7100)
assert vals[9]==vals[8]-1000
print('v167 virtual investment tests passed', vp)
