from __future__ import annotations
import re
from bs4 import BeautifulSoup
from official_live_v10 import fetch_html,official_url,parse_deadlines
from today_discovery_v12 import VENUES

TRANS=str.maketrans("１２３４５６","123456")

def parse_racelist_entries(html):
    soup=BeautifulSoup(html,"html.parser")
    entries=[]
    for tr in soup.find_all("tr"):
        cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
        if not cells: continue
        first=re.sub(r"\s+","",cells[0]).translate(TRANS)
        if first not in {"1","2","3","4","5","6"}: continue
        joined=" | ".join(cells)
        mr=re.search(r"\b(\d{4})\s*/\s*(A1|A2|B1|B2)",joined)
        if not mr: continue
        racer_no=int(mr.group(1)); clazz=mr.group(2)
        mf=re.search(r"F(\d+)",joined); ml=re.search(r"L(\d+)",joined)
        mst=re.search(r"L\d+\s+([01]\.\d{2})",joined)
        mw=re.search(r"(\d{1,2})歳\s*/\s*(\d{2}(?:\.\d)?)kg",joined)

        numeric_cells=[]
        for c in cells[2:]:
            toks=re.findall(r"\d+(?:\.\d+)?",c)
            numeric_cells.append(toks)

        national=local=(None,None,None)
        motor=hull=(None,None,None)
        if len(cells)>=7:
            def three(cell):
                x=re.findall(r"\d+(?:\.\d+)?",cell)
                return tuple(x[:3]) if len(x)>=3 else (None,None,None)
            national=three(cells[3]) if len(cells)>3 else national
            local=three(cells[4]) if len(cells)>4 else local
            motor=three(cells[5]) if len(cells)>5 else motor
            hull=three(cells[6]) if len(cells)>6 else hull

        entries.append({
            "boat_no":int(first),"racer_no":racer_no,"class":clazz,
            "f_count":int(mf.group(1)) if mf else None,
            "l_count":int(ml.group(1)) if ml else None,
            "avg_st":float(mst.group(1)) if mst else None,
            "weight_kg":float(mw.group(2)) if mw else None,
            "national_win_rate":float(national[0]) if national[0] else None,
            "local_win_rate":float(local[0]) if local[0] else None,
            "motor_no":int(float(motor[0])) if motor[0] else None,
            "motor_quinella_rate":float(motor[1]) if motor[1] else None,
            "motor_trio_rate":float(motor[2]) if motor[2] else None,
            "boat_no_machine":int(float(hull[0])) if hull[0] else None,
            "boat_quinella_rate":float(hull[1]) if hull[1] else None,
            "boat_trio_rate":float(hull[2]) if hull[2] else None,
        })
    uniq={e["boat_no"]:e for e in entries}
    return [uniq[k] for k in sorted(uniq)]

def seed_venue_races(con,race_date,jcd,cache_dir="cache/live"):
    html,source=fetch_html(official_url("racelist",race_date,jcd,1),cache_dir=cache_dir,max_age_sec=300,timeout=10)
    deadlines=parse_deadlines(html)
    if len(deadlines)!=12:
        raise ValueError(f"{jcd}: 締切時刻が12R分取得できません: {len(deadlines)}")
    con.execute("INSERT OR IGNORE INTO stadiums(jcd,name) VALUES(?,?)",(jcd,VENUES[jcd]))
    for rno,dl in deadlines.items():
        rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
        con.execute("""INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status)
                       VALUES(?,?,?,?,?,'scheduled')
                       ON CONFLICT(race_date,jcd,race_no)
                       DO UPDATE SET deadline=excluded.deadline""",(rid,race_date,jcd,rno,dl))
    con.commit()
    return source

def refresh_racelist(con,race_date,jcd,rno,cache_dir="cache/live"):
    html,source=fetch_html(official_url("racelist",race_date,jcd,rno),cache_dir=cache_dir,max_age_sec=120,timeout=8)
    entries=parse_racelist_entries(html)
    if len(entries)!=6:
        raise ValueError(f"{jcd} {rno}R: 出走表6艇を取得できません: {len(entries)}")
    rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
    for e in entries:
        con.execute("""INSERT INTO entries(
          race_id,boat_no,racer_no,class,national_win_rate,local_win_rate,avg_st,
          f_count,l_count,motor_no,motor_quinella_rate,motor_trio_rate,
          boat_no_machine,boat_quinella_rate,boat_trio_rate,weight_kg)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(race_id,boat_no) DO UPDATE SET
          racer_no=excluded.racer_no,class=excluded.class,national_win_rate=excluded.national_win_rate,
          local_win_rate=excluded.local_win_rate,avg_st=excluded.avg_st,f_count=excluded.f_count,
          l_count=excluded.l_count,motor_no=excluded.motor_no,motor_quinella_rate=excluded.motor_quinella_rate,
          motor_trio_rate=excluded.motor_trio_rate,boat_no_machine=excluded.boat_no_machine,
          boat_quinella_rate=excluded.boat_quinella_rate,boat_trio_rate=excluded.boat_trio_rate,
          weight_kg=excluded.weight_kg""",
          (rid,e["boat_no"],e["racer_no"],e["class"],e["national_win_rate"],e["local_win_rate"],
           e["avg_st"],e["f_count"],e["l_count"],e["motor_no"],e["motor_quinella_rate"],
           e["motor_trio_rate"],e["boat_no_machine"],e["boat_quinella_rate"],e["boat_trio_rate"],e["weight_kg"]))
    con.commit()
    return {"race_id":rid,"entries":6,"source":source}
