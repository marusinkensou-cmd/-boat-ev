from __future__ import annotations
import argparse,json,mimetypes,sqlite3
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse
from nationwide_board_v09 import build_board
from refresh_service_v13 import refresh_for_iphone
from virtual_ledger_v14 import stats,grade_stats
JST=ZoneInfo("Asia/Tokyo")

class App:
    def __init__(self,db,static_dir): self.db=db; self.static_dir=Path(static_dir)
    def board(self):
        con=sqlite3.connect(self.db)
        try:
            now=datetime.now(JST)
            return {"generated_at":now.isoformat(),"board":build_board(con,now)}
        finally: con.close()
    def refresh(self):
        con=sqlite3.connect(self.db)
        try:return refresh_for_iphone(con,datetime.now(JST))
        finally:con.close()
    def stats(self):
        con=sqlite3.connect(self.db)
        try:
            today=datetime.now(JST).date().isoformat()
            return {"today":stats(con,today),"all":stats(con),"by_grade":grade_stats(con)}
        finally:con.close()

def make_handler(app):
    class H(BaseHTTPRequestHandler):
        def sendx(self,status,body,ctype="application/json; charset=utf-8"):
            self.send_response(status);self.send_header("Content-Type",ctype)
            self.send_header("Cache-Control","no-store" if self.path.startswith("/api/") else "public,max-age=60")
            self.end_headers();self.wfile.write(body if isinstance(body,bytes) else body.encode("utf-8"))
        def do_GET(self):
            p=urlparse(self.path).path
            if p=="/api/health":return self.sendx(200,json.dumps({"ok":True}))
            if p=="/api/board":
                try:return self.sendx(200,json.dumps(app.board(),ensure_ascii=False))
                except Exception as e:return self.sendx(500,json.dumps({"error":str(e)},ensure_ascii=False))
            if p=="/api/stats":
                try:return self.sendx(200,json.dumps(app.stats(),ensure_ascii=False))
                except Exception as e:return self.sendx(500,json.dumps({"error":str(e)},ensure_ascii=False))
            rel="index.html" if p=="/" else p.lstrip("/")
            f=(app.static_dir/rel).resolve()
            try:f.relative_to(app.static_dir.resolve())
            except:return self.sendx(403,"forbidden","text/plain")
            if not f.is_file():return self.sendx(404,"not found","text/plain")
            return self.sendx(200,f.read_bytes(),mimetypes.guess_type(str(f))[0] or "application/octet-stream")
        def do_POST(self):
            if urlparse(self.path).path!="/api/refresh":return self.sendx(404,"not found","text/plain")
            try:return self.sendx(200,json.dumps(app.refresh(),ensure_ascii=False))
            except Exception as e:return self.sendx(500,json.dumps({"error":str(e)},ensure_ascii=False))
        def log_message(self,*args):pass
    return H

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--host",default="0.0.0.0");ap.add_argument("--port",type=int,default=8080)
    ap.add_argument("--static",default="pwa")
    a=ap.parse_args()
    ThreadingHTTPServer((a.host,a.port),make_handler(App(a.db,a.static))).serve_forever()
