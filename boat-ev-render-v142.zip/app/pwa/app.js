let DATA=[]; let FILTER="all";

function fmtPct(v){ return (v*100).toFixed(1)+"%"; }
function esc(s){ return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m])); }
function yen(v){ return "¥"+Number(v||0).toLocaleString("ja-JP"); }
function visible(r){
  if(FILTER==="all") return true;
  if(FILTER==="buy") return r.grade!=="PASS";
  if(FILTER==="pass") return r.grade==="PASS";
  return r.grade===FILTER;
}

function render(){
  const rows=DATA.filter(visible);
  document.getElementById("buyCount").textContent=DATA.filter(r=>!["PASS","DATA"].includes(r.grade)).length;
  document.getElementById("passCount").textContent=DATA.filter(r=>r.grade==="PASS").length;
  const future=DATA.filter(r=>r.minutes_to_deadline>=0);
  document.getElementById("nextMin").textContent=future.length?Math.max(0,Math.round(future[0].minutes_to_deadline)):"-";

  if(!rows.length){
    document.getElementById("list").innerHTML='<div class="empty">現在、締切90分以内のレースはありません。<br>開催時間帯に「最新に更新」を押してください。</div>'; return;
  }
  document.getElementById("list").innerHTML=rows.map(r=>{
    const dataMissing=r.grade==="DATA";
    const passed=r.grade==="PASS" || dataMissing;
    const mins=r.minutes_to_deadline>=0?`締切まで ${Math.round(r.minutes_to_deadline)}分`:`締切 ${Math.abs(Math.round(r.minutes_to_deadline))}分経過`;
    const best=dataMissing?`データ不足<small>出走表またはオッズ未取得のため判定しません</small>`:
      passed?`見送り<small>EV条件を満たす買い目なし</small>`:
      `${esc(r.best_combo)} <small>EV ${Number(r.best_ev).toFixed(2)} / ${Number(r.best_odds).toFixed(1)}倍 / 予測 ${fmtPct(r.best_prob)}</small>`;
    const bets=(r.bets||[]).slice(0,6).map(b=>`
      <div class="bet"><div class="combo">${esc(b.combination)}</div>
      <span>予測<br>${fmtPct(b.predicted_prob)}</span><span>適正<br>${Number(b.fair_odds).toFixed(1)}倍</span>
      <strong>EV ${Number(b.ev).toFixed(2)}<br>${Number(b.market_odds).toFixed(1)}倍</strong></div>`).join("");
    return `<section class="card ${passed?"pass":""}"><div class="cardhead">
      <div><span class="venue">${esc(r.venue)}</span><span class="race">${r.race_no}R</span><div class="deadline">${mins}</div></div>
      <div class="badge ${esc(r.grade)}">${dataMissing?"データ不足":passed?"見送り":esc(r.grade)+"評価"}</div></div>
      <div class="best">${best}</div>${bets}</section>`;
  }).join("");
}

function renderStats(payload){
  const t=payload?.today||{}; const a=payload?.all||{};
  document.getElementById("paperRaces").textContent=t.settled_races||0;
  document.getElementById("paperStake").textContent=yen(t.stake_yen);
  document.getElementById("paperReturn").textContent=yen(t.return_yen);
  document.getElementById("paperRate").textContent=t.recovery_rate==null?"-":Number(t.recovery_rate).toFixed(1)+"%";
  document.getElementById("paperAll").textContent=a.stake_yen?`累計 ${a.settled_races}R / 投資 ${yen(a.stake_yen)} / 払戻 ${yen(a.return_yen)} / 回収率 ${Number(a.recovery_rate).toFixed(1)}% / 収支 ${a.profit_yen>=0?"+":""}${yen(a.profit_yen).replace("¥","")}円`:`累計データなし — 今日から自動記録します`;
}
async function fetchStats(){
  const res=await fetch("/api/stats",{cache:"no-store"});
  if(res.ok) renderStats(await res.json());
}
async function fetchBoard(){
  const res=await fetch("/api/board",{cache:"no-store"});
  if(!res.ok) throw new Error("HTTP "+res.status);
  const payload=await res.json(); DATA=payload.board||[];
  document.getElementById("updated").textContent="更新 "+new Date(payload.generated_at).toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit"}); render();
}
async function refreshLive(){
  const btn=document.getElementById("refresh");btn.disabled=true;btn.textContent="取得中…";
  document.getElementById("updated").textContent="公式データ更新中";
  const ctl=new AbortController();
  const slow=setTimeout(()=>{document.getElementById("updated").textContent="取得に時間がかかっています…";},20000);
  const timeout=setTimeout(()=>ctl.abort(),90000);
  try{
    const res=await fetch("/api/refresh",{method:"POST",cache:"no-store",signal:ctl.signal});
    if(!res.ok){
      let msg="HTTP "+res.status;
      try{const e=await res.json(); if(e?.error) msg=e.error;}catch(_){}
      throw new Error(msg);
    }
    const payload=await res.json(); DATA=payload.board||[];
    document.getElementById("updated").textContent=`${payload.venues_found||0}場 / ${payload.races_updated||0}R更新`;
    render(); renderStats({today:payload.stats_today,all:payload.stats_all});
  }catch(e){
    const msg=e?.name==="AbortError"?"90秒でタイムアウトしました":`${e.message} (${location.origin})`;
    document.getElementById("updated").textContent="更新失敗";
    document.getElementById("list").innerHTML='<div class="error">最新情報を取得できませんでした。<br>'+esc(msg)+'</div>';
  }finally{
    clearTimeout(slow); clearTimeout(timeout);
    btn.disabled=false;btn.textContent="最新に更新";
  }
}
async function load(){
  try{await Promise.all([fetchBoard(),fetchStats()]);}
  catch(e){document.getElementById("list").innerHTML='<div class="error">データを取得できませんでした。<br>'+esc(e.message)+'</div>';}
}
document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll("[data-filter]").forEach(x=>x.classList.remove("active"));b.classList.add("active");FILTER=b.dataset.filter;render();}));
document.getElementById("refresh").addEventListener("click",refreshLive);
if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
load();
