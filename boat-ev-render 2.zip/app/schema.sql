PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS raw_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK(kind IN ('B','K','RACER')),
  target_date TEXT,
  source_url TEXT NOT NULL,
  local_path TEXT NOT NULL,
  sha256 TEXT,
  size_bytes INTEGER,
  downloaded_at TEXT NOT NULL,
  parse_status TEXT NOT NULL DEFAULT 'pending',
  parse_message TEXT
);

CREATE TABLE IF NOT EXISTS stadiums (jcd TEXT PRIMARY KEY, name TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS racers (
  racer_no INTEGER PRIMARY KEY, name_kanji TEXT, name_kana TEXT, branch TEXT, class TEXT,
  birth_era TEXT, birth_ymd TEXT, sex INTEGER, age INTEGER, height_cm INTEGER,
  weight_kg REAL, blood_type TEXT, training_term INTEGER, hometown TEXT, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS racer_term_stats (
  racer_no INTEGER NOT NULL, year INTEGER NOT NULL, term INTEGER NOT NULL,
  period_from TEXT, period_to TEXT, class TEXT, win_rate REAL, quinella_rate REAL,
  first_count INTEGER, second_count INTEGER, starts INTEGER, finals INTEGER, wins INTEGER,
  avg_st REAL, ability_index_prev REAL, ability_index_current REAL,
  PRIMARY KEY (racer_no, year, term),
  FOREIGN KEY (racer_no) REFERENCES racers(racer_no)
);

CREATE TABLE IF NOT EXISTS racer_course_stats (
  racer_no INTEGER NOT NULL, year INTEGER NOT NULL, term INTEGER NOT NULL,
  course INTEGER NOT NULL CHECK(course BETWEEN 1 AND 6),
  entries INTEGER, quinella_rate REAL, avg_st REAL, avg_st_rank REAL,
  first_count INTEGER, second_count INTEGER, third_count INTEGER,
  fourth_count INTEGER, fifth_count INTEGER, sixth_count INTEGER,
  f_count INTEGER, l0_count INTEGER, l1_count INTEGER, k0_count INTEGER, k1_count INTEGER,
  s0_count INTEGER, s1_count INTEGER, s2_count INTEGER,
  PRIMARY KEY (racer_no, year, term, course),
  FOREIGN KEY (racer_no) REFERENCES racers(racer_no)
);

CREATE TABLE IF NOT EXISTS races (
  race_id TEXT PRIMARY KEY, race_date TEXT NOT NULL, jcd TEXT NOT NULL,
  race_no INTEGER NOT NULL CHECK(race_no BETWEEN 1 AND 12),
  race_name TEXT, race_type TEXT, deadline TEXT, status TEXT,
  UNIQUE(race_date, jcd, race_no),
  FOREIGN KEY (jcd) REFERENCES stadiums(jcd)
);

CREATE TABLE IF NOT EXISTS entries (
  race_id TEXT NOT NULL, boat_no INTEGER NOT NULL CHECK(boat_no BETWEEN 1 AND 6),
  racer_no INTEGER, class TEXT, national_win_rate REAL, local_win_rate REAL, avg_st REAL,
  f_count INTEGER, l_count INTEGER, motor_no INTEGER, motor_quinella_rate REAL,
  motor_trio_rate REAL, boat_no_machine INTEGER, boat_quinella_rate REAL,
  boat_trio_rate REAL, weight_kg REAL,
  PRIMARY KEY (race_id, boat_no),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS beforeinfo (
  race_id TEXT NOT NULL, boat_no INTEGER NOT NULL, exhibition_time REAL, tilt REAL,
  exhibition_course INTEGER, exhibition_st REAL,
  PRIMARY KEY (race_id, boat_no),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS race_weather (
  race_id TEXT PRIMARY KEY, weather TEXT, air_temp_c REAL, water_temp_c REAL,
  wind_dir TEXT, wind_speed_m REAL, wave_height_cm REAL,
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS results (
  race_id TEXT NOT NULL, boat_no INTEGER NOT NULL, finish INTEGER, actual_course INTEGER,
  st REAL, status_code TEXT,
  PRIMARY KEY (race_id, boat_no),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS race_result_meta (
  race_id TEXT PRIMARY KEY, winning_technique TEXT, trifecta_combo TEXT,
  trifecta_payout_yen INTEGER,
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS odds_snapshots (
  snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
  fetched_at TEXT NOT NULL, official_updated_at TEXT,
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS odds_trifecta (
  snapshot_id INTEGER NOT NULL, first_boat INTEGER NOT NULL, second_boat INTEGER NOT NULL,
  third_boat INTEGER NOT NULL, odds REAL,
  PRIMARY KEY (snapshot_id, first_boat, second_boat, third_boat),
  FOREIGN KEY (snapshot_id) REFERENCES odds_snapshots(snapshot_id)
);

CREATE TABLE IF NOT EXISTS predictions (
  prediction_id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
  created_at TEXT NOT NULL, model_version TEXT NOT NULL, combo TEXT NOT NULL,
  predicted_prob REAL NOT NULL, market_odds REAL, expected_value REAL,
  rank_no INTEGER, bet_flag INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS backtest_runs (
  run_id INTEGER PRIMARY KEY AUTOINCREMENT, model_version TEXT NOT NULL,
  date_from TEXT NOT NULL, date_to TEXT NOT NULL, rule_name TEXT NOT NULL,
  races_seen INTEGER NOT NULL, races_bet INTEGER NOT NULL, tickets_bet INTEGER NOT NULL,
  stake_yen INTEGER NOT NULL, return_yen INTEGER NOT NULL, hit_tickets INTEGER NOT NULL,
  recovery_rate REAL NOT NULL, created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_races_date ON races(race_date);
CREATE INDEX IF NOT EXISTS idx_entries_racer ON entries(racer_no);
CREATE INDEX IF NOT EXISTS idx_results_finish ON results(finish);
CREATE INDEX IF NOT EXISTS idx_predictions_race ON predictions(race_id);


CREATE TABLE IF NOT EXISTS payouts (
  race_id TEXT NOT NULL,
  bet_type TEXT NOT NULL,
  combination TEXT NOT NULL,
  amount_yen INTEGER NOT NULL,
  popularity INTEGER,
  PRIMARY KEY (race_id, bet_type, combination),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

ALTER TABLE results ADD COLUMN race_time TEXT;


CREATE TABLE IF NOT EXISTS external_sources (
  source_id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT NOT NULL,
  source_name TEXT NOT NULL,
  source_url TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  base_trust REAL NOT NULL DEFAULT 0.50,
  notes TEXT,
  UNIQUE(platform, source_name)
);

CREATE TABLE IF NOT EXISTS external_posts (
  post_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  external_id TEXT,
  posted_at TEXT,
  collected_at TEXT NOT NULL,
  url TEXT,
  raw_text TEXT NOT NULL,
  race_date TEXT,
  jcd TEXT,
  race_no INTEGER,
  racer_no INTEGER,
  boat_no INTEGER,
  motor_no INTEGER,
  FOREIGN KEY(source_id) REFERENCES external_sources(source_id)
);

CREATE TABLE IF NOT EXISTS external_signals (
  signal_id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_value TEXT,
  polarity REAL NOT NULL,
  confidence REAL NOT NULL DEFAULT 0.50,
  evidence_text TEXT,
  FOREIGN KEY(post_id) REFERENCES external_posts(post_id)
);

CREATE TABLE IF NOT EXISTS source_scores (
  source_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  samples INTEGER NOT NULL DEFAULT 0,
  correct REAL NOT NULL DEFAULT 0,
  weighted_score REAL NOT NULL DEFAULT 0.50,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(source_id, category),
  FOREIGN KEY(source_id) REFERENCES external_sources(source_id)
);

CREATE TABLE IF NOT EXISTS external_race_adjustments (
  race_id TEXT NOT NULL,
  boat_no INTEGER NOT NULL,
  category TEXT NOT NULL,
  signal_count INTEGER NOT NULL,
  weighted_signal REAL NOT NULL,
  adjustment REAL NOT NULL,
  generated_at TEXT NOT NULL,
  PRIMARY KEY(race_id, boat_no, category),
  FOREIGN KEY(race_id) REFERENCES races(race_id)
);


CREATE TABLE IF NOT EXISTS beforeinfo_extra (
  race_id TEXT NOT NULL,
  boat_no INTEGER NOT NULL,
  propeller_changed INTEGER DEFAULT 0,
  parts_changed TEXT,
  PRIMARY KEY (race_id, boat_no),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS live_quality (
  race_id TEXT PRIMARY KEY,
  racelist_ok INTEGER DEFAULT 0,
  beforeinfo_ok INTEGER DEFAULT 0,
  odds_ok INTEGER DEFAULT 0,
  updated_at TEXT,
  note TEXT,
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

-- v1.4: paper-trading ledger for unbiased model validation.
CREATE TABLE IF NOT EXISTS virtual_plans (
  plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
  race_id TEXT NOT NULL,
  model_version TEXT NOT NULL DEFAULT 'C1',
  grade TEXT NOT NULL,
  decision TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  stake_per_ticket INTEGER NOT NULL DEFAULT 100,
  settled_at TEXT,
  result_combo TEXT,
  payout_per_100 INTEGER,
  total_stake INTEGER NOT NULL DEFAULT 0,
  total_return INTEGER NOT NULL DEFAULT 0,
  settle_note TEXT,
  UNIQUE(race_id, model_version),
  FOREIGN KEY (race_id) REFERENCES races(race_id)
);

CREATE TABLE IF NOT EXISTS virtual_bets (
  plan_id INTEGER NOT NULL,
  combination TEXT NOT NULL,
  predicted_prob REAL NOT NULL,
  market_odds REAL NOT NULL,
  expected_value REAL NOT NULL,
  stake_yen INTEGER NOT NULL DEFAULT 100,
  hit INTEGER,
  return_yen INTEGER,
  PRIMARY KEY (plan_id, combination),
  FOREIGN KEY (plan_id) REFERENCES virtual_plans(plan_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_virtual_plans_settle ON virtual_plans(settled_at, race_id);
