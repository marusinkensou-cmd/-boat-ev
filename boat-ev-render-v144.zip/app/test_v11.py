import sqlite3,tempfile,json,threading,urllib.request,time
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from parse_bk import ensure_schema
from server_v11 import App,make_handler
from http.server import ThreadingHTTPServer

JST=ZoneInfo("Asia/Tokyo")
with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    today=datetime.now(JST).date().isoformat()
    # valid future-ish time for board parser, no odds => graceful no_odds/PASS-like omission logic
    hh=(datetime.now(JST).hour+1)%24
    dl=f"{hh:02d}:00"
    rid=f"{today.replace('-','')}-02-01"
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status) VALUES(?,?,?,?,?,?)",
                (rid,today,'02',1,dl,'scheduled'))
    con.commit(); con.close()

    app=App(str(db),str(Path(__file__).with_name("pwa")))
    payload=app.board()
    assert "generated_at" in payload and "board" in payload
    assert (Path(__file__).with_name("pwa")/"index.html").exists()
    assert (Path(__file__).with_name("pwa")/"manifest.webmanifest").exists()
    assert (Path(__file__).with_name("pwa")/"sw.js").exists()
    print("v1.1 iPhone PWA test: OK")
