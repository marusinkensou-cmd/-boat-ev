from dataclasses import dataclass
from math import exp
from itertools import permutations

@dataclass
class BoatFeatures:
    boat_no: int
    racer_strength: float = 0.0
    course_fit: float = 0.0
    local_fit: float = 0.0
    recent_form: float = 0.0
    st_strength: float = 0.0
    motor_strength: float = 0.0
    exhibition_strength: float = 0.0
    weather_fit: float = 0.0

WEIGHTS = {
    "racer_strength": 0.25,
    "course_fit": 0.20,
    "motor_strength": 0.15,
    "local_fit": 0.10,
    "recent_form": 0.10,
    "st_strength": 0.10,
    "exhibition_strength": 0.05,
    "weather_fit": 0.05,
}

def raw_score(b):
    return sum(getattr(b, k) * w for k, w in WEIGHTS.items())

def trifecta_probs(boats):
    s = {b.boat_no: exp(raw_score(b) * 4.0) for b in boats}
    out = {}
    for a,b,c in permutations(s.keys(), 3):
        p1 = s[a] / sum(s.values())
        p2 = s[b] / sum(v for k,v in s.items() if k != a)
        p3 = s[c] / sum(v for k,v in s.items() if k not in (a,b))
        out[(a,b,c)] = p1*p2*p3
    return out

def recommend(boats, market_odds, min_ev=1.10, top_n=5):
    probs = trifecta_probs(boats)
    rows = []
    for combo,p in probs.items():
        odds = market_odds.get(combo)
        if odds:
            ev = p * odds
            if ev >= min_ev:
                rows.append((combo,p,odds,ev))
    rows.sort(key=lambda x:(x[3],x[1]), reverse=True)
    return rows[:top_n]
