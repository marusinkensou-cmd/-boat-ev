from __future__ import annotations
import argparse, sqlite3, subprocess, shutil, tempfile
from pathlib import Path

VENUES = {
"01":"桐生","02":"戸田","03":"江戸川","04":"平和島","05":"多摩川","06":"浜名湖",
"07":"蒲郡","08":"常滑","09":"津","10":"三国","11":"びわこ","12":"住之江",
"13":"尼崎","14":"鳴門","15":"丸亀","16":"児島","17":"宮島","18":"徳山",
"19":"下関","20":"若松","21":"芦屋","22":"福岡","23":"唐津","24":"大村"
}
WEATHER = {"1":"晴","2":"曇","3":"雨","4":"霧","5":"雪"}

def si(s, default=None):
    try: return int(str(s).strip())
    except: return default

def sf(s, scale=1.0, default=None):
    v = si(s, None)
    return default if v is None else v * scale

def ensure_schema(con, schema_path):
    text = Path(schema_path).read_text(encoding="utf-8")
    # tolerate duplicate-column ALTER on repeated init
    stmts = [x.strip() for x in text.split(";") if x.strip()]
    for st in stmts:
        try:
            con.execute(st)
        except sqlite3.OperationalError as e:
            if "duplicate column name" not in str(e).lower():
                raise
    for code,name in VENUES.items():
        con.execute("INSERT OR IGNORE INTO stadiums(jcd,name) VALUES(?,?)",(code,name))
    con.commit()

def extract_lzh(path: Path, outdir: Path) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    # 1) python lhafile
    try:
        import lhafile
        with lhafile.Lhafile(str(path)) as arc:
            names = arc.namelist()
            out = []
            for name in names:
                target = outdir / Path(name).name
                target.write_bytes(arc.read(name))
                out.append(target)
            return out
    except Exception:
        pass
    # 2) 7z / 7zz / lha
    for exe, args in [
        ("7z", ["x", "-y", f"-o{outdir}", str(path)]),
        ("7zz", ["x", "-y", f"-o{outdir}", str(path)]),
        ("lha", ["x", str(path), str(outdir)]),
    ]:
        if shutil.which(exe):
            subprocess.run([exe, *args], check=True, capture_output=True)
            return [p for p in outdir.rglob("*") if p.is_file()]
    raise RuntimeError("LZH展開には lhafile または 7z/7zz/lha が必要です。")

class KParser:
    def __init__(self, date, con):
        self.date, self.con = date, con
        self.venue = ""
        self.race_id = None

    def race_key(self, venue, rno):
        return f"{self.date.replace('-','')}-{venue}-{int(rno):02d}"

    def parse(self, text):
        for raw in text.splitlines():
            line = raw.rstrip("\r\n")
            if len(line) < 2: continue
            rt = line[:2]
            if rt == "T0":
                if len(line) >= 4: self.venue = line[2:4].strip()
            elif rt == "TH":
                self.parse_th(line)
            elif rt[0:1] == "T" and rt[1:2] in "123456":
                self.parse_boat(line)
            elif rt == "T7":
                self.parse_payout(line)

    def parse_th(self, line):
        if len(line) < 20: return
        venue = line[2:4].strip() or self.venue
        rno = si(line[4:6])
        if not venue or rno is None: return
        self.venue = venue
        rid = self.race_key(venue, rno)
        self.race_id = rid
        self.con.execute("""INSERT OR IGNORE INTO races
          (race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)""",
          (rid,self.date,venue,rno,"finished"))
        self.con.execute("""INSERT OR REPLACE INTO race_weather
          (race_id,weather,water_temp_c,wind_dir,wind_speed_m,wave_height_cm)
          VALUES(?,?,?,?,?,?)""",(
            rid,
            WEATHER.get(line[7:8], line[7:8] or None),
            sf(line[12:16],0.1),
            line[8:10].strip() or None,
            sf(line[10:12],1.0),
            sf(line[16:20],1.0)
          ))

    def parse_boat(self, line):
        if not self.race_id or len(line) < 14: return
        boat = si(line[1:2]); course = si(line[2:3]); racer = si(line[3:8])
        rank_s = line[8:9].strip()
        rank = si(rank_s) if rank_s.isdigit() else None
        race_time = line[9:14].strip() or None
        st_raw = line[14:17].strip() if len(line) >= 17 else ""
        st = None
        try:
            if st_raw:
                st = float(st_raw) / 100.0 if st_raw.replace("-","").isdigit() else float(st_raw)
        except: pass
        self.con.execute("""INSERT OR REPLACE INTO results
          (race_id,boat_no,finish,actual_course,st,status_code,race_time)
          VALUES(?,?,?,?,?,?,?)""",
          (self.race_id,boat,rank,course,st,None if rank else rank_s or None,race_time))

    def parse_payout(self, line):
        # Official fixed-length layout varies historically; this implements the modern
        # compact T7 layout used by public parser implementations. We validate against
        # result combination before using it in backtests.
        if not self.race_id or len(line) < 12: return
        pos = 2
        first, second, third = line[pos:pos+1].strip(), line[pos+1:pos+2].strip(), line[pos+2:pos+3].strip()
        pos += 3
        def read_ticket(bet, combo):
            nonlocal pos
            if pos + 7 > len(line): return
            amount = si(line[pos:pos+5]); pop = si(line[pos+5:pos+7]); pos += 7
            if amount and combo:
                self.con.execute("""INSERT OR REPLACE INTO payouts
                (race_id,bet_type,combination,amount_yen,popularity) VALUES(?,?,?,?,?)""",
                (self.race_id,bet,combo,amount*10,pop))
        read_ticket("単勝", first)
        for b in (first,second,third): read_ticket("複勝", b)
        for c in ("".join(sorted((first,second))),"".join(sorted((first,third))),"".join(sorted((second,third)))):
            read_ticket("拡連複", c)
        read_ticket("2連複","".join(sorted((first,second))))
        read_ticket("2連単",first+second)
        read_ticket("3連複","".join(sorted((first,second,third))))
        read_ticket("3連単",first+second+third)

class BParser:
    def __init__(self, date, con):
        self.date, self.con = date, con
        self.venue, self.race_id = "", None

    def race_key(self, venue, rno):
        return f"{self.date.replace('-','')}-{venue}-{int(rno):02d}"

    def parse(self, raw_bytes):
        # Keep bytes for byte-accurate Shift-JIS fixed-width slicing.
        lines = raw_bytes.replace(b"\r\n", b"\n").split(b"\n")
        for raw in lines:
            if len(raw) < 2: continue
            try: rt = raw[:2].decode("ascii")
            except: continue
            if rt == "BB":
                try: self.venue = raw[2:4].decode("ascii").strip()
                except: pass
            elif rt == "BH":
                self.parse_bh(raw)
            elif rt[:1] == "B" and rt[1:2] in "123456":
                self.parse_entry(raw)

    def parse_bh(self, raw):
        if len(raw) < 6: return
        try:
            venue = raw[2:4].decode("ascii").strip() or self.venue
            rno = int(raw[4:6])
        except: return
        self.venue = venue
        rid = self.race_key(venue, rno)
        self.race_id = rid
        self.con.execute("""INSERT OR IGNORE INTO races
          (race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)""",
          (rid,self.date,venue,rno,"scheduled"))

    def parse_entry(self, raw):
        if not self.race_id or len(raw) < 45: return
        def bi(a,b,default=None):
            try: return int(raw[a:b].decode("ascii").strip())
            except: return default
        def bf(a,b,scale=.01,default=None):
            v=bi(a,b,None); return default if v is None else v*scale
        try: boat=int(chr(raw[1]))
        except: return
        racer=bi(2,7)
        try: name=raw[7:15].decode("cp932",errors="replace").strip()
        except: name=""
        self.con.execute("""INSERT OR REPLACE INTO entries
          (race_id,boat_no,racer_no,national_win_rate,local_win_rate,avg_st,
           f_count,l_count,motor_no,motor_quinella_rate,boat_no_machine,
           boat_quinella_rate,weight_kg)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
            self.race_id, boat, racer,
            bf(29,33), bf(37,41), bf(25,29),
            bi(21,23,0), bi(23,25,0), bi(45,48),
            bf(48,52), bi(52,55), bf(55,59), bf(18,21,.1)
        ))
        # Minimal racer master upsert; fan data will enrich later.
        if racer:
            self.con.execute("""INSERT INTO racers
              (racer_no,name_kanji,updated_at)
              VALUES(?,?,datetime('now'))
              ON CONFLICT(racer_no) DO UPDATE SET
              name_kanji=COALESCE(excluded.name_kanji,racers.name_kanji),
              updated_at=datetime('now')""",(racer,name or None))

def parse_txt_file(path: Path, kind: str, date: str, con):
    raw = path.read_bytes()
    if kind == "K":
        text = raw.decode("cp932", errors="replace")
        KParser(date,con).parse(text)
    else:
        BParser(date,con).parse(raw)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--schema",default="schema.sql")
    ap.add_argument("--kind",choices=["B","K"],required=True)
    ap.add_argument("--date",required=True,help="YYYY-MM-DD")
    ap.add_argument("path")
    args=ap.parse_args()
    con=sqlite3.connect(args.db)
    ensure_schema(con,args.schema)
    p=Path(args.path)
    if p.suffix.lower()==".lzh":
        with tempfile.TemporaryDirectory() as td:
            files=extract_lzh(p,Path(td))
            for f in files: parse_txt_file(f,args.kind,args.date,con)
    else:
        parse_txt_file(p,args.kind,args.date,con)
    con.commit()
    print("parsed",args.kind,args.date,p)

if __name__=="__main__":
    main()
