import sqlite3, tempfile
from pathlib import Path
from build_features_v03 import rebuild

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.db"
    c=sqlite3.connect(db)
    c.executescript("""
    CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,jcd TEXT,race_no INTEGER);
    CREATE TABLE results(race_id TEXT,boat_no INTEGER,finish INTEGER,actual_course INTEGER);
    CREATE TABLE race_weather(race_id TEXT PRIMARY KEY,wind_speed_m REAL,wave_height_cm REAL);
    """)
    c.execute("INSERT INTO races VALUES('r1','2026-01-01','01',1)")
    c.execute("INSERT INTO race_weather VALUES('r1',4,3)")
    for boat in range(1,7):
        c.execute("INSERT INTO results VALUES(?,?,?,?)",('r1',boat,boat,boat))
    rebuild(c)
    row=c.execute("""SELECT starts,wins,win_rate FROM venue_condition_stats
                     WHERE jcd='01' AND course=1""").fetchone()
    assert row==(1,1,1.0),row
    print("v0.3 feature test: OK")
