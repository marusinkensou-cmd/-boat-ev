import sqlite3,tempfile
from pathlib import Path
from parse_bk import ensure_schema
from beforeinfo_live_v13 import parse_beforeinfo_v13
from live_quality_v13 import mark,status

rows=[]
sts=["F.01",".11",".17",".14",".19","F.01"]
for i in range(1,7):
    prop="プロペラ 新" if i==2 else ""
    part="リング" if i==3 else ""
    rows.append(f"<tr><td>{i}</td><td>52.0kg</td><td>6.{89+i:02d}</td><td>0.0</td><td>{prop}</td><td>{part}</td></tr>")
start="スタート展示 "+" ".join(f"{i} {sts[i-1]}" for i in range(1,7))
html=f"<div>晴 気温 33.0℃ 水温 32.0℃ 風速 2m 波高 1cm {start}</div><table>{''.join(rows)}</table>"
b,w=parse_beforeinfo_v13(html)
assert len(b)==6,b
assert b[0]["exhibition_course"]==1 and b[0]["exhibition_st"]<0,b[0]
assert b[1]["propeller_changed"]==1,b[1]
assert b[2]["parts_changed"]=="リング",b[2]
assert w["air_temp_c"]==33.0 and w["wave_height_cm"]==1.0,w

with tempfile.TemporaryDirectory() as td:
    con=sqlite3.connect(Path(td)/"x.sqlite")
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status) VALUES('r','2026-09-13','02',1,'12:00','scheduled')")
    con.commit()
    mark(con,"r","racelist_ok",True)
    mark(con,"r","odds_ok",False,"odds missing")
    q=status(con,"r")
    assert q["racelist_ok"] and not q["odds_ok"]
print("v1.3 real-structure parser/quality test: OK")
print("start exhibition:",[(x["boat_no"],x["exhibition_course"],x["exhibition_st"]) for x in b])
