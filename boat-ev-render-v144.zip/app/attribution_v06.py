from __future__ import annotations
import argparse, sqlite3, csv
from collections import defaultdict
from datetime import datetime

ODDS_BANDS = [(0,10,"<10"),(10,20,"10-20"),(20,50,"20-50"),(50,100,"50-100"),(100,10**9,"100+")]

def odds_band(x):
    if x is None: return "unknown"
    for lo,hi,name in ODDS_BANDS:
        if lo <= x < hi: return name
    return "unknown"

def implied_hit_value(finish, polarity):
    if polarity > 0: return 1.0 if finish <= 3 else 0.0
    if polarity < 0: return 1.0 if finish >= 4 else 0.0
    return 0.5

def source_rows(con):
    q = """SELECT
        p.source_id, es.source_name, es.platform,
        s.category, p.race_date, p.jcd, p.race_no, p.boat_no,
        s.polarity, s.confidence, r.finish,
        pay.combination, pay.amount_yen
      FROM external_signals s
      JOIN external_posts p ON p.post_id=s.post_id
      JOIN external_sources es ON es.source_id=p.source_id
      JOIN races rc ON rc.race_date=p.race_date AND rc.jcd=p.jcd AND rc.race_no=p.race_no
      JOIN results r ON r.race_id=rc.race_id AND r.boat_no=p.boat_no
      LEFT JOIN payouts pay ON pay.race_id=rc.race_id AND pay.bet_type='3連単'
      WHERE p.boat_no BETWEEN 1 AND 6
        AND r.finish BETWEEN 1 AND 6"""
    return con.execute(q).fetchall()

def aggregate(con):
    out = defaultdict(lambda: {"samples":0,"correct":0.0,"weighted_correct":0.0,"confidence_sum":0.0})
    for row in source_rows(con):
        source_id, source_name, platform, category, rdate, jcd, race_no, boat_no, polarity, confidence, finish, combo, payout = row
        band = odds_band((payout/100.0) if payout else None)
        correct = implied_hit_value(finish, polarity)
        weight = max(0.05, min(1.0, confidence or 0.5))
        keys = [
            ("source_category", source_id, source_name, platform, category, "*", "*"),
            ("source_venue", source_id, source_name, platform, "*", jcd, "*"),
            ("source_category_venue", source_id, source_name, platform, category, jcd, "*"),
            ("source_category_odds", source_id, source_name, platform, category, "*", band),
        ]
        for key in keys:
            d=out[key]
            d["samples"] += 1
            d["correct"] += correct
            d["weighted_correct"] += correct*weight
            d["confidence_sum"] += weight

    rows=[]
    for key,d in out.items():
        dim,source_id,source_name,platform,category,jcd,band=key
        n=d["samples"]
        raw=d["correct"]/n if n else 0.5
        wacc=d["weighted_correct"]/d["confidence_sum"] if d["confidence_sum"] else 0.5
        shrunk=(d["correct"]+10)/(n+20)
        rows.append({
            "dimension":dim,"source_id":source_id,"source_name":source_name,"platform":platform,
            "category":category,"jcd":jcd,"odds_band":band,"samples":n,
            "raw_accuracy":raw,"weighted_accuracy":wacc,"shrunk_score":shrunk
        })
    return rows

def save_table(con, rows):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS external_attribution (
      dimension TEXT NOT NULL,
      source_id INTEGER NOT NULL,
      category TEXT NOT NULL,
      jcd TEXT NOT NULL,
      odds_band TEXT NOT NULL,
      samples INTEGER NOT NULL,
      raw_accuracy REAL NOT NULL,
      weighted_accuracy REAL NOT NULL,
      shrunk_score REAL NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(dimension,source_id,category,jcd,odds_band)
    );
    DELETE FROM external_attribution;
    """)
    now=datetime.now().isoformat(timespec="seconds")
    for r in rows:
        con.execute("""INSERT INTO external_attribution
        (dimension,source_id,category,jcd,odds_band,samples,raw_accuracy,
         weighted_accuracy,shrunk_score,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (r["dimension"],r["source_id"],r["category"],r["jcd"],r["odds_band"],
         r["samples"],r["raw_accuracy"],r["weighted_accuracy"],r["shrunk_score"],now))
    con.commit()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--out",default="external_attribution_v06.csv")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    rows=aggregate(con)
    save_table(con,rows)
    if rows:
        with open(a.out,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
    else:
        open(a.out,"w",encoding="utf-8").write("")
    print(f"attribution rows: {len(rows)}")
    print("saved:",a.out)

if __name__=="__main__":
    main()
