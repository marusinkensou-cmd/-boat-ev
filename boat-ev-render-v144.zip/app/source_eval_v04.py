from __future__ import annotations
import argparse, sqlite3
from datetime import datetime
from collections import defaultdict

# V0.4 uses a deliberately simple outcome definition:
# positive boat signal is "correct" if the boat finishes top-3;
# negative signal is "correct" if it finishes 4th-6th.
# Later this will be category-specific (e.g. motor/伸び should be judged against
# normalized performance, not only finish order).

def rebuild(con, before_date=None):
    q="""SELECT p.source_id,s.category,s.polarity,r.finish
         FROM external_signals s
         JOIN external_posts p ON p.post_id=s.post_id
         JOIN races rc ON rc.race_date=p.race_date AND rc.jcd=p.jcd AND rc.race_no=p.race_no
         JOIN results r ON r.race_id=rc.race_id AND r.boat_no=p.boat_no
         WHERE p.boat_no BETWEEN 1 AND 6 AND r.finish BETWEEN 1 AND 6"""
    params=[]
    if before_date:
        q += " AND rc.race_date < ?"
        params.append(before_date)

    agg=defaultdict(lambda:[0,0.0])
    for sid,cat,pol,finish in con.execute(q,params):
        if abs(pol)<.05: continue
        correct = 1.0 if ((pol>0 and finish<=3) or (pol<0 and finish>=4)) else 0.0
        agg[(sid,cat)][0]+=1
        agg[(sid,cat)][1]+=correct

    con.execute("DELETE FROM source_scores")
    for (sid,cat),(n,c) in agg.items():
        # beta-binomial style shrinkage toward 50%, equivalent to 10 neutral pseudo-observations
        score=(c+5)/(n+10)
        con.execute("""INSERT INTO source_scores
          (source_id,category,samples,correct,weighted_score,updated_at)
          VALUES(?,?,?,?,?,?)""",
          (sid,cat,n,c,score,datetime.now().isoformat(timespec="seconds")))
    con.commit()
    print(f"source score groups: {len(agg)}")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--before-date")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    rebuild(con,a.before_date)
