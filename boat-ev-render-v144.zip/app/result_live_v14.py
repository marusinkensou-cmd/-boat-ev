from __future__ import annotations
import re
from urllib.parse import urlencode
from bs4 import BeautifulSoup
from official_live_v10 import fetch_html
from virtual_ledger_v14 import settle_plan

BASE="https://www.boatrace.jp/owpc/pc/race/resultlist"

def resultlist_url(date,jcd):
    return BASE+"?"+urlencode({"hd":date.replace("-",""),"jcd":jcd})

def _money(s):
    m=re.search(r"(?:¥|￥)?\s*([0-9][0-9,]*)",str(s).replace(" ",""))
    return int(m.group(1).replace(",","")) if m else None

def parse_resultlist(html):
    """Return {race_no: {combo,payout,note}} from official venue result list."""
    soup=BeautifulSoup(html,"html.parser")
    out={}
    for table in soup.find_all("table"):
        txt=table.get_text(" ",strip=True)
        if not ("3連" in txt and "払戻" in txt):
            continue
        for tr in table.find_all("tr"):
            cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
            if len(cells)<3: continue
            rm=re.search(r"\b(1[0-2]|[1-9])R\b",cells[0])
            if not rm: continue
            rno=int(rm.group(1))
            # The first three distinct boat numbers after race number form trifecta.
            joined=" | ".join(cells[1:])
            cm=re.search(r"([1-6])\s*[-－]\s*([1-6])\s*[-－]\s*([1-6])",joined)
            if not cm: continue
            combo="".join(cm.groups())
            payout=None
            # payout is normally the cell immediately following trifecta combination.
            for c in cells[1:4]:
                if "¥" in c or "￥" in c:
                    payout=_money(c)
                    if payout is not None: break
            if payout is None:
                nums=[_money(c) for c in cells[1:]]
                nums=[x for x in nums if x is not None and x>=100]
                payout=nums[0] if nums else None
            if payout is None: continue
            note=cells[-1] if len(cells)>4 else ""
            out[rno]={"combo":combo,"payout":payout,"note":note}
    return out

def fetch_resultlist(date,jcd,cache_dir="cache/live"):
    url=resultlist_url(date,jcd)
    # Result pages can change after every race; cache briefly.
    html,source=fetch_html(url,cache_dir=cache_dir,max_age_sec=30,timeout=15)
    return parse_resultlist(html),source,url

def settle_due(con, now, cache_dir="cache/live", grace_min=3):
    """Settle due paper plans using the official result-list page, one fetch per venue."""
    rows=con.execute(
        """SELECT vp.plan_id,r.race_date,r.jcd,r.race_no,r.deadline
           FROM virtual_plans vp JOIN races r ON r.race_id=vp.race_id
           WHERE vp.settled_at IS NULL ORDER BY r.race_date,r.jcd,r.race_no"""
    ).fetchall()
    groups={}
    for plan_id,date,jcd,rno,deadline in rows:
        if date!=now.date().isoformat() or not deadline: continue
        try:
            hh,mm=map(int,deadline[:5].split(":"))
            dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
            mins=(now-dl).total_seconds()/60
        except Exception:
            continue
        if mins < grace_min: continue
        groups.setdefault((date,jcd),[]).append((plan_id,rno))
    settled=[]; errors=[]
    for (date,jcd),plans in groups.items():
        try:
            results,source,url=fetch_resultlist(date,jcd,cache_dir)
            for plan_id,rno in plans:
                item=results.get(rno)
                if not item: continue
                # Return/refund races need a richer refund parser before counting them.
                if "返還" in (item.get("note") or ""):
                    continue
                if settle_plan(con,plan_id,item["combo"],item["payout"],now):
                    settled.append({"plan_id":plan_id,"race_no":rno,"combo":item["combo"],"payout":item["payout"]})
        except Exception as e:
            errors.append({"date":date,"jcd":jcd,"error":str(e)})
    return {"settled":settled,"errors":errors}
