from __future__ import annotations
import argparse, sqlite3, json
from datetime import datetime
from zoneinfo import ZoneInfo
from official_live_v10 import refresh_one
from nationwide_board_v09 import build_board

JST=ZoneInfo("Asia/Tokyo")

def active_candidates(con,now,horizon_min=90):
    today=now.date().isoformat()
    rows=con.execute("""SELECT jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    out=[]
    for jcd,rno,deadline in rows:
        try:
            hh,mm=map(int,deadline[:5].split(":"))
            dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
        except Exception:
            continue
        mins=(dl-now).total_seconds()/60
        if 0<=mins<=horizon_min:
            out.append((jcd,rno,mins))
    return out

def refresh_nearby(con,now,max_races=8,horizon_min=90):
    results=[]
    for jcd,rno,mins in active_candidates(con,now,horizon_min)[:max_races]:
        try:
            results.append(refresh_one(con,now.date().isoformat(),jcd,rno))
        except Exception as e:
            results.append({"jcd":jcd,"race_no":rno,"error":str(e)})
    return results

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--max-races",type=int,default=8)
    ap.add_argument("--horizon-min",type=int,default=90)
    ap.add_argument("--skip-fetch",action="store_true")
    a=ap.parse_args()

    now=datetime.now(JST)
    con=sqlite3.connect(a.db)
    refreshed=[] if a.skip_fetch else refresh_nearby(con,now,a.max_races,a.horizon_min)
    board=build_board(con,now)
    print(json.dumps({"refreshed":refreshed,"board":board},ensure_ascii=False,indent=2))
