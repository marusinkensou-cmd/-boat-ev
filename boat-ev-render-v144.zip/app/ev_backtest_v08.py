from __future__ import annotations
import argparse, sqlite3, csv
from ev_engine_v08 import evaluate_race

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--start",required=True)
    ap.add_argument("--end",required=True)
    ap.add_argument("--model",default="C1")
    ap.add_argument("--ev-threshold",type=float,default=1.10)
    ap.add_argument("--edge-threshold",type=float,default=.10)
    ap.add_argument("--max-bets",type=int,default=6)
    ap.add_argument("--stake",type=int,default=100)
    ap.add_argument("--out",default="ev_backtest_v08.csv")
    a=ap.parse_args()

    con=sqlite3.connect(a.db)
    races=con.execute("""SELECT race_id,race_date
                         FROM races
                         WHERE race_date BETWEEN ? AND ?
                         ORDER BY race_date,jcd,race_no""",(a.start,a.end)).fetchall()
    rows=[]
    total_stake=0
    total_return=0.0
    hit_tickets=0
    bet_races=0
    pass_races=0

    for rid,rdate in races:
        # Historical backtest must use odds observed before the race result.
        result=evaluate_race(
            con,rid,a.model,None,
            a.ev_threshold,a.edge_threshold,a.max_bets
        )
        if result["status"]=="pass":
            pass_races+=1
            continue
        if result["status"]!="bet":
            continue

        bet_races+=1
        payout=con.execute("""SELECT combination,amount_yen
                              FROM payouts
                              WHERE race_id=? AND bet_type='3連単'
                              LIMIT 1""",(rid,)).fetchone()
        if not payout:
            continue
        actual,amount=payout

        for bet in result["bets"]:
            total_stake += a.stake
            ret=0.0
            hit=0
            if bet["combination"]==actual:
                hit=1
                hit_tickets+=1
                ret=amount*(a.stake/100)
                total_return += ret
            rows.append({
                "race_id":rid,
                "race_date":rdate,
                "combination":bet["combination"],
                "predicted_prob":bet["predicted_prob"],
                "fair_odds":bet["fair_odds"],
                "market_odds":bet["market_odds"],
                "ev":bet["ev"],
                "edge_ratio":bet["edge_ratio"],
                "hit":hit,
                "return":ret,
            })

    with open(a.out,"w",newline="",encoding="utf-8-sig") as f:
        if rows:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        else:
            f.write("")

    recovery=(total_return/total_stake*100) if total_stake else 0
    print("bet_races:",bet_races)
    print("pass_races:",pass_races)
    print("tickets:",len(rows))
    print("hits:",hit_tickets)
    print("stake:",total_stake)
    print("return:",total_return)
    print("recovery_rate:",round(recovery,1))
    print("saved:",a.out)

if __name__=="__main__":
    main()
