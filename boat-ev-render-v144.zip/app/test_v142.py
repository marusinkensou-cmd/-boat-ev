import sqlite3
from pathlib import Path
from parse_bk import ensure_schema
root=Path(__file__).resolve().parent
con=sqlite3.connect(":memory:")
ensure_schema(con, root/"schema.sql")
names={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
assert "venue_condition_stats" in names
assert "virtual_plans" in names
assert "virtual_bets" in names
print("v1.4.2 schema regression: OK")
