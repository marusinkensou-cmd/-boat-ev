from __future__ import annotations
import argparse, sqlite3, math
from collections import defaultdict
from itertools import permutations

COURSE_PRIOR={1:1.0,2:.73,3:.69,4:.63,5:.49,6:.36}

def clamp(x,a=0,b=1): return max(a,min(b,x))
def nwr(x): return .5 if x is None else clamp((x-2)/7)
def nst(x): return .5 if x is None else clamp((.30-x)/.22)
def nm(x): return .5 if x is None else clamp(x/60)

def model_score(row, recent):
    boat,racer,nw,lw,avgst,motor2=row
    starts,wins,top3=recent.get(racer,(0,0,0))
    winf=wins/starts if starts else .20
    top3f=top3/starts if starts else .50
    return (.25*nwr(nw)+.20*COURSE_PRIOR.get(boat,.5)+.15*nm(motor2)+
            .10*nwr(lw)+.10*clamp(winf/.45)+.10*nst(avgst)+
            .05*clamp(top3f/.75)+.05*.5)

def probs(scores):
    s={b:math.exp(v*4) for b,v in scores}
    out={}
    for a,b,c in permutations(s,3):
        out[f"{a}{b}{c}"]=(s[a]/sum(s.values()))*(s[b]/sum(v for k,v in s.items() if k!=a))*(s[c]/sum(v for k,v in s.items() if k not in (a,b)))
    return out

def recent_before(con, target, maxn=30):
    q="""SELECT e.racer_no,r.finish
         FROM results r JOIN races rc ON rc.race_id=r.race_id
         JOIN entries e ON e.race_id=r.race_id AND e.boat_no=r.boat_no
         WHERE rc.race_date < ? AND e.racer_no IS NOT NULL
         ORDER BY rc.race_date DESC,rc.race_no DESC"""
    d=defaultdict(list)
    for racer,fin in con.execute(q,(target,)):
        if len(d[racer])<maxn: d[racer].append(fin)
    return {k:(len(v),sum(x==1 for x in v),sum(x and x<=3 for x in v)) for k,v in d.items()}

def month_key(s): return s[:7]

def run(db,start,end,topn=5,stake=100):
    con=sqlite3.connect(db)
    rows=con.execute("""SELECT race_id,race_date FROM races
        WHERE race_date BETWEEN ? AND ? ORDER BY race_date,jcd,race_no""",(start,end)).fetchall()
    monthly=defaultdict(lambda:{"seen":0,"bet":0,"tickets":0,"hits":0,"stake":0,"ret":0})
    cached_date=None; recent={}
    for rid,d in rows:
        entries=con.execute("""SELECT boat_no,racer_no,national_win_rate,local_win_rate,
        avg_st,motor_quinella_rate FROM entries WHERE race_id=? ORDER BY boat_no""",(rid,)).fetchall()
        payout=con.execute("SELECT combination,amount_yen FROM payouts WHERE race_id=? AND bet_type='3連単' LIMIT 1",(rid,)).fetchone()
        if len(entries)!=6 or not payout: continue
        if cached_date!=d:
            recent=recent_before(con,d); cached_date=d
        m=monthly[month_key(d)]; m["seen"]+=1
        ps=probs([(r[0],model_score(r,recent)) for r in entries])
        picks=sorted(ps.items(),key=lambda x:x[1],reverse=True)[:topn]
        if not picks: continue
        m["bet"]+=1; m["tickets"]+=len(picks); m["stake"]+=stake*len(picks)
        combo,amount=payout
        if any(c==combo for c,_ in picks):
            m["hits"]+=1; m["ret"]+=amount*(stake/100)
    total={k:sum(m[k] for m in monthly.values()) for k in ["seen","bet","tickets","hits","stake","ret"]}
    print("month,races,bets,hits,stake,return,recovery")
    for mon,m in sorted(monthly.items()):
        rr=(m["ret"]/m["stake"]*100) if m["stake"] else 0
        print(f"{mon},{m['seen']},{m['bet']},{m['hits']},{m['stake']},{m['ret']:.0f},{rr:.1f}%")
    rr=(total["ret"]/total["stake"]*100) if total["stake"] else 0
    print(f"TOTAL,{total['seen']},{total['bet']},{total['hits']},{total['stake']},{total['ret']:.0f},{rr:.1f}%")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--start",required=True)
    ap.add_argument("--end",required=True)
    ap.add_argument("--topn",type=int,default=5)
    ap.add_argument("--stake",type=int,default=100)
    a=ap.parse_args()
    run(a.db,a.start,a.end,a.topn,a.stake)
