from __future__ import annotations
import argparse, sqlite3, csv

MIN_SAMPLES=20
def label(score,samples):
    if samples < MIN_SAMPLES:return "参考不足"
    if score >= .62:return "強い"
    if score >= .55:return "やや有効"
    if score <= .38:return "逆指標候補"
    if score <= .45:return "弱い"
    return "中立"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--out",default="source_rank_v06.csv")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    rows=con.execute("""SELECT ea.dimension,es.source_name,es.platform,ea.category,ea.jcd,
        ea.odds_band,ea.samples,ea.raw_accuracy,ea.weighted_accuracy,ea.shrunk_score
      FROM external_attribution ea
      JOIN external_sources es ON es.source_id=ea.source_id
      ORDER BY ea.shrunk_score DESC,ea.samples DESC""").fetchall()
    with open(a.out,"w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["dimension","source_name","platform","category","jcd","odds_band",
                    "samples","raw_accuracy","weighted_accuracy","shrunk_score","label"])
        for r in rows:
            w.writerow([*r,label(r[-1],r[-4])])
    print("saved:",a.out)
    for r in rows[:20]:
        print(r[1],r[3],r[4],r[6],round(r[-1],3),label(r[-1],r[-4]))

if __name__=="__main__":
    main()
