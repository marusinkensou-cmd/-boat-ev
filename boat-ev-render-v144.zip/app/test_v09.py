import sqlite3,tempfile,csv
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from parse_bk import ensure_schema
from build_features_v03 import rebuild
from nationwide_board_v09 import build_board
from ev_engine_v08 import latest_odds_snapshot

JST=ZoneInfo("Asia/Tokyo")

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('04','平和島')")

    # Minimal historical rows to allow model calculation.
    for idx,d in enumerate(["2026-09-10","2026-09-11"]):
        rid=f"h{idx}"
        con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status) VALUES(?,?,?,?,?,?)",
                    (rid,d,'02',1,'12:00','finished'))
        for b in range(1,7):
            con.execute("""INSERT INTO entries(race_id,boat_no,racer_no,national_win_rate,local_win_rate,avg_st,motor_quinella_rate)
                           VALUES(?,?,?,?,?,?,?)""",(rid,b,4000+b,6.5-b*.2,5.8-b*.1,.14+b*.005,45-b))
            con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES(?,?,?,?)",(rid,b,b,b))
    rebuild(con)

    # Today's two races.
    races=[("r1","02",11,"15:06"),("r2","04",10,"15:09")]
    for rid,jcd,rno,dl in races:
        con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status) VALUES(?,?,?,?,?,?)",
                    (rid,"2026-09-13",jcd,rno,dl,"scheduled"))
        for b in range(1,7):
            con.execute("""INSERT INTO entries(race_id,boat_no,racer_no,national_win_rate,local_win_rate,avg_st,motor_quinella_rate)
                           VALUES(?,?,?,?,?,?,?)""",(rid,b,4000+b,6.5-b*.2,5.8-b*.1,.14+b*.005,45-b))

    # r1: deliberately make 314 high value; r2: no value.
    for rid,ts in [("r1","2026-09-13T14:59:00+09:00"),("r2","2026-09-13T14:59:00+09:00")]:
        cur=con.execute("INSERT INTO odds_snapshots(race_id,fetched_at) VALUES(?,?)",(rid,ts))
        sid=cur.lastrowid
        for a in range(1,7):
            for b in range(1,7):
                for c in range(1,7):
                    if len({a,b,c})<3: continue
                    odds=3.0 if rid=="r2" else 8.0
                    if rid=="r1" and (a,b,c)==(3,1,4):
                        odds=80.0
                    con.execute("""INSERT INTO odds_trifecta(snapshot_id,first_boat,second_boat,third_boat,odds)
                                   VALUES(?,?,?,?,?)""",(sid,a,b,c,odds))
    con.commit()

    ts,od=latest_odds_snapshot(con,"r1","2026-09-13T15:00:00+09:00")
    assert ts=="2026-09-13T14:59:00+09:00"
    assert od["314"]==80.0

    rows=build_board(con,datetime(2026,9,13,15,0,tzinfo=JST))
    assert len(rows)==2, rows
    assert rows[0]["race_id"]=="r1"
    assert rows[0]["grade"]!="PASS"
    assert rows[1]["race_id"]=="r2"
    assert rows[1]["grade"]=="PASS"
    print("v0.9 nationwide board test: OK")
    print(rows[0]["venue"],rows[0]["race_no"],rows[0]["grade"],rows[0]["best_combo"],rows[0]["best_ev"])
    print(rows[1]["venue"],rows[1]["race_no"],rows[1]["grade"])
