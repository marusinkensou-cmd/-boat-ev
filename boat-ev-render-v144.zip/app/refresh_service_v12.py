from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
from today_discovery_v12 import discover_today
from racelist_live_v12 import seed_venue_races,refresh_racelist
from beforeinfo_live_v12 import refresh_beforeinfo
from official_live_v10 import refresh_one
from nationwide_board_v09 import build_board

JST=ZoneInfo("Asia/Tokyo")

def mins_to_deadline(now,deadline):
    hh,mm=map(int,deadline[:5].split(":"))
    dl=now.replace(hour=hh,minute=mm,second=0,microsecond=0)
    return (dl-now).total_seconds()/60

def seed_today(con,now,cache_dir="cache/live"):
    race_date=now.date().isoformat()
    venues,source=discover_today(race_date,cache_dir)
    ok=[]; errors=[]
    for v in venues:
        try:
            seed_venue_races(con,race_date,v["jcd"],cache_dir); ok.append(v)
        except Exception as e:
            errors.append({"jcd":v["jcd"],"venue":v["venue"],"error":str(e)})
    return ok,errors,source

def refresh_for_iphone(con,now=None,max_races=8,horizon_min=90,cache_dir="cache/live"):
    now=now or datetime.now(JST)
    seeded,venue_errors,_=seed_today(con,now,cache_dir)
    today=now.date().isoformat()
    rows=con.execute("""SELECT jcd,race_no,deadline FROM races
                        WHERE race_date=? AND deadline IS NOT NULL
                        ORDER BY deadline,jcd,race_no""",(today,)).fetchall()
    candidates=[]
    for jcd,rno,deadline in rows:
        try:m=mins_to_deadline(now,deadline)
        except:continue
        if 0<=m<=horizon_min:candidates.append((m,jcd,rno))
    updates=[]
    for mins,jcd,rno in candidates[:max_races]:
        item={"jcd":jcd,"race_no":rno,"minutes":round(mins,1)}
        for key,func in [
            ("racelist",lambda:refresh_racelist(con,today,jcd,rno,cache_dir)),
            ("beforeinfo",lambda:refresh_beforeinfo(con,today,jcd,rno,cache_dir)),
            ("odds",lambda:refresh_one(con,today,jcd,rno,cache_dir))
        ]:
            try:item[key]=func()
            except Exception as e:item[key+"_error"]=str(e)
        updates.append(item)
    return {
      "generated_at":now.isoformat(),"venues_found":len(seeded),
      "venue_errors":venue_errors,"races_updated":len(updates),
      "updates":updates,"board":build_board(con,now)
    }
