from __future__ import annotations
from datetime import datetime

def ensure_quality_table(con):
    con.execute("""CREATE TABLE IF NOT EXISTS live_quality(
      race_id TEXT PRIMARY KEY,
      racelist_ok INTEGER DEFAULT 0,
      beforeinfo_ok INTEGER DEFAULT 0,
      odds_ok INTEGER DEFAULT 0,
      updated_at TEXT,
      note TEXT
    )""")
    con.commit()

def mark(con,race_id,field,ok,note=None):
    ensure_quality_table(con)
    if field not in {"racelist_ok","beforeinfo_ok","odds_ok"}:
        raise ValueError(field)
    now=datetime.now().astimezone().isoformat(timespec="seconds")
    con.execute("""INSERT INTO live_quality(race_id,updated_at,note)
                   VALUES(?,?,?)
                   ON CONFLICT(race_id) DO NOTHING""",(race_id,now,note))
    con.execute(f"""UPDATE live_quality SET {field}=?,updated_at=?,note=COALESCE(?,note)
                    WHERE race_id=?""",(1 if ok else 0,now,note,race_id))
    con.commit()

def status(con,race_id):
    ensure_quality_table(con)
    row=con.execute("""SELECT racelist_ok,beforeinfo_ok,odds_ok,note
                       FROM live_quality WHERE race_id=?""",(race_id,)).fetchone()
    if not row:
        return {"racelist_ok":False,"beforeinfo_ok":False,"odds_ok":False,"note":"未取得"}
    return {"racelist_ok":bool(row[0]),"beforeinfo_ok":bool(row[1]),"odds_ok":bool(row[2]),"note":row[3]}
