from __future__ import annotations
import csv, argparse, statistics

def num(x):
    try:return float(x)
    except:return 0.0

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("csv")
    a=ap.parse_args()
    with open(a.csv,encoding="utf-8-sig") as f:
        rows=list(csv.DictReader(f))
    totals=[r for r in rows if r["month"]=="TOTAL"]
    months=[r for r in rows if r["month"]!="TOTAL"]

    print("# モデル比較")
    for r in totals:
        print(f"{r['model']} {r['name']}: 回収率 {num(r['recovery_rate']):.1f}% / 的中率 {num(r['hit_rate'])*100:.1f}% / Brier {num(r['brier']):.4f} / LogLoss {num(r['logloss']):.4f}")
    print("\n# 月別安定性")
    for code in sorted(set(r["model"] for r in months)):
        vals=[num(r["recovery_rate"]) for r in months if r["model"]==code]
        if vals:
            print(f"{code}: 月平均 {statistics.mean(vals):.1f}% / 最低 {min(vals):.1f}% / 最高 {max(vals):.1f}% / 標準偏差 {statistics.pstdev(vals):.1f}")

if __name__=="__main__":
    main()
