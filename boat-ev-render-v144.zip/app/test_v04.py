import sqlite3, tempfile
from pathlib import Path
from parse_bk import ensure_schema
from external_ingest_v04 import upsert_source, add_post, add_signal
from external_scoring_v04 import build_adjustments
from source_eval_v04 import rebuild

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES('r1','2026-09-13','02',8,'finished')")
    for b in range(1,7):
        con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES('r1',?,?,?)",(b,b,b))
    s1=upsert_source(con,"blog","テストA","https://example.com/a",.6)
    p1=add_post(con,s1,{"raw_text":"3号艇は伸び良い","race_date":"2026-09-13","jcd":"02","race_no":8,"boat_no":3})
    add_signal(con,p1,"伸び","boat","3",1.0,.9,"伸び良い")
    s2=upsert_source(con,"x","テストB","https://example.com/b",.5)
    p2=add_post(con,s2,{"raw_text":"3号艇モーター良さそう","race_date":"2026-09-13","jcd":"02","race_no":8,"boat_no":3})
    add_signal(con,p2,"モーター評価","boat","3",.8,.8,"モーター良さそう")
    con.commit()

    rows,tot=build_adjustments(con,"r1")
    assert tot[3] > 0, tot
    rebuild(con)
    n=con.execute("SELECT COUNT(*) FROM source_scores").fetchone()[0]
    assert n==2,n
    print("v0.4 external-info test: OK")
    print("boat3 adjustment:",round(tot[3],4))
