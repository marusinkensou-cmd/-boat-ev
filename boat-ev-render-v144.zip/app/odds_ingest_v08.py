from __future__ import annotations
import argparse,csv,sqlite3
from datetime import datetime

def import_csv(con,race_id,csv_path,fetched_at=None,official_updated_at=None):
    fetched_at=fetched_at or datetime.now().isoformat(timespec="seconds")
    cur=con.execute("""INSERT INTO odds_snapshots(race_id,fetched_at,official_updated_at)
                       VALUES(?,?,?)""",(race_id,fetched_at,official_updated_at))
    sid=cur.lastrowid
    n=0
    with open(csv_path,encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            combo=str(row["combination"]).strip()
            if len(combo)!=3 or not combo.isdigit() or len(set(combo))!=3:
                continue
            a,b,c=map(int,combo)
            odds=float(row["odds"])
            con.execute("""INSERT OR REPLACE INTO odds_trifecta
                           (snapshot_id,first_boat,second_boat,third_boat,odds)
                           VALUES(?,?,?,?,?)""",(sid,a,b,c,odds))
            n+=1
    con.commit()
    print(f"snapshot_id={sid} imported={n} fetched_at={fetched_at}")
    return sid

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--race-id",required=True)
    ap.add_argument("--csv",required=True)
    ap.add_argument("--fetched-at")
    ap.add_argument("--official-updated-at")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    import_csv(con,a.race_id,a.csv,a.fetched_at,a.official_updated_at)
