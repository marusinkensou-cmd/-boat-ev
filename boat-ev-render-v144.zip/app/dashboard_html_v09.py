from __future__ import annotations
import argparse,sqlite3,html,json
from datetime import datetime
from zoneinfo import ZoneInfo
from nationwide_board_v09 import build_board

JST=ZoneInfo("Asia/Tokyo")

def esc(x): return html.escape(str(x))

def card(r):
    passed=r["grade"]=="PASS"
    badge="見送り" if passed else f"{r['grade']}評価"
    top = "妙味なし" if passed else f"{r['best_combo']} / EV {r['best_ev']:.2f} / {r['best_odds']:.1f}倍"
    bets=""
    if not passed:
        lis=[]
        for b in r["bets"][:6]:
            lis.append(
                f"<li><b>{esc(b['combination'])}</b>"
                f"<span>予測 {b['predicted_prob']*100:.1f}%</span>"
                f"<span>適正 {b['fair_odds']:.1f}倍</span>"
                f"<span>現在 {b['market_odds']:.1f}倍</span>"
                f"<strong>EV {b['ev']:.2f}</strong></li>"
            )
        bets="<ul>"+''.join(lis)+"</ul>"
    mins=r["minutes_to_deadline"]
    mtxt=f"締切まで {mins:.0f}分" if mins>=0 else f"締切 {abs(mins):.0f}分経過"
    return f"""
    <section class="card {'pass' if passed else 'buy'}">
      <div class="head">
        <div><span class="venue">{esc(r['venue'])}</span><b>{r['race_no']}R</b></div>
        <span class="badge">{badge}</span>
      </div>
      <div class="deadline">{mtxt}</div>
      <div class="top">{top}</div>
      {bets}
    </section>"""

def render(rows,now):
    cards=''.join(card(r) for r in rows) or '<p class="empty">対象レースがありません。</p>'
    buy=sum(r["grade"]!="PASS" for r in rows)
    passed=sum(r["grade"]=="PASS" for r in rows)
    return f"""<!doctype html><html lang="ja"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>今日の狙い目</title>
<style>
*{{box-sizing:border-box}} body{{margin:0;background:#0d1117;color:#f0f3f6;font-family:-apple-system,BlinkMacSystemFont,"Helvetica Neue",sans-serif}}
header{{position:sticky;top:0;background:#0d1117e8;backdrop-filter:blur(12px);padding:18px 16px 12px;border-bottom:1px solid #2a3038;z-index:5}}
h1{{font-size:22px;margin:0 0 8px}} .sub{{font-size:12px;color:#9da7b3}} .summary{{display:flex;gap:8px;margin-top:10px}}
.pill{{background:#1b2330;padding:6px 10px;border-radius:999px;font-size:12px}} main{{padding:12px;max-width:760px;margin:auto}}
.card{{border:1px solid #2d3743;background:#151b23;border-radius:16px;padding:14px;margin:10px 0;box-shadow:0 4px 20px #0003}}
.card.buy{{border-left:5px solid #f0f3f6}} .card.pass{{opacity:.72}} .head{{display:flex;justify-content:space-between;align-items:center}}
.venue{{font-size:18px;font-weight:800;margin-right:8px}} .badge{{border:1px solid #596575;border-radius:999px;padding:5px 9px;font-size:12px}}
.deadline{{font-size:13px;color:#aeb7c2;margin-top:6px}} .top{{font-size:17px;font-weight:800;margin:10px 0}}
ul{{list-style:none;padding:0;margin:8px 0 0}} li{{display:grid;grid-template-columns:1.1fr 1fr 1fr 1fr 1fr;gap:5px;padding:8px 0;border-top:1px solid #28313c;font-size:12px;align-items:center}}
li b{{font-size:16px}} li strong{{text-align:right}} .empty{{text-align:center;color:#9da7b3;padding:40px}}
@media(max-width:520px){{li{{grid-template-columns:.9fr 1fr 1fr}} li span:nth-of-type(2){{display:none}} li strong{{text-align:left}}}}
</style></head><body>
<header><h1>今日の狙い目</h1><div class="sub">{now.strftime('%Y/%m/%d %H:%M')} JST ・ 締切順</div>
<div class="summary"><span class="pill">買い候補 {buy}</span><span class="pill">見送り {passed}</span></div></header>
<main>{cards}</main></body></html>"""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--out",default="today_v09.html")
    ap.add_argument("--now")
    a=ap.parse_args()
    now=datetime.fromisoformat(a.now) if a.now else datetime.now(JST)
    con=sqlite3.connect(a.db)
    rows=build_board(con,now)
    with open(a.out,"w",encoding="utf-8") as f:
        f.write(render(rows,now))
    print("saved:",a.out)

if __name__=="__main__":
    main()
