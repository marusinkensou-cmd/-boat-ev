import sqlite3, tempfile, csv, math
from pathlib import Path
from datetime import date, timedelta
from parse_bk import ensure_schema
from build_features_v03 import rebuild
from ev_engine_v08 import select_bets, fair_odds, expected_value

# Pure EV logic test
probs={"123":.25,"314":.08,"132":.10}
odds={"123":3.0,"314":18.0,"132":8.0}
bets,rows=select_bets(probs,odds,ev_threshold=1.10,edge_threshold=.10,max_bets=6,min_prob=.01)
names=[b["combination"] for b in bets]
assert "123" not in names, names  # EV .75 -> pass
assert "314" in names, names      # EV 1.44 -> buy
assert abs(fair_odds(.08)-12.5)<1e-9
assert abs(expected_value(.08,18)-1.44)<1e-9

# Verify a low-priced favorite is excluded even with highest probability.
fav=[r for r in rows if r["combination"]=="123"][0]
assert fav["predicted_prob"]==.25 and fav["market_odds"]==3.0 and fav["ev"]<1.0

# Verify no forced bets.
bets2,_=select_bets(
    {"123":.35,"132":.20},
    {"123":2.2,"132":4.0},
    ev_threshold=1.10,edge_threshold=.10
)
assert bets2==[], bets2

print("v0.8 EV selection test: OK")
print("favorite 123 EV:", round(fav["ev"],2), "=> PASS")
hole=[b for b in bets if b["combination"]=="314"][0]
print("value 314 EV:", round(hole["ev"],2), "=> BUY")
