import sqlite3,tempfile
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from parse_bk import ensure_schema
from virtual_ledger_v14 import record_board,settle_plan,stats
from result_live_v14 import parse_resultlist
JST=ZoneInfo('Asia/Tokyo')

fixture='''<table><tr><th>レース</th><th>3連勝単式</th><th>払戻金</th><th>2連勝単式</th><th>払戻金</th><th>備考</th></tr>
<tr><td>1R</td><td>2 - 1 - 4</td><td>¥560</td><td>2 - 1</td><td>¥360</td><td></td></tr>
<tr><td>2R</td><td>2 - 4 - 3</td><td>¥5,370</td><td>2 - 4</td><td>¥3,390</td><td></td></tr></table>'''
r=parse_resultlist(fixture)
assert r[1]['combo']=='214' and r[1]['payout']==560,r
assert r[2]['combo']=='243' and r[2]['payout']==5370,r

with tempfile.TemporaryDirectory() as td:
    con=sqlite3.connect(Path(td)/'x.sqlite')
    ensure_schema(con,Path(__file__).with_name('schema.sql'))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status) VALUES('r','2026-09-14','02',1,'10:30','scheduled')")
    con.commit()
    board=[{'race_id':'r','grade':'A','decision':'bet','minutes_to_deadline':20,'odds_captured_at':'2026-09-14T10:10:00+09:00','bets':[
        {'combination':'214','predicted_prob':.08,'market_odds':18,'ev':1.44},
        {'combination':'123','predicted_prob':.05,'market_odds':25,'ev':1.25},
    ]}]
    n=record_board(con,board,datetime(2026,9,14,10,10,tzinfo=JST)); assert n==1
    # A second refresh replaces, never doubles the same race.
    record_board(con,board,datetime(2026,9,14,10,15,tzinfo=JST))
    assert con.execute('select count(*) from virtual_plans').fetchone()[0]==1
    pid=con.execute('select plan_id from virtual_plans').fetchone()[0]
    settle_plan(con,pid,'214',560,datetime(2026,9,14,10,35,tzinfo=JST))
    st=stats(con,'2026-09-14')
    assert st['stake_yen']==200 and st['return_yen']==560 and round(st['recovery_rate'],1)==280.0,st
print('v1.4 paper ledger/result parser test: OK')
