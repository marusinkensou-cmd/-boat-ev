from scoring_v1 import BoatFeatures, trifecta_probs, recommend

boats = [
    BoatFeatures(1,.90,.95,.80,.75,.80,.70,.75,.70),
    BoatFeatures(2,.68,.72,.60,.65,.66,.60,.62,.55),
    BoatFeatures(3,.82,.78,.74,.80,.78,.84,.81,.70),
    BoatFeatures(4,.76,.74,.69,.74,.75,.79,.72,.76),
    BoatFeatures(5,.60,.55,.58,.62,.60,.65,.58,.60),
    BoatFeatures(6,.52,.48,.50,.54,.52,.57,.50,.54),
]
probs = trifecta_probs(boats)
assert abs(sum(probs.values()) - 1.0) < 1e-9
top = sorted(probs.items(), key=lambda x:x[1], reverse=True)[:5]
print("Top probabilities:")
for combo,p in top:
    print(combo, round(p,4))

odds = {combo: max(1.1, 0.85/p) for combo,p in probs.items()}
odds[top[0][0]] = 1.25 / top[0][1]
print("Recommendations:")
for combo,p,o,ev in recommend(boats, odds):
    print(combo, round(p,4), round(o,1), round(ev,3))
