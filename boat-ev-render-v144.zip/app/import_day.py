from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

def run(cmd):
    print("+"," ".join(map(str,cmd)))
    subprocess.run(list(map(str,cmd)),check=True)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--date",required=True)
    ap.add_argument("--b",required=True,help="B .lzh or txt")
    ap.add_argument("--k",required=True,help="K .lzh or txt")
    ap.add_argument("--db",default="data/boatrace.sqlite")
    a=ap.parse_args()
    py=sys.executable
    run([py,"init_db.py"])
    run([py,"parse_bk.py","--db",a.db,"--kind","B","--date",a.date,a.b])
    run([py,"parse_bk.py","--db",a.db,"--kind","K","--date",a.date,a.k])
    run([py,"validate_day.py","--db",a.db,"--date",a.date])
    run([py,"build_features_v03.py","--db",a.db])
    print("1日分の取込・検証・特徴量更新が完了しました。")
