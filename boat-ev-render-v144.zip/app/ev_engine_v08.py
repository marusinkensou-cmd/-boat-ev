from __future__ import annotations
import math
from abtest_v07 import predict, recent_before

DEFAULT_EV_THRESHOLD = 1.10
DEFAULT_EDGE_THRESHOLD = 0.10
DEFAULT_MAX_BETS = 6
DEFAULT_MIN_PROB = 0.01

def fair_odds(prob):
    return None if prob is None or prob <= 0 else 1.0 / prob

def expected_value(prob, odds):
    return None if prob is None or odds is None else prob * odds

def edge_ratio(prob, odds):
    fo=fair_odds(prob)
    return None if not fo or odds is None else odds/fo-1.0

def vig_adjusted_market_probs(odds_map):
    raw={k:1.0/v for k,v in odds_map.items() if v and v>0}
    s=sum(raw.values())
    return {} if s<=0 else {k:v/s for k,v in raw.items()}

def select_bets(probs, odds_map, ev_threshold=DEFAULT_EV_THRESHOLD,
                edge_threshold=DEFAULT_EDGE_THRESHOLD, max_bets=DEFAULT_MAX_BETS,
                min_prob=DEFAULT_MIN_PROB):
    market_probs=vig_adjusted_market_probs(odds_map)
    rows=[]
    for combo,prob in probs.items():
        odds=odds_map.get(combo)
        if not odds or odds<=0:
            continue
        ev=expected_value(prob,odds)
        fo=fair_odds(prob)
        edge=edge_ratio(prob,odds)
        row={
            "combination":combo,
            "predicted_prob":prob,
            "fair_odds":fo,
            "market_odds":odds,
            "market_prob_vig_adj":market_probs.get(combo),
            "ev":ev,
            "edge_ratio":edge,
            "qualifies": bool(prob>=min_prob and ev>=ev_threshold and edge is not None and edge>=edge_threshold)
        }
        rows.append(row)
    qualified=sorted((r for r in rows if r["qualifies"]),
                     key=lambda r:(r["ev"],r["predicted_prob"]), reverse=True)
    return qualified[:max_bets],rows

def latest_odds_snapshot(con, race_id, before_at=None):
    col="fetched_at"
    if before_at:
        snap=con.execute(f"""SELECT snapshot_id,{col}
            FROM odds_snapshots
            WHERE race_id=? AND {col}<=?
            ORDER BY {col} DESC LIMIT 1""",(race_id,before_at)).fetchone()
    else:
        snap=con.execute(f"""SELECT snapshot_id,{col}
            FROM odds_snapshots
            WHERE race_id=?
            ORDER BY {col} DESC LIMIT 1""",(race_id,)).fetchone()
    if not snap:
        return None,{}
    sid,ts=snap
    odds={}
    for a,b,c,o in con.execute("""SELECT first_boat,second_boat,third_boat,odds
                                  FROM odds_trifecta WHERE snapshot_id=?""",(sid,)):
        if o is not None:
            odds[f"{a}{b}{c}"]=float(o)
    return ts,odds

def evaluate_race(con, race_id, model="C1", before_at=None,
                  ev_threshold=DEFAULT_EV_THRESHOLD, edge_threshold=DEFAULT_EDGE_THRESHOLD,
                  max_bets=DEFAULT_MAX_BETS, min_prob=DEFAULT_MIN_PROB):
    race=con.execute("SELECT race_date FROM races WHERE race_id=?",(race_id,)).fetchone()
    if not race:
        raise ValueError("race not found")
    rdate=race[0]
    recent=recent_before(con,rdate)
    probs=predict(con,race_id,rdate,model,recent)
    if not probs:
        return {"race_id":race_id,"status":"insufficient_data","bets":[]}
    captured_at,odds=latest_odds_snapshot(con,race_id,before_at)
    if not odds:
        return {"race_id":race_id,"status":"no_odds","bets":[]}
    bets,rows=select_bets(probs,odds,ev_threshold,edge_threshold,max_bets,min_prob)
    return {
        "race_id":race_id,
        "status":"bet" if bets else "pass",
        "odds_captured_at":captured_at,
        "model":model,
        "bets":bets,
        "all_rows":rows,
    }
