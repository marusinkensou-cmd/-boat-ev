import sqlite3, tempfile, subprocess, sys, csv
from pathlib import Path
from datetime import date, timedelta
from parse_bk import ensure_schema
from build_features_v03 import rebuild
from external_ingest_v04 import upsert_source, add_post, add_signal
from external_scoring_v04 import build_adjustments

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"t.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('01','桐生')")

    # 40 unique historical races over 4 dates x 10 races
    base=date(2026,1,1)
    idx=0
    for day_offset in range(4):
        d=(base+timedelta(days=day_offset)).isoformat()
        for rno in range(1,11):
            idx+=1
            rid=f"h{idx}"
            con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)",(rid,d,'01',rno,'finished'))
            con.execute("INSERT INTO race_weather(race_id,wind_speed_m,wave_height_cm) VALUES(?,?,?)",(rid,4,3))
            for b in range(1,7):
                con.execute("""INSERT INTO racers(racer_no,name_kanji,updated_at)
                               VALUES(?,?,datetime('now')) ON CONFLICT(racer_no) DO NOTHING""",(4000+b,f"R{b}"))
                con.execute("""INSERT INTO entries(race_id,boat_no,racer_no,national_win_rate,local_win_rate,avg_st,motor_quinella_rate)
                               VALUES(?,?,?,?,?,?,?)""",(rid,b,4000+b,6.0-b*.2,5.5-b*.1,.15+b*.005,40-b))
                con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES(?,?,?,?)",(rid,b,b,b))
            con.execute("INSERT INTO payouts(race_id,bet_type,combination,amount_yen,popularity) VALUES(?,?,?,?,?)",(rid,'3連単','123',1200,1))
    rebuild(con)

    rid="r1"
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)",(rid,'2026-02-01','01',1,'finished'))
    con.execute("INSERT INTO race_weather(race_id,wind_speed_m,wave_height_cm) VALUES(?,?,?)",(rid,4,3))
    for b in range(1,7):
        con.execute("""INSERT INTO entries(race_id,boat_no,racer_no,national_win_rate,local_win_rate,avg_st,motor_quinella_rate)
                       VALUES(?,?,?,?,?,?,?)""",(rid,b,4000+b,6.0-b*.2,5.5-b*.1,.15+b*.005,40-b))
        con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES(?,?,?,?)",(rid,b,b,b))
    con.execute("INSERT INTO payouts VALUES(?,?,?,?,?)",(rid,'3連単','123',1200,1))

    s=upsert_source(con,'blog','test',None,.6)
    p=add_post(con,s,{"raw_text":"1号艇◎","race_date":"2026-02-01","jcd":"01","race_no":1,"boat_no":1})
    add_signal(con,p,"総合評価","boat","1",1,.8,"1号艇◎")
    con.commit()
    build_adjustments(con,rid)

    out=Path(td)/"cmp.csv"
    r=subprocess.run([sys.executable,"abtest_v05.py","--db",str(db),"--start","2026-02-01","--end","2026-02-01","--out",str(out)],
                     cwd=Path(__file__).parent,capture_output=True,text=True)
    print(r.stdout)
    assert r.returncode==0, r.stderr
    rows=list(csv.DictReader(open(out,encoding="utf-8-sig")))
    assert any(x["model"]=="A" and x["month"]=="TOTAL" for x in rows)
    assert any(x["model"]=="C" and x["month"]=="TOTAL" for x in rows)
    print("v0.5 A/B/C backtest test: OK")
