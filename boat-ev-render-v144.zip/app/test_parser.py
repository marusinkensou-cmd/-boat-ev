import sqlite3, tempfile
from pathlib import Path
from parse_bk import ensure_schema, KParser, BParser

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"t.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))

    # Synthetic K records matching the documented parser offsets.
    k = "\n".join([
        "T001",
        "TH0112 1010500200000",   # venue 01 / 12R / weather=1 etc.
        "T1123451A123015",
        "T2234562A124016",
        "T3334573A125017",
        "T4444584A126018",
        "T5554595A127019",
        "T6664606A128020",
    ])
    KParser("2026-09-13",con).parse(k)

    # Synthetic B: fields are byte-width controlled.
    def bline(boat,racer):
        raw=bytearray(b" "*59)
        raw[0:2]=f"B{boat}".encode()
        raw[2:7]=f"{racer:05d}".encode()
        raw[7:15]="ﾃｽﾄ    ".encode("cp932")[:8].ljust(8,b" ")
        raw[16:18]=b"30"; raw[18:21]=b"520"; raw[21:23]=b"00"; raw[23:25]=b"00"
        raw[25:29]=b"0015"; raw[29:33]=b"0650"; raw[33:37]=b"4800"
        raw[37:41]=b"0700"; raw[41:45]=b"5200"; raw[45:48]=b"012"
        raw[48:52]=b"4200"; raw[52:55]=b"033"; raw[55:59]=b"3500"
        return bytes(raw)
    bh=b"BH0112"
    raw=b"BB01\n"+bh+b"\n"+b"\n".join(bline(i,4000+i) for i in range(1,7))
    BParser("2026-09-13",con).parse(raw)
    con.commit()

    assert con.execute("select count(*) from races").fetchone()[0]==1
    assert con.execute("select count(*) from entries").fetchone()[0]==6
    assert con.execute("select count(*) from results").fetchone()[0]==6
    print("parser synthetic test: OK")
