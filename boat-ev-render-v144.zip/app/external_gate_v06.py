from __future__ import annotations
import argparse, sqlite3

def trust_multiplier(con, source_id, category, jcd, min_samples=20):
    candidates=[
        ("source_category_venue",category,jcd,"*"),
        ("source_category",category,"*","*"),
        ("source_venue","*",jcd,"*"),
    ]
    for dim,cat,venue,band in candidates:
        row=con.execute("""SELECT samples,shrunk_score FROM external_attribution
            WHERE dimension=? AND source_id=? AND category=? AND jcd=? AND odds_band=?""",
            (dim,source_id,cat,venue,band)).fetchone()
        if row and row[0] >= min_samples:
            n,score=row
            return max(0.25,min(1.75,1.0+(score-.5)*2.0))
    return 1.0

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--source-id",type=int,required=True)
    ap.add_argument("--category",required=True)
    ap.add_argument("--jcd",required=True)
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    m=trust_multiplier(con,a.source_id,a.category,a.jcd)
    print(f"multiplier={m:.3f}")
