from __future__ import annotations
import argparse, sqlite3, json
from ev_engine_v08 import evaluate_race

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--race-id",required=True)
    ap.add_argument("--model",default="C1",choices=["A","B","C0","C1"])
    ap.add_argument("--before-at")
    ap.add_argument("--ev-threshold",type=float,default=1.10)
    ap.add_argument("--edge-threshold",type=float,default=.10)
    ap.add_argument("--max-bets",type=int,default=6)
    ap.add_argument("--min-prob",type=float,default=.01)
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    result=evaluate_race(con,a.race_id,a.model,a.before_at,a.ev_threshold,a.edge_threshold,a.max_bets,a.min_prob)
    compact={k:v for k,v in result.items() if k!="all_rows"}
    print(json.dumps(compact,ensure_ascii=False,indent=2))
