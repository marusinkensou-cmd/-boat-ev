from __future__ import annotations
import sqlite3
from collections import defaultdict
from datetime import datetime
from external_gate_v06 import trust_multiplier

CATEGORY_WEIGHT = {
    "出足":1.00,
    "伸び":1.00,
    "回り足":0.90,
    "乗り心地":0.55,
    "スタート気配":0.75,
    "モーター評価":0.95,
    "本命評価":0.40,
    "穴評価":0.35,
    "総合評価":0.50,
}

def source_base_trust(con, source_id):
    row=con.execute("SELECT base_trust FROM external_sources WHERE source_id=?",(source_id,)).fetchone()
    return float(row[0]) if row else 0.5

def gated_external_adjustment(con, race_id, boat_no, max_total=.06):
    race=con.execute("SELECT race_date,jcd,race_no FROM races WHERE race_id=?",(race_id,)).fetchone()
    if not race:
        return 0.0, []
    race_date,jcd,race_no=race

    rows=con.execute("""SELECT p.source_id,es.source_name,es.platform,
                              s.category,s.polarity,s.confidence,s.evidence_text
                       FROM external_posts p
                       JOIN external_sources es ON es.source_id=p.source_id
                       JOIN external_signals s ON s.post_id=p.post_id
                       WHERE p.race_date=? AND p.jcd=? AND p.race_no=? AND p.boat_no=?""",
                     (race_date,jcd,race_no,boat_no)).fetchall()

    details=[]
    total=0.0
    for source_id,source_name,platform,category,polarity,confidence,evidence in rows:
        base=source_base_trust(con,source_id)
        gate=trust_multiplier(con,source_id,category,jcd)
        catw=CATEGORY_WEIGHT.get(category,0.5)

        raw=float(polarity)*float(confidence or .5)*base*catw
        gated=raw*gate
        # Each individual signal is capped to ±2 points equivalent.
        adj=max(-.02,min(.02,gated*.02))
        total += adj

        details.append({
            "source_id":source_id,
            "source_name":source_name,
            "platform":platform,
            "category":category,
            "polarity":float(polarity),
            "confidence":float(confidence or .5),
            "base_trust":base,
            "gate_multiplier":gate,
            "raw_signal":raw,
            "adjustment":adj,
            "evidence_text":evidence,
        })

    total=max(-max_total,min(max_total,total))
    return total, details

def rebuild_gated_adjustments(con, race_id):
    con.execute("""CREATE TABLE IF NOT EXISTS external_adjustment_explanations (
      race_id TEXT NOT NULL,
      boat_no INTEGER NOT NULL,
      source_id INTEGER NOT NULL,
      category TEXT NOT NULL,
      gate_multiplier REAL NOT NULL,
      base_trust REAL NOT NULL,
      polarity REAL NOT NULL,
      confidence REAL NOT NULL,
      adjustment REAL NOT NULL,
      evidence_text TEXT,
      generated_at TEXT NOT NULL
    )""")
    con.execute("DELETE FROM external_adjustment_explanations WHERE race_id=?",(race_id,))

    totals={}
    now=datetime.now().isoformat(timespec="seconds")
    for boat in range(1,7):
        total,details=gated_external_adjustment(con,race_id,boat)
        totals[boat]=total
        for d in details:
            con.execute("""INSERT INTO external_adjustment_explanations
              (race_id,boat_no,source_id,category,gate_multiplier,base_trust,
               polarity,confidence,adjustment,evidence_text,generated_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
              (race_id,boat,d["source_id"],d["category"],d["gate_multiplier"],
               d["base_trust"],d["polarity"],d["confidence"],d["adjustment"],
               d["evidence_text"],now))
    con.commit()
    return totals

def explain_boat(con,race_id,boat_no):
    total,details=gated_external_adjustment(con,race_id,boat_no)
    return {"race_id":race_id,"boat_no":boat_no,"total_adjustment":total,"details":details}
