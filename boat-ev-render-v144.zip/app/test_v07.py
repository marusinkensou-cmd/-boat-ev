import sqlite3, tempfile
from pathlib import Path
from datetime import date, timedelta
from parse_bk import ensure_schema
from external_ingest_v04 import upsert_source, add_post, add_signal
from attribution_v06 import aggregate, save_table
from gated_external_v07 import gated_external_adjustment, rebuild_gated_adjustments

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    sid=upsert_source(con,"blog","信頼できる戸田ブログ","https://example.com",.6)

    # Build 30 historical observations so the source/category/venue gate has evidence.
    base=date(2026,3,1)
    for i in range(30):
        d=(base+timedelta(days=i//12)).isoformat()
        rno=(i%12)+1
        rid=f"h{i}"
        con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)",(rid,d,'02',rno,'finished'))
        finish=2 if i<24 else 5
        con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES(?,?,?,?)",(rid,3,finish,3))
        con.execute("INSERT INTO payouts(race_id,bet_type,combination,amount_yen,popularity) VALUES(?,?,?,?,?)",(rid,'3連単','123',2500,3))
        p=add_post(con,sid,{"raw_text":"3号艇伸び良い","race_date":d,"jcd":"02","race_no":rno,"boat_no":3})
        add_signal(con,p,"伸び","boat","3",1,.9,"伸び良い")
    con.commit()

    rows=aggregate(con); save_table(con,rows)

    # Target race.
    rid="target"
    con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)",(rid,'2026-04-01','02',5,'scheduled'))
    p=add_post(con,sid,{"raw_text":"5R 3号艇伸び◎","race_date":"2026-04-01","jcd":"02","race_no":5,"boat_no":3})
    add_signal(con,p,"伸び","boat","3",1,.9,"3号艇伸び◎")
    con.commit()

    total,details=gated_external_adjustment(con,rid,3)
    assert total>0
    assert details and details[0]["gate_multiplier"]>1.15
    totals=rebuild_gated_adjustments(con,rid)
    assert totals[3]>0
    n=con.execute("SELECT COUNT(*) FROM external_adjustment_explanations WHERE race_id=?",(rid,)).fetchone()[0]
    assert n==1
    print("v0.7 gated model test: OK")
    print("boat3 total adjustment:",round(total,4))
    print("gate:",round(details[0]["gate_multiplier"],3))
