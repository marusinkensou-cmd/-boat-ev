from __future__ import annotations
import argparse, sqlite3, math
from collections import defaultdict
from datetime import datetime

DEFAULT_CATEGORY_WEIGHT = {
    "出足":1.00,
    "伸び":1.00,
    "回り足":0.90,
    "乗り心地":0.55,
    "スタート気配":0.75,
    "モーター評価":0.95,
    "本命評価":0.40,
    "穴評価":0.35,
    "総合評価":0.50,
}

def source_trust(con, source_id, category):
    row=con.execute("""SELECT weighted_score,samples FROM source_scores
                       WHERE source_id=? AND category=?""",(source_id,category)).fetchone()
    if row:
        score,samples=row
        # shrink toward 0.5 until enough history exists
        shrink=min(1.0,samples/50.0)
        return .5*(1-shrink)+score*shrink
    row=con.execute("SELECT base_trust FROM external_sources WHERE source_id=?",(source_id,)).fetchone()
    return row[0] if row else .5

def build_adjustments(con, race_id, max_total_adjust=.06):
    race=con.execute("SELECT race_date,jcd,race_no FROM races WHERE race_id=?",(race_id,)).fetchone()
    if not race: return []
    race_date,jcd,race_no=race
    q="""SELECT p.source_id,p.boat_no,s.category,s.polarity,s.confidence
         FROM external_posts p
         JOIN external_signals s ON s.post_id=p.post_id
         WHERE p.race_date=? AND p.jcd=? AND p.race_no=? AND p.boat_no BETWEEN 1 AND 6"""
    agg=defaultdict(list)
    for source_id,boat,cat,pol,conf in con.execute(q,(race_date,jcd,race_no)):
        trust=source_trust(con,source_id,cat)
        w=DEFAULT_CATEGORY_WEIGHT.get(cat,.5)
        agg[(boat,cat)].append(pol*conf*trust*w)

    con.execute("DELETE FROM external_race_adjustments WHERE race_id=?",(race_id,))
    boat_totals=defaultdict(float)
    rows=[]
    for (boat,cat),vals in agg.items():
        # agreement boosts confidence, disagreement naturally cancels.
        signal=sum(vals)/max(1,len(vals))
        adjustment=max(-.02,min(.02,signal*.02))
        boat_totals[boat]+=adjustment
        con.execute("""INSERT INTO external_race_adjustments
          (race_id,boat_no,category,signal_count,weighted_signal,adjustment,generated_at)
          VALUES(?,?,?,?,?,?,?)""",
          (race_id,boat,cat,len(vals),signal,adjustment,datetime.now().isoformat(timespec="seconds")))
        rows.append((boat,cat,len(vals),signal,adjustment))
    con.commit()
    # final boat total is capped: external opinion can reinforce, not dominate.
    return rows, {b:max(-max_total_adjust,min(max_total_adjust,v)) for b,v in boat_totals.items()}

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--race-id",required=True)
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    rows,tot=build_adjustments(con,a.race_id)
    for row in rows: print(row)
    print("boat totals:",tot)
