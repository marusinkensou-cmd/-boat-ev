from __future__ import annotations
import argparse, csv, json, sqlite3
from datetime import datetime
from pathlib import Path

CATEGORIES = {
    "出足","伸び","回り足","乗り心地","スタート気配",
    "モーター評価","本命評価","穴評価","総合評価"
}

def upsert_source(con, platform, name, url=None, base_trust=.5):
    con.execute("""INSERT INTO external_sources(platform,source_name,source_url,base_trust)
                   VALUES(?,?,?,?)
                   ON CONFLICT(platform,source_name) DO UPDATE SET
                   source_url=COALESCE(excluded.source_url,external_sources.source_url),
                   base_trust=excluded.base_trust""",
                (platform,name,url,base_trust))
    return con.execute("SELECT source_id FROM external_sources WHERE platform=? AND source_name=?",
                       (platform,name)).fetchone()[0]

def add_post(con, source_id, row):
    cur=con.execute("""INSERT INTO external_posts
    (source_id,external_id,posted_at,collected_at,url,raw_text,race_date,jcd,race_no,
     racer_no,boat_no,motor_no)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(
        source_id,row.get("external_id"),row.get("posted_at"),
        datetime.now().isoformat(timespec="seconds"),row.get("url"),
        row["raw_text"],row.get("race_date"),row.get("jcd"),
        row.get("race_no"),row.get("racer_no"),row.get("boat_no"),row.get("motor_no")
    ))
    return cur.lastrowid

def add_signal(con, post_id, category, target_type, target_value, polarity, confidence=.5, evidence_text=None):
    if category not in CATEGORIES:
        raise ValueError(f"unknown category: {category}")
    polarity=max(-1.0,min(1.0,float(polarity)))
    confidence=max(0.0,min(1.0,float(confidence)))
    con.execute("""INSERT INTO external_signals
      (post_id,category,target_type,target_value,polarity,confidence,evidence_text)
      VALUES(?,?,?,?,?,?,?)""",
      (post_id,category,target_type,target_value,polarity,confidence,evidence_text))

def import_jsonl(con,path):
    count=0
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        row=json.loads(line)
        sid=upsert_source(con,row["platform"],row["source_name"],row.get("source_url"),row.get("base_trust",.5))
        pid=add_post(con,sid,row)
        for s in row.get("signals",[]):
            add_signal(con,pid,s["category"],s["target_type"],s.get("target_value"),
                       s["polarity"],s.get("confidence",.5),s.get("evidence_text"))
        count+=1
    con.commit()
    print(f"imported posts: {count}")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--jsonl",required=True)
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    import_jsonl(con,a.jsonl)
