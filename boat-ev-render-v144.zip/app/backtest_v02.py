from __future__ import annotations
import argparse, sqlite3, math
from collections import defaultdict
from itertools import permutations

COURSE_PRIOR = {1:1.00,2:.73,3:.69,4:.63,5:.49,6:.36}

def clamp(x,a=0,b=1): return max(a,min(b,x))

def norm_winrate(x):
    if x is None: return .5
    return clamp((x-2.0)/7.0)

def norm_st(x):
    if x is None: return .5
    return clamp((.30-x)/.22)

def norm_motor(x):
    if x is None: return .5
    return clamp(x/60.0)

def feature_score(row, recent):
    boat, racer, nw, lw, avgst, motor2 = row
    r = recent.get(racer, (0,0,0))
    starts,wins,top3 = r
    winf = wins/starts if starts else .20
    top3f = top3/starts if starts else .50
    return (
        .25*norm_winrate(nw) +
        .20*COURSE_PRIOR.get(boat,.5) +
        .15*norm_motor(motor2) +
        .10*norm_winrate(lw) +
        .10*clamp(winf/.45) +
        .10*norm_st(avgst) +
        .05*clamp(top3f/.75) +
        .05*.5
    )

def trifecta_probs(scored):
    strengths={boat:math.exp(score*4) for boat,score in scored}
    out={}
    for a,b,c in permutations(strengths,3):
        p1=strengths[a]/sum(strengths.values())
        p2=strengths[b]/sum(v for k,v in strengths.items() if k!=a)
        p3=strengths[c]/sum(v for k,v in strengths.items() if k not in (a,b))
        out[f"{a}{b}{c}"]=p1*p2*p3
    return out

def recent_form(con, race_date, limit=50):
    # Historical only: every row is strictly before the target date to prevent leakage.
    q="""SELECT r.racer_no, res.finish
         FROM results res
         JOIN races rc ON rc.race_id=res.race_id
         LEFT JOIN entries r ON r.race_id=res.race_id AND r.boat_no=res.boat_no
         WHERE rc.race_date < ? AND r.racer_no IS NOT NULL
         ORDER BY rc.race_date DESC"""
    buckets=defaultdict(list)
    for racer,finish in con.execute(q,(race_date,)):
        if len(buckets[racer])<limit: buckets[racer].append(finish)
    out={}
    for racer,fs in buckets.items():
        valid=[x for x in fs if x]
        out[racer]=(len(valid),sum(x==1 for x in valid),sum(x<=3 for x in valid))
    return out

def run(db, start, end, stake=100, topn=5, prob_floor=.02):
    con=sqlite3.connect(db)
    race_ids=con.execute("""SELECT race_id,race_date FROM races
      WHERE race_date BETWEEN ? AND ? ORDER BY race_date,jcd,race_no""",(start,end)).fetchall()
    seen=bet_races=tickets=hits=stake_total=ret=0
    for rid,rdate in race_ids:
        entries=con.execute("""SELECT boat_no,racer_no,national_win_rate,local_win_rate,
                    avg_st,motor_quinella_rate FROM entries WHERE race_id=? ORDER BY boat_no""",(rid,)).fetchall()
        if len(entries)!=6: continue
        payout=con.execute("""SELECT combination,amount_yen FROM payouts
                    WHERE race_id=? AND bet_type='3連単' LIMIT 1""",(rid,)).fetchone()
        if not payout: continue
        seen+=1
        recent=recent_form(con,rdate)
        scored=[(row[0],feature_score(row,recent)) for row in entries]
        probs=trifecta_probs(scored)
        picks=sorted([(c,p) for c,p in probs.items() if p>=prob_floor],
                     key=lambda x:x[1],reverse=True)[:topn]
        if not picks: continue
        bet_races+=1; tickets+=len(picks); stake_total+=stake*len(picks)
        wincombo,amount=payout
        if any(c==wincombo for c,_ in picks):
            hits+=1; ret+=amount*(stake/100)
    recovery=(ret/stake_total*100) if stake_total else 0
    print(f"対象レース {seen}")
    print(f"購入レース {bet_races}")
    print(f"購入点数 {tickets}")
    print(f"的中 {hits}")
    print(f"投資 ¥{stake_total:,.0f}")
    print(f"払戻 ¥{ret:,.0f}")
    print(f"回収率 {recovery:.1f}%")
    return {"seen":seen,"bet_races":bet_races,"tickets":tickets,"hits":hits,
            "stake":stake_total,"return":ret,"recovery":recovery}

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--start",required=True)
    ap.add_argument("--end",required=True)
    ap.add_argument("--stake",type=int,default=100)
    ap.add_argument("--topn",type=int,default=5)
    ap.add_argument("--prob-floor",type=float,default=.02)
    a=ap.parse_args()
    run(a.db,a.start,a.end,a.stake,a.topn,a.prob_floor)
