from __future__ import annotations
import argparse, sqlite3, json
from gated_external_v07 import explain_boat, rebuild_gated_adjustments

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--race-id",required=True)
    ap.add_argument("--boat",type=int)
    ap.add_argument("--rebuild",action="store_true")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    if a.rebuild:
        print(json.dumps(rebuild_gated_adjustments(con,a.race_id),ensure_ascii=False,indent=2))
    if a.boat:
        print(json.dumps(explain_boat(con,a.race_id,a.boat),ensure_ascii=False,indent=2))
