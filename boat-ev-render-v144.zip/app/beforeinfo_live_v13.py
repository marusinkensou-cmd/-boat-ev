from __future__ import annotations
import re
from bs4 import BeautifulSoup
from official_live_v10 import fetch_html,official_url

TRANS=str.maketrans("１２３４５６","123456")
PART_WORDS=["ピストン","リング","電気","キャブ","シリンダ","シャフト","ギヤ","キャリボ"]

def parse_beforeinfo_v13(html):
    soup=BeautifulSoup(html,"html.parser")
    boats={}
    for tr in soup.find_all("tr"):
        cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
        if not cells: continue
        first=re.sub(r"\s+","",cells[0]).translate(TRANS)
        if first not in {"1","2","3","4","5","6"}: continue
        joined=" ".join(cells)
        weight=re.search(r"(\d{2}(?:\.\d)?)\s*kg",joined)
        ex=re.search(r"\b(6\.\d{2})\b",joined)
        mt=re.search(r"(?<!\d)([-+]?(?:-0\.5|0\.0|0\.5|1\.0|1\.5|2\.0|3\.0))(?!\d)",joined)
        prop=1 if re.search(r"(?:プロペラ|ペラ).*新|新.*(?:プロペラ|ペラ)",joined) else 0
        parts=[p for p in PART_WORDS if p in joined]
        boats[int(first)]={
            "boat_no":int(first),
            "weight_kg":float(weight.group(1)) if weight else None,
            "exhibition_time":float(ex.group(1)) if ex else None,
            "tilt":float(mt.group(1)) if mt else None,
            "propeller_changed":prop,
            "parts_changed":"、".join(parts) if parts else None,
            "exhibition_course":None,
            "exhibition_st":None,
        }

    text=soup.get_text(" ",strip=True)
    start_pos=text.find("スタート展示")
    if start_pos>=0:
        segment=text[start_pos:start_pos+700]
        pairs=re.findall(r"([1-6])\s+(F?\.?\d{2})",segment)
        for course,(boat,sttxt) in enumerate(pairs[:6],1):
            boat=int(boat)
            if boat not in boats:
                boats[boat]={"boat_no":boat,"weight_kg":None,"exhibition_time":None,"tilt":None,
                             "propeller_changed":0,"parts_changed":None,
                             "exhibition_course":None,"exhibition_st":None}
            val=sttxt.replace("F","")
            if val.startswith("."): val="0"+val
            try: st=float(val)
            except: st=None
            boats[boat]["exhibition_course"]=course
            boats[boat]["exhibition_st"]=-st if sttxt.startswith("F") and st is not None else st

    def val(pat):
        m=re.search(pat,text)
        return float(m.group(1)) if m else None
    weather=next((w for w in ["晴","曇り","雨","雪","霧"] if w in text),None)
    meta={
        "weather":weather,
        "air_temp_c":val(r"気温\s*([0-9.]+)℃"),
        "water_temp_c":val(r"水温\s*([0-9.]+)℃"),
        "wind_speed_m":val(r"風速\s*([0-9.]+)m"),
        "wave_height_cm":val(r"波高\s*([0-9.]+)cm"),
        "wind_dir":None,
    }
    return [boats[k] for k in sorted(boats)],meta

def refresh_beforeinfo_v13(con,race_date,jcd,rno,cache_dir="cache/live"):
    html,source=fetch_html(official_url("beforeinfo",race_date,jcd,rno),cache_dir=cache_dir,max_age_sec=60)
    boats,weather=parse_beforeinfo_v13(html)
    rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
    for b in boats:
        con.execute("""INSERT INTO beforeinfo(
                       race_id,boat_no,exhibition_time,tilt,exhibition_course,exhibition_st)
                       VALUES(?,?,?,?,?,?)
                       ON CONFLICT(race_id,boat_no) DO UPDATE SET
                       exhibition_time=excluded.exhibition_time,tilt=excluded.tilt,
                       exhibition_course=excluded.exhibition_course,exhibition_st=excluded.exhibition_st""",
                    (rid,b["boat_no"],b["exhibition_time"],b["tilt"],b["exhibition_course"],b["exhibition_st"]))
        con.execute("""INSERT INTO beforeinfo_extra(race_id,boat_no,propeller_changed,parts_changed)
                       VALUES(?,?,?,?)
                       ON CONFLICT(race_id,boat_no) DO UPDATE SET
                       propeller_changed=excluded.propeller_changed,parts_changed=excluded.parts_changed""",
                    (rid,b["boat_no"],b["propeller_changed"],b["parts_changed"]))
        if b["weight_kg"] is not None:
            con.execute("UPDATE entries SET weight_kg=? WHERE race_id=? AND boat_no=?",
                        (b["weight_kg"],rid,b["boat_no"]))
    con.execute("""INSERT INTO race_weather(
                   race_id,weather,air_temp_c,water_temp_c,wind_dir,wind_speed_m,wave_height_cm)
                   VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(race_id) DO UPDATE SET
                   weather=excluded.weather,air_temp_c=excluded.air_temp_c,
                   water_temp_c=excluded.water_temp_c,wind_dir=excluded.wind_dir,
                   wind_speed_m=excluded.wind_speed_m,wave_height_cm=excluded.wave_height_cm""",
                (rid,weather["weather"],weather["air_temp_c"],weather["water_temp_c"],
                 weather["wind_dir"],weather["wind_speed_m"],weather["wave_height_cm"]))
    con.commit()
    return {"race_id":rid,"beforeinfo_count":len(boats),"source":source}
