from __future__ import annotations
import argparse, sqlite3, math, csv
from collections import defaultdict
from itertools import permutations
from gated_external_v07 import gated_external_adjustment

COURSE_PRIOR={1:1.0,2:.73,3:.69,4:.63,5:.49,6:.36}

def clamp(x,a=0,b=1): return max(a,min(b,x))
def nwr(x): return .5 if x is None else clamp((x-2)/7)
def nst(x): return .5 if x is None else clamp((.30-x)/.22)
def nm(x): return .5 if x is None else clamp(x/60)

def recent_before(con,target,maxn=30):
    q="""SELECT e.racer_no,r.finish
         FROM results r JOIN races rc ON rc.race_id=r.race_id
         JOIN entries e ON e.race_id=r.race_id AND e.boat_no=r.boat_no
         WHERE rc.race_date < ? AND e.racer_no IS NOT NULL
         ORDER BY rc.race_date DESC,rc.race_no DESC"""
    d=defaultdict(list)
    for racer,fin in con.execute(q,(target,)):
        if len(d[racer])<maxn: d[racer].append(fin)
    return {k:(len(v),sum(x==1 for x in v),sum(x and x<=3 for x in v)) for k,v in d.items()}

def base_score(row,recent):
    boat,racer,nw,lw,avgst,motor2=row
    starts,wins,top3=recent.get(racer,(0,0,0))
    winf=wins/starts if starts else .20
    top3f=top3/starts if starts else .50
    return (.25*nwr(nw)+.20*COURSE_PRIOR.get(boat,.5)+.15*nm(motor2)+
            .10*nwr(lw)+.10*clamp(winf/.45)+.10*nst(avgst)+
            .05*clamp(top3f/.75)+.05*.5)

def bw(v):
    if v is None:return "unknown"
    if v<2:return "0-1"
    if v<4:return "2-3"
    if v<6:return "4-5"
    return "6+"

def bv(v):
    if v is None:return "unknown"
    if v<=2:return "0-2"
    if v<=5:return "3-5"
    if v<=10:return "6-10"
    return "11+"

def venue_adjust(con,rid,boat):
    row=con.execute("""SELECT rc.jcd,w.wind_speed_m,w.wave_height_cm
        FROM races rc LEFT JOIN race_weather w ON w.race_id=rc.race_id
        WHERE rc.race_id=?""",(rid,)).fetchone()
    if not row:return 0
    jcd,wind,wave=row
    s=con.execute("""SELECT starts,win_rate FROM venue_condition_stats
      WHERE jcd=? AND course=? AND wind_bucket=? AND wave_bucket=?""",
      (jcd,boat,bw(wind),bv(wave))).fetchone()
    if not s or s[0]<30:return 0
    prior={1:.55,2:.15,3:.12,4:.10,5:.05,6:.03}.get(boat,.10)
    return clamp((s[1]-prior)*.5,-.05,.05)

def trifecta_probs(scores):
    x={b:math.exp(v*4) for b,v in scores}
    den=sum(x.values()); out={}
    for a,b,c in permutations(x,3):
        p1=x[a]/den
        p2=x[b]/sum(v for k,v in x.items() if k!=a)
        p3=x[c]/sum(v for k,v in x.items() if k not in (a,b))
        out[f"{a}{b}{c}"]=p1*p2*p3
    return out

def predict(con,rid,rdate,model,recent):
    es=con.execute("""SELECT boat_no,racer_no,national_win_rate,local_win_rate,avg_st,motor_quinella_rate
                      FROM entries WHERE race_id=? ORDER BY boat_no""",(rid,)).fetchall()
    if len(es)!=6:return None
    scores=[]
    for row in es:
        boat=row[0]; s=base_score(row,recent)
        if model in ("B","C0","C1"): s += venue_adjust(con,rid,boat)
        if model=="C0":
            q=con.execute("""SELECT COALESCE(SUM(adjustment),0) FROM external_race_adjustments
                             WHERE race_id=? AND boat_no=?""",(rid,boat)).fetchone()[0]
            s += clamp(q,-.06,.06)
        if model=="C1":
            q,_=gated_external_adjustment(con,rid,boat)
            s += q
        scores.append((boat,s))
    return trifecta_probs(scores)

def eval_model(con,start,end,model,topn=5,stake=100):
    races=con.execute("""SELECT race_id,race_date FROM races WHERE race_date BETWEEN ? AND ?
                         ORDER BY race_date,jcd,race_no""",(start,end)).fetchall()
    d={"races":0,"hits":0,"stake":0,"ret":0.0,"brier":0.0,"logloss":0.0}
    cached=None; recent={}
    for rid,rdate in races:
        pay=con.execute("SELECT combination,amount_yen FROM payouts WHERE race_id=? AND bet_type='3連単' LIMIT 1",(rid,)).fetchone()
        if not pay:continue
        if cached!=rdate:
            recent=recent_before(con,rdate); cached=rdate
        probs=predict(con,rid,rdate,model,recent)
        if not probs:continue
        actual,amount=pay
        picks=sorted(probs.items(),key=lambda x:x[1],reverse=True)[:topn]
        d["races"]+=1; d["stake"]+=stake*len(picks)
        d["brier"]+=sum((p-(1 if c==actual else 0))**2 for c,p in probs.items())
        d["logloss"]+=-math.log(max(1e-9,probs.get(actual,1e-9)))
        if any(c==actual for c,_ in picks):
            d["hits"]+=1; d["ret"]+=amount*(stake/100)
    if d["races"]:
        d["brier"]/=d["races"]; d["logloss"]/=d["races"]
    d["hit_rate"]=d["hits"]/d["races"] if d["races"] else 0
    d["recovery_rate"]=d["ret"]/d["stake"]*100 if d["stake"] else 0
    return d

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--start",required=True)
    ap.add_argument("--end",required=True)
    ap.add_argument("--topn",type=int,default=5)
    ap.add_argument("--out",default="compare_v07.csv")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    models={
      "A":"基本",
      "B":"基本+場条件",
      "C0":"B+外部情報（無選別）",
      "C1":"B+外部情報（信頼度ゲート）",
    }
    rows=[]
    for code,name in models.items():
        d=eval_model(con,a.start,a.end,code,a.topn)
        row={"model":code,"name":name,**d}
        rows.append(row)
        print(code,name,d)
    with open(a.out,"w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print("saved:",a.out)

if __name__=="__main__":
    main()
