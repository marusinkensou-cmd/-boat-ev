from official_live_v10 import parse_deadlines,parse_trifecta_odds

# Synthetic DOM that mirrors the official visible six-column-group layout.
times=" ".join(["10:28","10:58","11:24","11:54","12:24","12:53","13:23","13:53","14:28","15:03","15:38","16:15"])
rows=[]
for second_pos in range(1,6):
    # Produce 20 rows per first boat overall by cycling valid second/third pairs.
    pass

pairs={}
for first in range(1,7):
    pairs[first]=[(s,t) for s in range(1,7) for t in range(1,7) if len({first,s,t})==3]

for idx in range(20):
    cells=[]
    for first in range(1,7):
        s,t=pairs[first][idx]
        odds=round(5.0+first*10+idx/10,1)
        cells += [f"<td>{s}</td>",f"<td>{t}</td>",f"<td>{odds}</td>"]
    rows.append("<tr>"+"".join(cells)+"</tr>")

html=f"""<html><body>
<div>締切予定時刻 {times}</div>
<h3>3連単オッズ</h3>
<table><tr><th>オッズ</th></tr>{''.join(rows)}</table>
</body></html>"""

d=parse_deadlines(html)
assert len(d)==12 and d[1]=="10:28" and d[12]=="16:15",d
o=parse_trifecta_odds(html)
assert len(o)==120,len(o)
assert set(o)=={f"{a}{b}{c}" for a in range(1,7) for b in range(1,7) for c in range(1,7) if len({a,b,c})==3}
print("v1.0 official parser fixture test: OK")
print("deadlines:",len(d),"trifecta odds:",len(o))
