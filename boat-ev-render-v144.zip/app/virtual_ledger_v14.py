from __future__ import annotations
from datetime import datetime


def _iso(now):
    return now.isoformat(timespec="seconds") if hasattr(now, "isoformat") else str(now)


def record_board(con, board, now: datetime, model="C1", stake_per_ticket=100):
    """Save/replace the latest pre-deadline paper-trading plan for each race.

    One plan per race/model prevents repeated refreshes from double-counting bets.
    Until settlement, the newest recommendation replaces the older one.
    """
    saved = 0
    for r in board:
        if r.get("grade") == "DATA":
            continue
        # Never create/replace a plan after the deadline.
        if float(r.get("minutes_to_deadline", -1)) < 0:
            continue
        rid = r["race_id"]
        settled = con.execute(
            "SELECT plan_id,settled_at FROM virtual_plans WHERE race_id=? AND model_version=?",
            (rid, model),
        ).fetchone()
        if settled and settled[1]:
            continue

        bets = r.get("bets") or []
        total_stake = len(bets) * int(stake_per_ticket)
        captured_at = r.get("odds_captured_at") or _iso(now)
        con.execute(
            """INSERT INTO virtual_plans
               (race_id,model_version,grade,decision,captured_at,stake_per_ticket,total_stake,total_return)
               VALUES(?,?,?,?,?,?,?,0)
               ON CONFLICT(race_id,model_version) DO UPDATE SET
                 grade=excluded.grade,
                 decision=excluded.decision,
                 captured_at=excluded.captured_at,
                 stake_per_ticket=excluded.stake_per_ticket,
                 total_stake=excluded.total_stake,
                 total_return=0,
                 settle_note=NULL
               WHERE virtual_plans.settled_at IS NULL""",
            (rid, model, r.get("grade", "PASS"), r.get("decision", "pass"), captured_at,
             int(stake_per_ticket), total_stake),
        )
        plan_id = con.execute(
            "SELECT plan_id FROM virtual_plans WHERE race_id=? AND model_version=?", (rid, model)
        ).fetchone()[0]
        con.execute("DELETE FROM virtual_bets WHERE plan_id=?", (plan_id,))
        for b in bets:
            con.execute(
                """INSERT INTO virtual_bets
                   (plan_id,combination,predicted_prob,market_odds,expected_value,stake_yen)
                   VALUES(?,?,?,?,?,?)""",
                (plan_id, b["combination"], float(b["predicted_prob"]), float(b["market_odds"]),
                 float(b["ev"]), int(stake_per_ticket)),
            )
        saved += 1
    con.commit()
    return saved


def settle_plan(con, plan_id: int, result_combo: str, payout_per_100: int, now: datetime, note="official_resultlist"):
    row = con.execute("SELECT settled_at FROM virtual_plans WHERE plan_id=?", (plan_id,)).fetchone()
    if not row or row[0]:
        return False
    total_return = 0
    for combo, stake in con.execute(
        "SELECT combination,stake_yen FROM virtual_bets WHERE plan_id=?", (plan_id,)
    ).fetchall():
        hit = int(combo == result_combo)
        ret = int(round(int(payout_per_100) * (int(stake) / 100.0))) if hit else 0
        total_return += ret
        con.execute(
            "UPDATE virtual_bets SET hit=?,return_yen=? WHERE plan_id=? AND combination=?",
            (hit, ret, plan_id, combo),
        )
    con.execute(
        """UPDATE virtual_plans SET settled_at=?,result_combo=?,payout_per_100=?,
           total_return=?,settle_note=? WHERE plan_id=?""",
        (_iso(now), result_combo, int(payout_per_100), total_return, note, plan_id),
    )
    con.commit()
    return True


def stats(con, race_date=None):
    where = ""
    params = []
    if race_date:
        where = " WHERE r.race_date=?"
        params.append(race_date)
    rows = con.execute(
        """SELECT vp.plan_id,vp.grade,vp.decision,vp.total_stake,vp.total_return,vp.settled_at
           FROM virtual_plans vp JOIN races r ON r.race_id=vp.race_id""" + where,
        params,
    ).fetchall()
    settled = [x for x in rows if x[5]]
    stake = sum(int(x[3] or 0) for x in settled)
    ret = sum(int(x[4] or 0) for x in settled)
    tickets = 0
    hits = 0
    if settled:
        ids = [x[0] for x in settled]
        q = ",".join("?" for _ in ids)
        tickets, hits = con.execute(
            f"SELECT COUNT(*),COALESCE(SUM(CASE WHEN hit=1 THEN 1 ELSE 0 END),0) FROM virtual_bets WHERE plan_id IN ({q})",
            ids,
        ).fetchone()
    bet_races = sum(1 for x in settled if int(x[3] or 0) > 0)
    return {
        "plans": len(rows),
        "settled_races": len(settled),
        "bet_races": bet_races,
        "tickets": int(tickets or 0),
        "hits": int(hits or 0),
        "stake_yen": stake,
        "return_yen": ret,
        "profit_yen": ret - stake,
        "recovery_rate": (ret / stake * 100.0) if stake else None,
    }


def grade_stats(con):
    out = {}
    for grade, stake, ret, n in con.execute(
        """SELECT grade,COALESCE(SUM(total_stake),0),COALESCE(SUM(total_return),0),COUNT(*)
           FROM virtual_plans WHERE settled_at IS NOT NULL GROUP BY grade"""
    ):
        stake = int(stake or 0); ret = int(ret or 0)
        out[grade] = {"races": int(n), "stake_yen": stake, "return_yen": ret,
                      "recovery_rate": (ret / stake * 100.0) if stake else None}
    return out
