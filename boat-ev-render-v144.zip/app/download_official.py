from __future__ import annotations
import argparse, hashlib, sqlite3, time
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

BASE = "https://www1.mbrace.or.jp/od2/{kind}/{yyyymm}/{kind_lower}{yymmdd}.lzh"

def iter_days(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)

def url_for(kind: str, d: date) -> str:
    return BASE.format(kind=kind, yyyymm=d.strftime("%Y%m"),
                       kind_lower=kind.lower(), yymmdd=d.strftime("%y%m%d"))

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def init_db(db_path: Path, schema_path: Path):
    with sqlite3.connect(db_path) as con:
        con.executescript(schema_path.read_text(encoding="utf-8"))

def record_raw(db_path: Path, kind: str, d: date, url: str, path: Path):
    with sqlite3.connect(db_path) as con:
        con.execute("""INSERT INTO raw_files
        (kind,target_date,source_url,local_path,sha256,size_bytes,downloaded_at)
        VALUES(?,?,?,?,?,?,?)""",
        (kind, d.isoformat(), url, str(path), sha256_file(path), path.stat().st_size,
         datetime.now().isoformat(timespec="seconds")))

def download_one(kind: str, d: date, outdir: Path, timeout: int = 20):
    url = url_for(kind, d)
    dest = outdir / kind / d.strftime("%Y%m") / f"{kind.lower()}{d.strftime('%y%m%d')}.lzh"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        return True, str(dest)
    tmp = dest.with_suffix(".part")
    req = Request(url, headers={"User-Agent": "BoatraceResearch/0.1"})
    try:
        with urlopen(req, timeout=timeout) as r, tmp.open("wb") as f:
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
        if not tmp.exists() or tmp.stat().st_size == 0:
            tmp.unlink(missing_ok=True)
            return False, f"empty: {url}"
        tmp.replace(dest)
        return True, str(dest)
    except (HTTPError, URLError, TimeoutError, OSError) as e:
        tmp.unlink(missing_ok=True)
        return False, f"{url} -> {e}"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--start", required=True)
    p.add_argument("--end", required=True)
    p.add_argument("--kind", choices=["B","K","both"], default="both")
    p.add_argument("--sleep", type=float, default=1.5)
    p.add_argument("--out", default="data/raw")
    p.add_argument("--db", default="data/boatrace.sqlite")
    p.add_argument("--schema", default="schema.sql")
    args = p.parse_args()

    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    outdir, db = Path(args.out), Path(args.db)
    db.parent.mkdir(parents=True, exist_ok=True)
    init_db(db, Path(args.schema))
    kinds = ["B","K"] if args.kind == "both" else [args.kind]
    ok, fail = 0, []
    for d in iter_days(start, end):
        for kind in kinds:
            success, info = download_one(kind, d, outdir)
            if success:
                path = Path(info)
                with sqlite3.connect(db) as con:
                    exists = con.execute(
                        "SELECT 1 FROM raw_files WHERE kind=? AND target_date=? AND local_path=?",
                        (kind, d.isoformat(), str(path))).fetchone()
                if not exists:
                    record_raw(db, kind, d, url_for(kind, d), path)
                ok += 1
                print("OK", kind, d, info)
            else:
                fail.append((kind, d.isoformat(), info))
                print("NG", kind, d, info)
            time.sleep(args.sleep)
    print(f"成功: {ok} / 失敗: {len(fail)}")
    for row in fail:
        print(" -", *row)

if __name__ == "__main__":
    main()
