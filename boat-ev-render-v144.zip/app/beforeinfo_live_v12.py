from __future__ import annotations
import re
from bs4 import BeautifulSoup
from official_live_v10 import fetch_html,official_url

TRANS=str.maketrans("１２３４５６","123456")

def parse_beforeinfo(html):
    soup=BeautifulSoup(html,"html.parser")
    boats=[]
    for tr in soup.find_all("tr"):
        cells=[c.get_text(" ",strip=True) for c in tr.find_all(["td","th"])]
        if not cells: continue
        first=re.sub(r"\s+","",cells[0]).translate(TRANS)
        if first not in {"1","2","3","4","5","6"}: continue
        joined=" ".join(cells)
        weight=re.search(r"(\d{2}(?:\.\d)?)\s*kg",joined)
        ex=re.search(r"\b(6\.\d{2})\b",joined)
        tilt=None
        for token in re.findall(r"[-+]?\d+(?:\.\d+)?",joined):
            x=float(token)
            if -1.0<=x<=3.0 and not (0<=x<=0.30):
                tilt=x; break
        boats.append({
            "boat_no":int(first),
            "weight_kg":float(weight.group(1)) if weight else None,
            "exhibition_time":float(ex.group(1)) if ex else None,
            "tilt":tilt
        })
    uniq={b["boat_no"]:b for b in boats}
    text=soup.get_text(" ",strip=True)
    weather=next((w for w in ["晴","曇り","雨","雪","霧"] if w in text),None)
    def val(pattern):
        m=re.search(pattern,text); return float(m.group(1)) if m else None
    meta={
      "weather":weather,
      "air_temp_c":val(r"気温\s*([0-9.]+)℃"),
      "water_temp_c":val(r"水温\s*([0-9.]+)℃"),
      "wind_speed_m":val(r"風速\s*([0-9.]+)m"),
      "wave_height_cm":val(r"波高\s*([0-9.]+)cm"),
    }
    return [uniq[k] for k in sorted(uniq)],meta

def refresh_beforeinfo(con,race_date,jcd,rno,cache_dir="cache/live"):
    html,source=fetch_html(official_url("beforeinfo",race_date,jcd,rno),cache_dir=cache_dir,max_age_sec=60)
    boats,weather=parse_beforeinfo(html)
    rid=f"{race_date.replace('-','')}-{jcd}-{rno:02d}"
    for b in boats:
        con.execute("""INSERT INTO beforeinfo(race_id,boat_no,exhibition_time,tilt)
                       VALUES(?,?,?,?)
                       ON CONFLICT(race_id,boat_no) DO UPDATE SET
                       exhibition_time=excluded.exhibition_time,tilt=excluded.tilt""",
                    (rid,b["boat_no"],b["exhibition_time"],b["tilt"]))
        if b["weight_kg"] is not None:
            con.execute("UPDATE entries SET weight_kg=? WHERE race_id=? AND boat_no=?",
                        (b["weight_kg"],rid,b["boat_no"]))
    con.execute("""INSERT INTO race_weather(race_id,weather,air_temp_c,water_temp_c,wind_speed_m,wave_height_cm)
                   VALUES(?,?,?,?,?,?)
                   ON CONFLICT(race_id) DO UPDATE SET
                   weather=excluded.weather,air_temp_c=excluded.air_temp_c,water_temp_c=excluded.water_temp_c,
                   wind_speed_m=excluded.wind_speed_m,wave_height_cm=excluded.wave_height_cm""",
                (rid,weather["weather"],weather["air_temp_c"],weather["water_temp_c"],
                 weather["wind_speed_m"],weather["wave_height_cm"]))
    con.commit()
    return {"race_id":rid,"beforeinfo_count":len(boats),"source":source}
