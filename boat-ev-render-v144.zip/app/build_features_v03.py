from __future__ import annotations
import argparse, sqlite3, math
from collections import defaultdict

def bucket_wind(v):
    if v is None: return "unknown"
    if v < 2: return "0-1"
    if v < 4: return "2-3"
    if v < 6: return "4-5"
    return "6+"

def bucket_wave(v):
    if v is None: return "unknown"
    if v <= 2: return "0-2"
    if v <= 5: return "3-5"
    if v <= 10: return "6-10"
    return "11+"

def rebuild(con):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS venue_condition_stats (
      jcd TEXT NOT NULL,
      course INTEGER NOT NULL,
      wind_bucket TEXT NOT NULL,
      wave_bucket TEXT NOT NULL,
      starts INTEGER NOT NULL,
      wins INTEGER NOT NULL,
      top2 INTEGER NOT NULL,
      top3 INTEGER NOT NULL,
      win_rate REAL NOT NULL,
      top2_rate REAL NOT NULL,
      top3_rate REAL NOT NULL,
      PRIMARY KEY(jcd,course,wind_bucket,wave_bucket)
    );
    DELETE FROM venue_condition_stats;
    """)
    q="""SELECT rc.jcd,res.actual_course,res.finish,w.wind_speed_m,w.wave_height_cm
         FROM results res
         JOIN races rc ON rc.race_id=res.race_id
         LEFT JOIN race_weather w ON w.race_id=res.race_id
         WHERE res.actual_course BETWEEN 1 AND 6 AND res.finish BETWEEN 1 AND 6"""
    agg=defaultdict(lambda:[0,0,0,0])
    for jcd,course,finish,wind,wave in con.execute(q):
        k=(jcd,course,bucket_wind(wind),bucket_wave(wave))
        a=agg[k]; a[0]+=1
        if finish==1: a[1]+=1
        if finish<=2: a[2]+=1
        if finish<=3: a[3]+=1
    for k,(n,w,t2,t3) in agg.items():
        con.execute("""INSERT INTO venue_condition_stats
        (jcd,course,wind_bucket,wave_bucket,starts,wins,top2,top3,win_rate,top2_rate,top3_rate)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (*k,n,w,t2,t3,w/n,t2/n,t3/n))
    con.commit()
    print(f"venue_condition_stats: {len(agg)} groups")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    rebuild(con)
