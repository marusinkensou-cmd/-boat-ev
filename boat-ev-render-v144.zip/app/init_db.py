from pathlib import Path
import sqlite3
from parse_bk import ensure_schema
root=Path(__file__).resolve().parent
db=root/"data"/"boatrace.sqlite"
db.parent.mkdir(exist_ok=True)
con=sqlite3.connect(db)
ensure_schema(con,root/"schema.sql")
print(f"DB initialized: {db}")
