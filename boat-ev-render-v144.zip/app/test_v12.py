from today_discovery_v12 import parse_today_venues
from racelist_live_v12 import parse_racelist_entries
from beforeinfo_live_v12 import parse_beforeinfo

idx="""<a href='/owpc/pc/race/racelist?hd=20260913&jcd=02&rno=1'>戸田</a>
<a href='/owpc/pc/race/racelist?hd=20260913&jcd=07&rno=1'>蒲郡</a>"""
v=parse_today_venues(idx)
assert [x["jcd"] for x in v]==["02","07"],v

rows=[]
for i in range(1,7):
    rows.append(f"""<tr><td>{i}</td>
<td>{4000+i} / A1 選手{i} 埼玉/埼玉 35歳/52.0kg</td>
<td>F0 L0 0.15</td><td>6.20 42.00 61.00</td><td>6.00 40.00 60.00</td>
<td>{20+i} 35.00 50.00</td><td>{40+i} 30.00 45.00</td></tr>""")
e=parse_racelist_entries("<table>"+''.join(rows)+"</table>")
assert len(e)==6,e
assert e[0]["racer_no"]==4001 and e[0]["motor_no"]==21,e[0]

brows=[]
for i in range(1,7):
    brows.append(f"<tr><td>{i}</td><td>52.0kg</td><td>6.{70+i:02d}</td><td>-0.5</td></tr>")
b,w=parse_beforeinfo("<div>晴 気温 28.0℃ 水温 25.0℃ 風速 3m 波高 2cm</div><table>"+''.join(brows)+"</table>")
assert len(b)==6,(b,w)
assert w["air_temp_c"]==28.0 and w["wind_speed_m"]==3.0,w
print("v1.2 live parser fixture test: OK")
print("venues:",len(v),"entries:",len(e),"beforeinfo:",len(b))
