import sqlite3,tempfile
from pathlib import Path
from parse_bk import ensure_schema
from official_live_v10 import store_odds

with tempfile.TemporaryDirectory() as td:
    con=sqlite3.connect(Path(td)/"x.sqlite")
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('09','津')")
    con.execute("""INSERT INTO races(race_id,race_date,jcd,race_no,deadline,status)
                   VALUES('20260825-09-01','2026-08-25','09',1,'10:28','scheduled')""")
    odds={f"{a}{b}{c}":10.0+a+b+c for a in range(1,7) for b in range(1,7) for c in range(1,7) if len({a,b,c})==3}
    sid=store_odds(con,'20260825-09-01',odds,'2026-08-25T10:20:00+09:00')
    n=con.execute("SELECT COUNT(*) FROM odds_trifecta WHERE snapshot_id=?",(sid,)).fetchone()[0]
    assert n==120,n
    print("v1.0 DB smoke test: OK",n)
