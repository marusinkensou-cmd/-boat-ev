from __future__ import annotations
import argparse, sqlite3, math, csv
from collections import defaultdict
from itertools import permutations

COURSE_PRIOR={1:1.0,2:.73,3:.69,4:.63,5:.49,6:.36}

def clamp(x,a=0,b=1): return max(a,min(b,x))
def nwr(x): return .5 if x is None else clamp((x-2)/7)
def nst(x): return .5 if x is None else clamp((.30-x)/.22)
def nm(x): return .5 if x is None else clamp(x/60)

def recent_before(con,target,maxn=30):
    q="""SELECT e.racer_no,r.finish
         FROM results r
         JOIN races rc ON rc.race_id=r.race_id
         JOIN entries e ON e.race_id=r.race_id AND e.boat_no=r.boat_no
         WHERE rc.race_date < ? AND e.racer_no IS NOT NULL
         ORDER BY rc.race_date DESC,rc.race_no DESC"""
    d=defaultdict(list)
    for racer,fin in con.execute(q,(target,)):
        if len(d[racer])<maxn: d[racer].append(fin)
    return {k:(len(v),sum(x==1 for x in v),sum(x and x<=3 for x in v)) for k,v in d.items()}

def base_score(row,recent):
    boat,racer,nw,lw,avgst,motor2=row
    starts,wins,top3=recent.get(racer,(0,0,0))
    winf=wins/starts if starts else .20
    top3f=top3/starts if starts else .50
    return (.25*nwr(nw)+.20*COURSE_PRIOR.get(boat,.5)+.15*nm(motor2)+
            .10*nwr(lw)+.10*clamp(winf/.45)+.10*nst(avgst)+
            .05*clamp(top3f/.75)+.05*.5)

def bucket_wind(v):
    if v is None:return "unknown"
    if v<2:return "0-1"
    if v<4:return "2-3"
    if v<6:return "4-5"
    return "6+"

def bucket_wave(v):
    if v is None:return "unknown"
    if v<=2:return "0-2"
    if v<=5:return "3-5"
    if v<=10:return "6-10"
    return "11+"

def venue_weather_adjust(con,race_id,boat):
    row=con.execute("""SELECT rc.jcd,w.wind_speed_m,w.wave_height_cm
        FROM races rc LEFT JOIN race_weather w ON w.race_id=rc.race_id
        WHERE rc.race_id=?""",(race_id,)).fetchone()
    if not row:return 0.0
    jcd,wind,wave=row
    stat=con.execute("""SELECT starts,win_rate,top3_rate FROM venue_condition_stats
       WHERE jcd=? AND course=? AND wind_bucket=? AND wave_bucket=?""",
       (jcd,boat,bucket_wind(wind),bucket_wave(wave))).fetchone()
    if not stat or stat[0] < 30:return 0.0
    starts,wr,t3=stat
    prior={1:.55,2:.15,3:.12,4:.10,5:.05,6:.03}.get(boat,.10)
    return clamp((wr-prior)*.5,-.05,.05)

def external_adjust(con,race_id,boat):
    row=con.execute("""SELECT COALESCE(SUM(adjustment),0)
                       FROM external_race_adjustments
                       WHERE race_id=? AND boat_no=?""",(race_id,boat)).fetchone()
    return clamp(row[0] if row else 0.0,-.06,.06)

def trifecta_probs(scores):
    s={b:math.exp(v*4) for b,v in scores}
    den=sum(s.values()); out={}
    for a,b,c in permutations(s,3):
        p1=s[a]/den
        p2=s[b]/sum(v for k,v in s.items() if k!=a)
        p3=s[c]/sum(v for k,v in s.items() if k not in (a,b))
        out[f"{a}{b}{c}"]=p1*p2*p3
    return out

def race_prediction(con,rid,rdate,model,recent):
    entries=con.execute("""SELECT boat_no,racer_no,national_win_rate,local_win_rate,
        avg_st,motor_quinella_rate FROM entries WHERE race_id=? ORDER BY boat_no""",(rid,)).fetchall()
    if len(entries)!=6:return None
    scores=[]
    for row in entries:
        boat=row[0]; s=base_score(row,recent)
        if model in ("B","C"): s+=venue_weather_adjust(con,rid,boat)
        if model=="C": s+=external_adjust(con,rid,boat)
        scores.append((boat,s))
    return trifecta_probs(scores)

def brier_for_trifecta(probs,actual):
    return sum((p-(1.0 if c==actual else 0.0))**2 for c,p in probs.items())

def logloss(probs,actual,eps=1e-9):
    return -math.log(max(eps,probs.get(actual,eps)))

def evaluate_model(con,start,end,model,topn=5,stake=100):
    races=con.execute("""SELECT race_id,race_date FROM races
        WHERE race_date BETWEEN ? AND ? ORDER BY race_date,jcd,race_no""",(start,end)).fetchall()
    monthly=defaultdict(lambda:{"seen":0,"bets":0,"tickets":0,"hits":0,"stake":0,"ret":0.0,"brier":0.0,"logloss":0.0})
    overall={"seen":0,"bets":0,"tickets":0,"hits":0,"stake":0,"ret":0.0,"brier":0.0,"logloss":0.0}
    cached_date=None; recent={}
    for rid,rdate in races:
        payout=con.execute("SELECT combination,amount_yen FROM payouts WHERE race_id=? AND bet_type='3連単' LIMIT 1",(rid,)).fetchone()
        if not payout:continue
        if cached_date!=rdate:
            recent=recent_before(con,rdate); cached_date=rdate
        probs=race_prediction(con,rid,rdate,model,recent)
        if not probs:continue
        actual,amount=payout
        picks=sorted(probs.items(),key=lambda x:x[1],reverse=True)[:topn]
        m=monthly[rdate[:7]]
        for d in (m,overall):
            d["seen"]+=1
            d["brier"]+=brier_for_trifecta(probs,actual)
            d["logloss"]+=logloss(probs,actual)
        if picks:
            for d in (m,overall):
                d["bets"]+=1; d["tickets"]+=len(picks); d["stake"]+=stake*len(picks)
            if any(c==actual for c,_ in picks):
                for d in (m,overall):
                    d["hits"]+=1; d["ret"]+=amount*(stake/100)
    return overall,monthly

def summarize(d):
    seen=d["seen"]
    return {
        "races":seen,"bet_races":d["bets"],"tickets":d["tickets"],"hits":d["hits"],
        "hit_rate":d["hits"]/d["bets"] if d["bets"] else 0,
        "stake":d["stake"],"return":d["ret"],
        "recovery_rate":d["ret"]/d["stake"]*100 if d["stake"] else 0,
        "brier":d["brier"]/seen if seen else None,
        "logloss":d["logloss"]/seen if seen else None,
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--start",required=True)
    ap.add_argument("--end",required=True)
    ap.add_argument("--topn",type=int,default=5)
    ap.add_argument("--stake",type=int,default=100)
    ap.add_argument("--out",default="model_compare_v05.csv")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    models={"A":"公式＋基本統計","B":"A＋場×風×波","C":"B＋外部情報"}
    rows=[]
    print("model,races,hits,hit_rate,recovery,brier,logloss")
    for code,name in models.items():
        overall,monthly=evaluate_model(con,a.start,a.end,code,a.topn,a.stake)
        s=summarize(overall)
        print(f"{code},{s['races']},{s['hits']},{s['hit_rate']:.3f},{s['recovery_rate']:.1f}%,{s['brier']},{s['logloss']}")
        rows.append({"model":code,"name":name,"month":"TOTAL",**s})
        for mon,d in sorted(monthly.items()):
            rows.append({"model":code,"name":name,"month":mon,**summarize(d)})
    with open(a.out,"w",newline="",encoding="utf-8-sig") as f:
        fieldnames=["model","name","month","races","bet_races","tickets","hits","hit_rate","stake","return","recovery_rate","brier","logloss"]
        w=csv.DictWriter(f,fieldnames=fieldnames); w.writeheader(); w.writerows(rows)
    print("saved:",a.out)

if __name__=="__main__":
    main()
