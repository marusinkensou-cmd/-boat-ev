from __future__ import annotations
from urllib.parse import urlparse, parse_qs
from bs4 import BeautifulSoup
from official_live_v10 import fetch_html

VENUES={
"01":"桐生","02":"戸田","03":"江戸川","04":"平和島","05":"多摩川","06":"浜名湖",
"07":"蒲郡","08":"常滑","09":"津","10":"三国","11":"びわこ","12":"住之江",
"13":"尼崎","14":"鳴門","15":"丸亀","16":"児島","17":"宮島","18":"徳山",
"19":"下関","20":"若松","21":"芦屋","22":"福岡","23":"唐津","24":"大村"
}
NAME_TO_JCD={v:k for k,v in VENUES.items()}

def index_url(race_date):
    return "https://www.boatrace.jp/owpc/pc/race/index?hd="+race_date.replace("-","")

def parse_today_venues(html):
    soup=BeautifulSoup(html,"html.parser")
    found={}
    for a in soup.find_all("a",href=True):
        qs=parse_qs(urlparse(a["href"]).query)
        jcd=(qs.get("jcd") or [None])[0]
        if jcd:
            j=jcd.zfill(2)
            if j in VENUES:
                found[j]=VENUES[j]
    if not found:
        text=soup.get_text(" ",strip=True)
        for name,jcd in NAME_TO_JCD.items():
            if name in text:
                found[jcd]=name
    return [{"jcd":j,"venue":found[j]} for j in sorted(found)]

def discover_today(race_date,cache_dir="cache/live"):
    html,source=fetch_html(index_url(race_date),cache_dir=cache_dir,max_age_sec=300)
    venues=parse_today_venues(html)
    if not venues:
        raise ValueError("本日の開催場を公式ページから検出できませんでした")
    return venues,source
