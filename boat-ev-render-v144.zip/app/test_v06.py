import sqlite3, tempfile
from pathlib import Path
from datetime import date, timedelta
from parse_bk import ensure_schema
from external_ingest_v04 import upsert_source, add_post, add_signal
from attribution_v06 import aggregate, save_table
from external_gate_v06 import trust_multiplier

with tempfile.TemporaryDirectory() as td:
    db=Path(td)/"x.sqlite"
    con=sqlite3.connect(db)
    ensure_schema(con,Path(__file__).with_name("schema.sql"))
    con.execute("INSERT OR IGNORE INTO stadiums VALUES('02','戸田')")
    sid=upsert_source(con,"blog","戸田テスト","https://example.com",.5)

    base=date(2026,3,1)
    for i in range(30):
        d=(base+timedelta(days=i//12)).isoformat()
        rno=(i%12)+1
        rid=f"r{i}"
        con.execute("INSERT INTO races(race_id,race_date,jcd,race_no,status) VALUES(?,?,?,?,?)",
                    (rid,d,'02',rno,'finished'))
        finish=2 if i<24 else 5
        con.execute("INSERT INTO results(race_id,boat_no,finish,actual_course) VALUES(?,?,?,?)",(rid,3,finish,3))
        con.execute("INSERT OR REPLACE INTO payouts(race_id,bet_type,combination,amount_yen,popularity) VALUES(?,?,?,?,?)",
                    (rid,'3連単','123',2500,3))
        p=add_post(con,sid,{"raw_text":"3号艇の伸び良い","race_date":d,"jcd":"02","race_no":rno,"boat_no":3})
        add_signal(con,p,"伸び","boat","3",1.0,.8,"伸び良い")
    con.commit()

    rows=aggregate(con)
    save_table(con,rows)
    specific=[r for r in rows if r["dimension"]=="source_category_venue" and r["category"]=="伸び"]
    assert specific and specific[0]["samples"]==30
    assert specific[0]["shrunk_score"]>.6, specific[0]
    m=trust_multiplier(con,sid,"伸び","02")
    assert m>1.15,m
    print("v0.6 attribution test: OK")
    print("multiplier:",round(m,3))
