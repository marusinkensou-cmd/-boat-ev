from __future__ import annotations
import argparse, sqlite3, json
from collections import Counter

def validate(db: str, race_date: str | None = None):
    con = sqlite3.connect(db)
    where = " WHERE race_date=?" if race_date else ""
    args = (race_date,) if race_date else ()

    races = con.execute(f"SELECT race_id FROM races{where}", args).fetchall()
    race_ids = [r[0] for r in races]
    problems = []

    for rid in race_ids:
        e = con.execute("SELECT COUNT(*) FROM entries WHERE race_id=?", (rid,)).fetchone()[0]
        r = con.execute("SELECT COUNT(*) FROM results WHERE race_id=?", (rid,)).fetchone()[0]
        p = con.execute("SELECT COUNT(*) FROM payouts WHERE race_id=? AND bet_type='3連単'", (rid,)).fetchone()[0]
        if e not in (0,6):
            problems.append({"race_id":rid,"type":"entries_count","value":e})
        if r not in (0,6):
            problems.append({"race_id":rid,"type":"results_count","value":r})
        # Finished races should normally have one trifecta payout. Cancellations/invalid races may differ.
        status = con.execute("SELECT status FROM races WHERE race_id=?", (rid,)).fetchone()[0]
        if status == "finished" and r == 6 and p not in (0,1):
            problems.append({"race_id":rid,"type":"trifecta_payout_count","value":p})

        # finish ranks should be unique among valid 1..6 ranks
        ranks = [x[0] for x in con.execute(
            "SELECT finish FROM results WHERE race_id=? AND finish BETWEEN 1 AND 6",(rid,)
        ).fetchall()]
        if len(ranks) != len(set(ranks)):
            problems.append({"race_id":rid,"type":"duplicate_finish","value":ranks})

        # actual course should usually be 1..6 and unique for six valid starters
        courses = [x[0] for x in con.execute(
            "SELECT actual_course FROM results WHERE race_id=? AND actual_course BETWEEN 1 AND 6",(rid,)
        ).fetchall()]
        if len(courses)==6 and len(set(courses))!=6:
            problems.append({"race_id":rid,"type":"duplicate_course","value":courses})

    summary = {
        "race_date": race_date,
        "races": len(race_ids),
        "entries": con.execute(
            "SELECT COUNT(*) FROM entries" + (" WHERE race_id IN (SELECT race_id FROM races WHERE race_date=?)" if race_date else ""),
            args
        ).fetchone()[0],
        "results": con.execute(
            "SELECT COUNT(*) FROM results" + (" WHERE race_id IN (SELECT race_id FROM races WHERE race_date=?)" if race_date else ""),
            args
        ).fetchone()[0],
        "trifecta_payouts": con.execute(
            "SELECT COUNT(*) FROM payouts WHERE bet_type='3連単'" +
            (" AND race_id IN (SELECT race_id FROM races WHERE race_date=?)" if race_date else ""),
            args
        ).fetchone()[0],
        "problems": len(problems),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if problems:
        print("問題例:")
        for p in problems[:30]:
            print(json.dumps(p, ensure_ascii=False))
    return 0 if not problems else 2

if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--date")
    a=ap.parse_args()
    raise SystemExit(validate(a.db,a.date))
