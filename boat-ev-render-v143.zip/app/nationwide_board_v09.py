from __future__ import annotations
import argparse,sqlite3,json
from datetime import datetime
from zoneinfo import ZoneInfo
from ev_engine_v08 import evaluate_race

JST=ZoneInfo("Asia/Tokyo")

def parse_deadline(race_date,deadline):
    if not deadline:
        return None
    s=str(deadline).strip()
    # Supports HH:MM, HH:MM:SS, or full ISO string.
    try:
        if "T" in s:
            dt=datetime.fromisoformat(s)
            return dt if dt.tzinfo else dt.replace(tzinfo=JST)
        parts=s.split(":")
        hh=int(parts[0]); mm=int(parts[1]); ss=int(parts[2]) if len(parts)>2 else 0
        y,m,d=map(int,race_date.split("-"))
        return datetime(y,m,d,hh,mm,ss,tzinfo=JST)
    except Exception:
        return None

def grade_for(bets):
    if not bets:
        return "PASS"
    best=bets[0]
    ev=best["ev"]; p=best["predicted_prob"]
    if ev>=1.40 and p>=.02:return "S"
    if ev>=1.25:return "A"
    if ev>=1.15:return "B"
    return "C"

def build_board(con,now=None,model="C1",window_before_min=3,window_after_min=240):
    now=now or datetime.now(JST)
    if now.tzinfo is None:
        now=now.replace(tzinfo=JST)
    today=now.date().isoformat()
    rows=con.execute("""SELECT r.race_id,r.race_date,r.jcd,r.race_no,r.deadline,r.status,
                               COALESCE(s.name,r.jcd)
                        FROM races r LEFT JOIN stadiums s ON s.jcd=r.jcd
                        WHERE r.race_date=?
                        ORDER BY r.deadline,r.jcd,r.race_no""",(today,)).fetchall()
    out=[]
    for rid,rdate,jcd,rno,deadline,status,venue in rows:
        dl=parse_deadline(rdate,deadline)
        if not dl:
            continue
        mins=(dl-now).total_seconds()/60
        if mins < -window_before_min or mins > window_after_min:
            continue
        # Never use an odds snapshot later than now or later than deadline.
        cutoff=min(now,dl).isoformat(timespec="seconds")
        result=evaluate_race(con,rid,model,before_at=cutoff)
        bets=result.get("bets",[])
        grade=grade_for(bets) if result["status"]=="bet" else "PASS"
        best=bets[0] if bets else None
        out.append({
            "race_id":rid,
            "venue":venue,
            "jcd":jcd,
            "race_no":rno,
            "deadline":dl.isoformat(),
            "minutes_to_deadline":round(mins,1),
            "race_status":status,
            "decision":result["status"],
            "grade":grade,
            "best_ev":round(best["ev"],3) if best else None,
            "best_combo":best["combination"] if best else None,
            "best_prob":round(best["predicted_prob"],4) if best else None,
            "best_odds":round(best["market_odds"],2) if best else None,
            "bet_count":len(bets),
            "bets":bets,
            "odds_captured_at":result.get("odds_captured_at"),
        })
    # Deadline is the primary sort, then better EV among ties.
    out.sort(key=lambda x:(x["minutes_to_deadline"],-(x["best_ev"] or 0)))
    return out

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default="data/boatrace.sqlite")
    ap.add_argument("--now")
    ap.add_argument("--model",default="C1")
    ap.add_argument("--json",action="store_true")
    a=ap.parse_args()
    con=sqlite3.connect(a.db)
    now=datetime.fromisoformat(a.now) if a.now else datetime.now(JST)
    rows=build_board(con,now,a.model)
    if a.json:
        print(json.dumps(rows,ensure_ascii=False,indent=2))
    else:
        for r in rows:
            if r["grade"]=="PASS":
                print(f"締切{r['minutes_to_deadline']:.0f}分 {r['venue']}{r['race_no']}R 見送り")
            else:
                print(f"締切{r['minutes_to_deadline']:.0f}分 {r['venue']}{r['race_no']}R {r['grade']}評価 "
                      f"{r['best_combo']} EV{r['best_ev']:.2f} {r['best_odds']:.1f}倍")
